### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod aliquis non possit habere odio veritatem. Bonum enim et ens et verum convertuntur. Sed aliquis non potest habere odio bonitatem. Ergo nec veritatem.

###### arg. 2
Praeterea, omnes homines naturaliter scire desiderant, ut dicitur in principio Metaphys. Sed scientia non est nisi verorum. Ergo veritas naturaliter desideratur et amatur. Sed quod naturaliter inest, semper inest. Nullus ergo potest habere odio veritatem.

###### arg. 3
Praeterea, philosophus dicit, in II Rhetoric., quod *homines amant non fictos*. Sed non nisi propter veritatem. Ergo homo naturaliter amat veritatem. Non potest ergo eam odio habere.

###### s. c.
Sed contra est quod apostolus dicit, ad Galat. IV, *factus sum vobis inimicus, verum dicens vobis*.

###### co.
Respondeo dicendum quod bonum et verum et ens sunt idem secundum rem, sed differunt ratione. Bonum enim habet rationem appetibilis, non autem ens vel verum, quia bonum est quod omnia appetunt. Et ideo bonum, sub ratione boni, non potest odio haberi, nec in universali nec in particulari. Ens autem et verum in universali quidem odio haberi non possunt, quia dissonantia est causa odii, et convenientia causa amoris; ens autem et verum sunt communia omnibus. Sed in particulari nihil prohibet quoddam ens et quoddam verum odio haberi, inquantum habet rationem contrarii et repugnantis, contrarietas enim et repugnantia non adversatur rationi entis et veri, sicut adversatur rationi boni. Contingit autem verum aliquod particulare tripliciter repugnare vel contrariari bono amato. Uno modo, secundum quod veritas est causaliter et originaliter in ipsis rebus. Et sic homo quandoque odit aliquam veritatem, dum vellet non esse verum quod est verum. Alio modo, secundum quod veritas est in cognitione ipsius hominis, quae impedit ipsum a prosecutione amati. Sicut si aliqui vellent non cognoscere veritatem fidei, ut libere peccarent, ex quorum persona dicitur [[Jb 21]], *scientiam viarum tuarum nolumus*. Tertio modo habetur odio veritas particularis, tanquam repugnans, prout est in intellectu alterius. Puta, cum aliquis vult latere in peccato, odit quod aliquis veritatem circa peccatum suum cognoscat. Et secundum hoc dicit Augustinus, in X Confess., quod *homines amant veritatem lucentem, oderunt eam redarguentem*.

###### ad 1
Et per hoc patet responsio ad primum.

###### ad 2
Ad secundum dicendum quod cognoscere veritatem secundum se est amabile, propter quod dicit Augustinus quod amant eam lucentem. Sed per accidens cognitio veritatis potest esse odibilis, inquantum impedit ab aliquo desiderato.

###### ad 3
Ad tertium dicendum quod ex hoc procedit quod non ficti amantur, quod homo amat secundum se cognoscere veritatem, quam homines non ficti manifestant.

