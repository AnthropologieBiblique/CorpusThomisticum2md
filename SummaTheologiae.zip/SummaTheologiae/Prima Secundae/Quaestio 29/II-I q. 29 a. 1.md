### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod obiectum et causa odii non sit malum. Omne enim quod est, inquantum huiusmodi bonum est. Si igitur obiectum odii sit malum, sequitur quod nulla res odio habeatur, sed solum defectus alicuius rei. Quod patet esse falsum.

###### arg. 2
Praeterea, odire malum est laudabile, unde in laudem quorundam dicitur [[2 M 3]], quod *leges optime custodiebantur, propter Oniae pontificis pietatem, et animos odio habentes mala*. Si igitur nihil oditur nisi malum, sequitur quod omne odium sit laudabile. Quod patet esse falsum.

###### arg. 3
Praeterea, idem non est simul bonum et malum. Sed idem diversis est odibile et amabile. Ergo odium non solum est mali, sed etiam boni.

###### s. c.
Sed contra, odium contrariatur amori. Sed obiectum amoris est bonum, ut supra dictum est. Ergo obiectum odii est malum.

###### co.
Respondeo dicendum quod, cum appetitus naturalis derivetur ab aliqua apprehensione, licet non coniuncta; eadem ratio videtur esse de inclinatione appetitus naturalis, et appetitus animalis, qui sequitur apprehensionem coniunctam, sicut supra dictum est. In appetitu autem naturali hoc manifeste apparet, quod sicut unumquodque habet naturalem consonantiam vel aptitudinem ad id quod sibi convenit, quae est amor naturalis; ita ad id quod est ei repugnans et corruptivum, habet dissonantiam naturalem, quae est odium naturale. Sic igitur et in appetitu animali, seu in intellectivo, amor est consonantia quaedam appetitus ad id quod apprehenditur ut conveniens, odium vero est dissonantia quaedam appetitus ad id quod apprehenditur ut repugnans et nocivum. Sicut autem omne conveniens, inquantum huiusmodi, habet rationem boni; ita omne repugnans, inquantum huiusmodi, habet rationem mali. Et ideo, sicut bonum est obiectum amoris, ita malum est obiectum odii.

###### ad 1
Ad primum ergo dicendum quod ens, inquantum ens, non habet rationem repugnantis, sed magis convenientis, quia omnia conveniunt in ente. Sed ens inquantum est hoc ens determinatum, habet rationem repugnantis ad aliquod ens determinatum. Et secundum hoc, unum ens est odibile alteri, et est malum, etsi non in se, tamen per comparationem ad alterum.

###### ad 2
Ad secundum dicendum quod, sicut aliquid apprehenditur ut bonum, quod non est vere bonum; ita aliquid apprehenditur ut malum, quod non est vere malum. Unde contingit quandoque nec odium mali, nec amorem boni esse bonum.

###### ad 3
Ad tertium dicendum quod contingit idem esse amabile et odibile diversis, secundum appetitum quidem naturalem, ex hoc quod unum et idem est conveniens uni secundum suam naturam, et repugnans alteri, sicut calor convenit igni, et repugnat aquae. Secundum appetitum vero animalem, ex hoc quod unum et idem apprehenditur ab uno sub ratione boni, et ab alio sub ratione mali.

