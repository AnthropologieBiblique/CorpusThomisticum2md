### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod aliquis possit seipsum odio habere. Dicitur enim in Psalmo X, *qui diligit iniquitatem, odit animam suam*. Sed multi diligunt iniquitatem. Ergo multi odiunt seipsos.

###### arg. 2
Praeterea, illum odimus, cui volumus et operamur malum. Sed quandoque aliquis vult et operatur sibi ipsi malum, puta qui interimunt seipsos. Ergo aliqui seipsos habent odio.

###### arg. 3
Praeterea, Boetius dicit, in II de Consol., quod *avaritia facit homines odiosos*, ex quo potest accipi quod omnis homo odit avarum. Sed aliqui sunt avari. Ergo illi odiunt seipsos.

###### s. c.
Sed contra est quod apostolus dicit, ad [[Ep 5]], quod *nemo unquam carnem suam odio habuit*.

###### co.
Respondeo dicendum quod impossibile est quod aliquis, per se loquendo, odiat seipsum. Naturaliter enim unumquodque appetit bonum, nec potest aliquis aliquid sibi appetere nisi sub ratione boni, nam malum est praeter voluntatem, ut Dionysius dicit, IV cap. de Div. Nom. Amare autem aliquem est velle ei bonum, ut supra dictum est. Unde necesse est quod aliquis amet seipsum; et impossibile est quod aliquis odiat seipsum, per se loquendo. Per accidens tamen contingit quod aliquis seipsum odio habeat. Et hoc dupliciter. Uno modo, ex parte boni quod sibi aliquis vult. Accidit enim quandoque illud quod appetitur ut secundum quid bonum, esse simpliciter malum, et secundum hoc, aliquis per accidens vult sibi malum, quod est odire. Alio modo, ex parte sui ipsius, cui vult bonum. Unumquodque enim maxime est id quod est principalius in ipso, unde civitas dicitur facere quod rex facit, quasi rex sit tota civitas. Manifestum est ergo quod homo maxime est mens hominis. Contingit autem quod aliqui aestimant se esse maxime illud quod sunt secundum naturam corporalem et sensitivam. Unde amant se secundum id quod aestimant se esse, sed odiunt id quod vere sunt, dum volunt contraria rationi. Et utroque modo, ille qui diligit iniquitatem, odit non solum animam suam, sed etiam seipsum.

###### ad 1
Et per hoc patet responsio ad primum.

###### ad 2
Ad secundum dicendum quod nullus sibi vult et facit malum, nisi inquantum apprehendit illud sub ratione boni. Nam et illi qui interimunt seipsos, hoc ipsum quod est mori, apprehendunt sub ratione boni, inquantum est terminativum alicuius miseriae vel doloris.

###### ad 3
Ad tertium dicendum quod avarus odit aliquod accidens suum, non tamen propter hoc odit seipsum, sicut aeger odit suam aegritudinem, ex hoc ipso quod se amat. Vel dicendum quod avaritia odiosos facit aliis, non autem sibi ipsi. Quinimmo causatur ex inordinato sui amore, secundum quem de bonis temporalibus plus sibi aliquis vult quam debeat.

