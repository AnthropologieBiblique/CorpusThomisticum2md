## Quaestio 29

### Prooemium

Deinde considerandum est de odio. Et circa hoc quaeruntur sex. Primo, utrum causa et obiectum odii sit malum. Secundo, utrum odium causetur ex amore. Tertio, utrum odium sit fortius quam amor. Quarto, utrum aliquis possit habere odio seipsum. Quinto, utrum aliquis possit habere odio veritatem. Sexto, utrum aliquid possit haberi odio in universali.

![[II-I q. 29 a. 1#Articulus 1]]

![[II-I q. 29 a. 2#Articulus 2]]

![[II-I q. 29 a. 3#Articulus 3]]

![[II-I q. 29 a. 4#Articulus 4]]

![[II-I q. 29 a. 5#Articulus 5]]

![[II-I q. 29 a. 6#Articulus 6]]

