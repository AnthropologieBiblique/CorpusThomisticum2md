### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod amor non sit causa odii. *Ea enim quae ex opposito dividuntur, naturaliter sunt simul*, ut dicitur in praedicamentis. Sed amor et odium, cum sint contraria, ex opposito dividuntur. Ergo naturaliter sunt simul. Non ergo amor est causa odii.

###### arg. 2
Praeterea, unum contrariorum non est causa alterius. Sed amor et odium sunt contraria. Ergo amor non est causa odii.

###### arg. 3
Praeterea, posterius non est causa prioris. Sed odium est prius amore, ut videtur, nam odium importat recessum a malo, amor vero accessum ad bonum. Ergo amor non est causa odii.

###### s. c.
Sed contra est quod dicit Augustinus, XIV de Civ. Dei, quod omnes affectiones causantur ex amore. Ergo et odium, cum sit quaedam affectio animae, causatur ex amore.

###### co.
Respondeo dicendum quod, sicut dictum est, amor consistit in quadam convenientia amantis ad amatum, odium vero consistit in quadam repugnantia vel dissonantia. Oportet autem in quolibet prius considerare quid ei conveniat, quam quid ei repugnet, per hoc enim aliquid est repugnans alteri, quia est corruptivum vel impeditivum eius quod est conveniens. Unde necesse est quod amor sit prior odio; et quod nihil odio habeatur, nisi per hoc quod contrariatur convenienti quod amatur. Et secundum hoc, omne odium ex amore causatur.

###### ad 1
Ad primum ergo dicendum quod in his quae ex opposito dividuntur, quaedam inveniuntur quae sunt naturaliter simul et secundum rem, et secundum rationem, sicut duae species animalis, vel duae species coloris. Quaedam vero sunt simul secundum rationem, sed unum realiter est prius altero et causa eius, sicut patet in speciebus numerorum, figurarum et motuum. Quaedam vero non sunt simul nec secundum rem, nec secundum rationem, sicut substantia et accidens, nam substantia realiter est causa accidentis; et ens secundum rationem prius attribuitur substantiae quam accidenti, quia accidenti non attribuitur nisi inquantum est in substantia. Amor autem et odium naturaliter quidem sunt simul secundum rationem, sed non realiter. Unde nihil prohibet amorem esse causam odii.

###### ad 2
Ad secundum dicendum quod amor et odium sunt contraria, quando accipiuntur circa idem. Sed quando sunt de contrariis, non sunt contraria, sed se invicem consequentia, eiusdem enim rationis est quod ametur aliquid, et odiatur eius contrarium. Et sic amor unius rei est causa quod eius contrarium odiatur.

###### ad 3
Ad tertium dicendum quod in executione prius est recedere ab uno termino, quam accedere ad alterum terminum. Sed in intentione est e converso, propter hoc enim receditur ab uno termino, ut accedatur ad alterum. Motus autem appetitivus magis pertinet ad intentionem quam ad executionem. Et ideo amor est prior odio, cum utrumque sit motus appetitivus.

