## Quaestio 70

### Prooemium

Deinde considerandum est de fructibus. Et circa hoc quaeruntur quatuor. Primo, utrum fructus spiritus sancti sint actus. Secundo, utrum differant a beatitudinibus. Tertio, de eorum numero. Quarto, de oppositione eorum ad opera carnis.

![[II-I q. 70 a. 1#Articulus 1]]

![[II-I q. 70 a. 2#Articulus 2]]

![[II-I q. 70 a. 3#Articulus 3]]

