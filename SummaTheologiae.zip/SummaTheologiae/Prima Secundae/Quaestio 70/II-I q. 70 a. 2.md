### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod fructus a beatitudinibus non differant. Beatitudines enim attribuuntur donis, ut supra dictum est. Sed dona perficiunt hominem secundum quod movetur a spiritu sancto. Ergo beatitudines ipsae sunt fructus spiritus sancti.

###### arg. 2
Praeterea, sicut se habet fructus vitae aeternae ad beatitudinem futuram, quae est rei; ita se habent fructus praesentis vitae ad beatitudines praesentis vitae, quae sunt spei. Sed fructus vitae aeternae est ipsa beatitudo futura. Ergo fructus vitae praesentis sunt ipsae beatitudines.

###### arg. 3
Praeterea, de ratione fructus est quod sit quiddam ultimum et delectabile. Sed hoc pertinet ad rationem beatitudinis, ut supra dictum est. Ergo eadem ratio est fructus et beatitudinis. Ergo non debent ab invicem distingui.

###### s. c.
Sed contra, quorum species sunt diversae, ipsa quoque sunt diversa. Sed in diversas partes dividuntur et fructus et beatitudines; ut patet per numerationem utrorumque. Ergo fructus differunt a beatitudinibus.

###### co.
Respondeo dicendum quod plus requiritur ad rationem beatitudinis, quam ad rationem fructus. Nam ad rationem fructus sufficit quod sit aliquid habens rationem ultimi et delectabilis, sed ad rationem beatitudinis, ulterius requiritur quod sit aliquid perfectum et excellens. Unde omnes beatitudines possunt dici fructus, sed non convertitur. Sunt enim fructus quaecumque virtuosa opera, in quibus homo delectatur. Sed beatitudines dicuntur solum perfecta opera, quae etiam, ratione suae perfectionis, magis attribuuntur donis quam virtutibus, ut supra dictum est.

###### ad 1
Ad primum ergo dicendum quod ratio illa probat quod beatitudines sint fructus, non autem quod omnes fructus beatitudines sint.

###### ad 2
Ad secundum dicendum quod fructus vitae aeternae est simpliciter ultimus et perfectus, et ideo in nullo distinguitur a beatitudine futura. Fructus autem praesentis vitae non sunt simpliciter ultimi et perfecti, et ideo non omnes fructus sunt beatitudines.

###### ad 3
Ad tertium dicendum quod aliquid amplius est de ratione beatitudinis quam de ratione fructus, ut dictum est.

