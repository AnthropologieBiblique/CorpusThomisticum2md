## Quaestio 92

### Prooemium

Deinde considerandum est de effectibus legis. Et circa hoc quaeruntur duo. Primo, utrum effectus legis sit homines facere bonos. Secundo, utrum effectus legis sint imperare, vetare, permittere et punire, sicut legisperitus dicit.

![[II-I q. 92 a. 1#Articulus 1]]

