## Quaestio 87

### Prooemium

Deinde considerandum est de reatu poenae. Et primo, de ipso reatu; secundo, de mortali et veniali peccato, quae distinguuntur secundum reatum. Circa primum quaeruntur octo. Primo, utrum reatus poenae sit effectus peccati. Secundo, utrum peccatum possit esse poena alterius peccati. Tertio, utrum aliquod peccatum faciat reum aeterna poena. Quarto, utrum faciat reum poena infinita secundum quantitatem. Quinto, utrum omne peccatum faciat reum aeterna et infinita poena. Sexto, utrum reatus poenae possit remanere post peccatum. Septimo, utrum omnis poena inferatur pro aliquo peccato. Octavo, utrum unus sit reus poenae pro peccato alterius.

![[II-I q. 87 a. 1#Articulus 1]]

![[II-I q. 87 a. 2#Articulus 2]]

![[II-I q. 87 a. 3#Articulus 3]]

![[II-I q. 87 a. 4#Articulus 4]]

![[II-I q. 87 a. 5#Articulus 5]]

![[II-I q. 87 a. 6#Articulus 6]]

![[II-I q. 87 a. 7#Articulus 7]]

![[II-I q. 87 a. 8#Articulus 8]]

