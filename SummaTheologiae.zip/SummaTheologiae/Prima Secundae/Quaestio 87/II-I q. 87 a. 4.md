### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod peccato debeatur poena infinita secundum quantitatem. Dicitur enim [[Jr 10]], *corripe me, domine, veruntamen in iudicio, et non in furore tuo, ne forte ad nihilum redigas me*. Ira autem vel furor Dei metaphorice significat vindictam divinae iustitiae, redigi autem in nihilum est poena infinita, sicut et ex nihilo aliquid facere est virtutis infinitae. Ergo secundum vindictam divinam, peccatum punitur poena infinita secundum quantitatem.

###### arg. 2
Praeterea, quantitati culpae respondet quantitas poenae; secundum illud Deuteron. XXV, *pro mensura peccati erit et plagarum modus*. Sed peccatum quod contra Deum committitur, est infinitum, tanto enim gravius est peccatum, quanto maior est persona contra quam peccatur, sicut gravius peccatum est percutere principem quam percutere hominem privatum; Dei autem magnitudo est infinita. Ergo poena infinita debetur pro peccato quod contra Deum committitur.

###### arg. 3
Praeterea, dupliciter est aliquid infinitum, duratione scilicet, et quantitate. Sed duratione est poena infinita. Ergo et quantitate.

###### s. c.
Sed contra est quia secundum hoc omnium mortalium peccatorum poenae essent aequales, non enim est infinitum infinito maius.

###### co.
Respondeo dicendum quod poena proportionatur peccato. In peccato autem duo sunt. Quorum unum est aversio ab incommutabili bono, quod est infinitum, unde ex hac parte peccatum est infinitum. Aliud quod est in peccato, est inordinata conversio ad commutabile bonum. Et ex hac parte peccatum est finitum, tum quia ipsum bonum commutabile est finitum; tum quia ipsa conversio est finita, non enim possunt esse actus creaturae infiniti. Ex parte igitur aversionis, respondet peccato poena damni, quae etiam est infinita, est enim amissio infiniti boni, scilicet Dei. Ex parte autem inordinatae conversionis, respondet ei poena sensus, quae etiam est finita.

###### ad 1
Ad primum ergo dicendum quod omnino redigi in nihilum eum qui peccat, non convenit divinae iustitiae, quia repugnat perpetuitati poenae, quae est secundum divinam iustitiam, ut dictum est. Sed in nihilum redigi dicitur qui spiritualibus bonis privatur; secundum illud [[1 Co 13]], *si non habuero caritatem, nihil sum*.

###### ad 2
Ad secundum dicendum quod ratio illa procedit de peccato ex parte aversionis, sic enim homo contra Deum peccat.

###### ad 3
Ad tertium dicendum quod duratio poenae respondet durationi culpae, non quidem ex parte actus, sed ex parte maculae, qua durante manet reatus poenae. Sed acerbitas poenae respondet gravitati culpae. Culpa autem quae est irreparabilis, de se habet quod perpetuo duret, et ideo debetur ei poena aeterna. Non autem ex parte conversionis habet infinitatem, et ideo non debetur ei ex hac parte poena infinita secundum quantitatem.

