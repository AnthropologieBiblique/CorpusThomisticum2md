### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod peccatum non possit esse poena peccati. Poenae enim sunt inductae ut per eas homines reducantur ad bonum virtutis, ut patet per philosophum, in X Ethic. Sed per peccatum non reducitur homo in bonum virtutis, sed in oppositum. Ergo peccatum non est poena peccati.

###### arg. 2
Praeterea, poenae iustae sunt a Deo, ut patet per Augustinum, in libro octoginta trium quaest. Peccatum autem non est a Deo, et est iniustum. Non ergo peccatum potest esse poena peccati.

###### arg. 3
Praeterea, de ratione poenae est quod sit contra voluntatem. Sed peccatum est a voluntate, ut ex supradictis patet. Ergo peccatum non potest esse poena peccati.

###### s. c.
Sed contra est quod Gregorius dicit, super Ezech., quod quaedam peccata sunt poenae peccati.

###### co.
Respondeo dicendum quod de peccato dupliciter loqui possumus, per se, et per accidens. Per se quidem nullo modo peccatum potest esse poena peccati. Peccatum enim per se consideratur secundum quod egreditur a voluntate, sic enim habet rationem culpae. De ratione autem poenae est quod sit contra voluntatem, ut in primo habitum est. Unde manifestum est quod nullo modo, per se loquendo, peccatum potest esse poena peccati. Per accidens autem peccatum potest esse poena peccati, tripliciter. Primo quidem, ex parte causae quae est remotio prohibentis. Sunt enim causae inclinantes ad peccatum passiones, tentatio Diaboli, et alia huiusmodi; quae quidem causae impediuntur per auxilium divinae gratiae, quae subtrahitur per peccatum. Unde cum ipsa subtractio gratiae sit quaedam poena, et a Deo, ut supra dictum est; sequitur quod per accidens etiam peccatum quod ex hoc sequitur, poena dicatur. Et hoc modo loquitur apostolus, [[Rm 1]], dicens, *propter quod tradidit eos Deus in desideria cordis eorum*, quae sunt animae passiones, quia scilicet deserti homines ab auxilio divinae gratiae, vincuntur a passionibus. Et hoc modo semper peccatum dicitur esse poena praecedentis peccati. Alio modo ex parte substantiae actus, quae afflictionem inducit, sive sit actus interior, ut patet in ira et invidia; sive actus exterior, ut patet cum aliqui gravi labore opprimuntur et damno, ut expleant actum peccati, secundum illud [[Sg 5]], *lassati sumus in via iniquitatis*. Tertio modo, ex parte effectus, ut scilicet aliquod peccatum dicatur poena respectu effectus consequentis. Et his duobus ultimis modis, unum peccatum non solum est poena praecedentis peccati, sed etiam sui.

###### ad 1
Ad primum ergo dicendum quod hoc etiam quod aliqui puniuntur a Deo, dum permittit eos in aliqua peccata profluere, ad bonum virtutis ordinatur. Quandoque quidem etiam ipsorum qui peccant, cum scilicet post peccatum humiliores et cautiores resurgunt. Semper autem est ad emendationem aliorum, qui videntes aliquos ruere de peccato in peccatum, magis reformidant peccare. In aliis autem duobus modis, manifestum est quod poena ordinatur ad emendationem quia hoc ipsum quod homo laborem et detrimentum patitur in peccando, natum est retrahere homines a peccato.

###### ad 2
Ad secundum dicendum quod ratio illa procedit de peccato secundum se.

###### ad 3
Et similiter dicendum est ad tertium.

