### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod reatus poenae non remaneat post peccatum. Remota enim causa, removetur effectus. Sed peccatum est causa reatus poenae. Ergo, remoto peccato, cessat reatus poenae.

###### arg. 2
Praeterea, peccatum removetur per hoc quod homo ad virtutem redit. Sed virtuoso non debetur poena, sed magis praemium. Ergo, remoto peccato, non remanet reatus poenae.

###### arg. 3
Praeterea, poenae sunt medicinae, ut dicitur in II Ethic. Sed postquam aliquis iam est ab infirmitate curatus, non adhibetur sibi medicina. Ergo, remoto peccato, non remanet debitum poenae.

###### s. c.
Sed contra est quod dicitur [[2S 12]], quod *David dixit ad Nathan, peccavi domino. Dixitque Nathan ad David, dominus quoque transtulit peccatum tuum, non morieris. Veruntamen quia blasphemare fecisti inimicos nomen domini, filius qui natus est tibi, morte morietur*. Punitur ergo aliquis a Deo etiam postquam ei peccatum dimittitur. Et sic reatus poenae remanet, peccato remoto.

###### co.
Respondeo dicendum quod in peccato duo possunt considerari, scilicet actus culpae, et macula sequens. Planum est autem quod, cessante actu peccati, remanet reatus, in omnibus peccatis actualibus. Actus enim peccati facit hominem reum poenae, inquantum transgreditur ordinem divinae iustitiae; ad quem non redit nisi per quandam recompensationem poenae, quae ad aequalitatem iustitiae reducit; ut scilicet qui plus voluntati suae indulsit quam debuit, contra mandatum Dei agens, secundum ordinem divinae iustitiae, aliquid contra illud quod vellet, spontaneus vel invitus patiatur. Quod etiam in iniuriis hominibus factis observatur, ut per recompensationem poenae reintegretur aequalitas iustitiae. Unde patet quod, cessante actu peccati vel iniuriae illatae, adhuc remanet debitum poenae. Sed si loquamur de ablatione peccati quantum ad maculam, sic manifestum est quod macula peccati ab anima auferri non potest, nisi per hoc quod anima Deo coniungitur, per cuius distantiam detrimentum proprii nitoris incurrebat, quod est macula, ut supra dictum est. Coniungitur autem homo Deo per voluntatem. Unde macula peccati ab homine tolli non potest nisi voluntas hominis ordinem divinae iustitiae acceptet, ut scilicet vel ipse poenam sibi spontaneus assumat in recompensationem culpae praeteritae, vel etiam a Deo illatam patienter sustineat, utroque enim modo poena rationem satisfactionis habet. Poena autem satisfactoria diminuit aliquid de ratione poenae. Est enim de ratione poenae quod sit contra voluntatem. Poena autem satisfactoria, etsi secundum absolutam considerationem sit contra voluntatem, tamen tunc, et pro hoc, est voluntaria. Unde simpliciter est voluntaria, secundum quid autem involuntaria, sicut patet ex his quae supra de voluntario et involuntario dicta sunt. Dicendum est ergo quod, remota macula culpae, potest quidem remanere reatus non poenae simpliciter, sed satisfactoriae.

###### ad 1
Ad primum ergo dicendum quod sicut, cessante actu peccati, remanet macula, ut supra dictum est; ita etiam potest remanere reatus. Cessante vero macula, non remanet reatus secundum eandem rationem, ut dictum est.

###### ad 2
Ad secundum dicendum quod virtuoso non debetur poena simpliciter, potest tamen sibi deberi poena ut satisfactoria, quia hoc ipsum ad virtutem pertinet, ut satisfaciat pro his in quibus offendit vel Deum vel hominem.

###### ad 3
Ad tertium dicendum quod, remota macula, sanatum est vulnus peccati quantum ad voluntatem. Requiritur autem adhuc poena ad sanationem aliarum virium animae, quae per peccatum praecedens deordinatae fuerunt, ut scilicet per contraria curentur. Requiritur etiam ad restituendum aequalitatem iustitiae; et ad amovendum scandalum aliorum, ut aedificentur in poena qui sunt scandalizati in culpa; ut patet ex exemplo de David inducto.

