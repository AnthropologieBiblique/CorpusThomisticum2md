### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod non omnes actus virtutum sint de lege naturae. Quia, ut supra dictum est, de ratione legis est ut ordinetur ad bonum commune. Sed quidam virtutum actus ordinantur ad bonum privatum alicuius, ut patet praecipue in actibus temperantiae. Non ergo omnes actus virtutum legi subduntur naturali.

###### arg. 2
Praeterea, omnia peccata aliquibus virtuosis actibus opponuntur. Si igitur omnes actus virtutum sint de lege naturae, videtur ex consequenti quod omnia peccata sint contra naturam. Quod tamen specialiter de quibusdam peccatis dicitur.

###### arg. 3
Praeterea, in his quae sunt secundum naturam, omnes conveniunt. Sed in actibus virtutum non omnes conveniunt, aliquid enim est virtuosum uni, quod est alteri vitiosum. Ergo non omnes actus virtutum sunt de lege naturae.

###### s. c.
Sed contra est quod Damascenus dicit, in III libro, quod virtutes sunt naturales. Ergo et actus virtuosi subiacent legi naturae.

###### co.
Respondeo dicendum quod de actibus virtuosis dupliciter loqui possumus, uno modo, inquantum sunt virtuosi; alio modo, inquantum sunt tales actus in propriis speciebus considerati. Si igitur loquamur de actibus virtutum inquantum sunt virtuosi, sic omnes actus virtuosi pertinent ad legem naturae. Dictum est enim quod ad legem naturae pertinet omne illud ad quod homo inclinatur secundum suam naturam. Inclinatur autem unumquodque naturaliter ad operationem sibi convenientem secundum suam formam, sicut ignis ad calefaciendum. Unde cum anima rationalis sit propria forma hominis, naturalis inclinatio inest cuilibet homini ad hoc quod agat secundum rationem. Et hoc est agere secundum virtutem. Unde secundum hoc, omnes actus virtutum sunt de lege naturali, dictat enim hoc naturaliter unicuique propria ratio, ut virtuose agat. Sed si loquamur de actibus virtuosis secundum seipsos, prout scilicet in propriis speciebus considerantur, sic non omnes actus virtuosi sunt de lege naturae. Multa enim secundum virtutem fiunt, ad quae natura non primo inclinat; sed per rationis inquisitionem ea homines adinvenerunt, quasi utilia ad bene vivendum.

###### ad 1
Ad primum ergo dicendum quod temperantia est circa concupiscentias naturales cibi et potus et venereorum, quae quidem ordinantur ad bonum commune naturae, sicut et alia legalia ordinantur ad bonum commune morale.

###### ad 2
Ad secundum dicendum quod natura hominis potest dici vel illa quae est propria homini, et secundum hoc, omnia peccata, inquantum sunt contra rationem, sunt etiam contra naturam, ut patet per Damascenum, in II libro. Vel illa quae est communis homini et aliis animalibus, et secundum hoc, quaedam specialia peccata dicuntur esse contra naturam; sicut contra commixtionem maris et feminae, quae est naturalis omnibus animalibus, est concubitus masculorum, quod specialiter dicitur vitium contra naturam.

###### ad 3
Ad tertium dicendum quod ratio illa procedit de actibus secundum seipsos consideratis. Sic enim, propter diversas hominum conditiones, contingit quod aliqui actus sunt aliquibus virtuosi, tanquam eis proportionati et convenientes, qui tamen sunt aliis vitiosi, tanquam eis non proportionati.

