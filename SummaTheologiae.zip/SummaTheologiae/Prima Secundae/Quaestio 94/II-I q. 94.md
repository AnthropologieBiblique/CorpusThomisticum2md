## Quaestio 94

### Prooemium

Deinde considerandum est de lege naturali. Et circa hoc quaeruntur sex. Primo, quid sit lex naturalis. Secundo, quae sint praecepta legis naturalis. Tertio, utrum omnes actus virtutum sint de lege naturali. Quarto, utrum lex naturalis sit una apud omnes. Quinto, utrum sit mutabilis. Sexto, utrum possit a mente hominis deleri.

![[II-I q. 94 a. 1#Articulus 1]]

![[II-I q. 94 a. 2#Articulus 2]]

![[II-I q. 94 a. 3#Articulus 3]]

![[II-I q. 94 a. 4#Articulus 4]]

![[II-I q. 94 a. 5#Articulus 5]]

