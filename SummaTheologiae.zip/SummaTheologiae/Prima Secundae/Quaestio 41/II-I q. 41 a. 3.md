### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod timor aliquis sit naturalis. Dicit enim Damascenus, in III libro, quod *est quidam timor naturalis, nolente anima dividi a corpore*.

###### arg. 2
Praeterea, timor ex amore oritur, ut dictum est. Sed est aliquis amor naturalis, ut Dionysius dicit, IV cap. de Div. Nom. Ergo etiam est aliquis timor naturalis.

###### arg. 3
Praeterea, timor opponitur spei, ut supra dictum est. Sed est aliqua spes naturae, ut patet per id quod dicitur [[Rm 4]], de Abraham, quod contra spem naturae, in spem gratiae credidit. Ergo etiam est aliquis timor naturae.

###### s. c.
Sed contra, ea quae sunt naturalia, communiter inveniuntur in rebus animatis et inanimatis. Sed timor non invenitur in rebus inanimatis. Ergo timor non est naturalis.

###### co.
Respondeo dicendum quod aliquis motus dicitur naturalis, quia ad ipsum inclinat natura. Sed hoc contingit dupliciter. Uno modo, quod totum perficitur a natura, absque aliqua operatione apprehensivae virtutis, sicut moveri sursum est motus naturalis ignis, et augeri est motus naturalis animalium et plantarum. Alio modo dicitur motus naturalis, ad quem natura inclinat, licet non perficiatur nisi per apprehensionem, quia, sicut supra dictum est, motus cognitivae et appetitivae virtutis reducuntur in naturam, sicut in principium primum. Et per hunc modum, etiam ipsi actus apprehensivae virtutis, ut intelligere, sentire et memorari, et etiam motus appetitus animalis, quandoque dicuntur naturales. Et per hunc modum potest dici timor naturalis. Et distinguitur a timore non naturali, secundum diversitatem obiecti. Est enim, ut philosophus dicit in II Rhetoric., timor de malo corruptivo, quod natura refugit propter naturale desiderium essendi, et talis timor dicitur naturalis. Est iterum de malo contristativo, quod non repugnat naturae, sed desiderio appetitus, et talis timor non est naturalis. Sicut etiam supra amor, concupiscentia et delectatio distincta sunt per naturale et non naturale. Sed secundum primam acceptionem naturalis, sciendum est quod quaedam de passionibus animae quandoque dicuntur naturales, ut amor, desiderium et spes, aliae vero naturales dici non possunt. Et hoc ideo, quia amor et odium, desiderium et fuga, important inclinationem quandam ad prosequendum bonum et fugiendum malum; quae quidem inclinatio pertinet etiam ad appetitum naturalem. Et ideo est amor quidam naturalis, et desiderium vel spes potest quodammodo dici etiam in rebus naturalibus cognitione carentibus. Sed aliae passiones animae important quosdam motus ad quos nullo modo sufficit inclinatio naturalis. Vel quia de ratione harum passionum est sensus seu cognitio, sicut dictum est quod apprehensio requiritur ad rationem delectationis et doloris, unde quae carent cognitione, non possunt dici delectari vel dolere. Aut quia huiusmodi motus sunt contra rationem inclinationis naturalis, puta quod desperatio refugit bonum propter aliquam difficultatem; et timor refugit impugnationem mali contrarii, ad quod est inclinatio naturalis. Et ideo huiusmodi passiones nullo modo attribuuntur rebus inanimatis.

###### ad 
Et per hoc patet responsio ad obiecta.

