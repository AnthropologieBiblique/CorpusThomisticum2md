## Quaestio 41

### Prooemium

Consequenter considerandum est, primo, de timore; et secundo, de audacia. Circa timorem consideranda sunt quatuor, primo, de ipso timore; secundo, de obiecto eius; tertio, de causa ipsius; quarto, de effectu. Circa primum quaeruntur quatuor. Primo, utrum timor sit passio animae. Secundo, utrum sit specialis passio. Tertio, utrum sit aliquis timor naturalis. Quarto, de speciebus timoris.

![[II-I q. 41 a. 1#Articulus 1]]

![[II-I q. 41 a. 2#Articulus 2]]

![[II-I q. 41 a. 3#Articulus 3]]

![[II-I q. 41 a. 4#Articulus 4]]

