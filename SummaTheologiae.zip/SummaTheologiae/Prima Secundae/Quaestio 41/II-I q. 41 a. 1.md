### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod timor non sit passio animae. Dicit enim Damascenus, in libro III, quod timor est virtus secundum systolen idest contractionem, essentiae desiderativa. Sed nulla virtus est passio, ut probatur in II Ethic. Ergo timor non est passio.

###### arg. 2
Praeterea, omnis passio est effectus ex praesentia agentis proveniens. Sed timor non est de aliquo praesenti, sed de futuro, ut Damascenus dicit in II libro. Ergo timor non est passio.

###### arg. 3
Praeterea, omnis passio animae est motus appetitus sensitivi, qui sequitur apprehensionem sensus. Sensus autem non est apprehensivus futuri, sed praesentis. Cum ergo timor sit de malo futuro, videtur quod non sit passio animae.

###### s. c.
Sed contra est quod Augustinus, in XIV de Civ. Dei, enumerat timorem inter alias animae passiones.

###### co.
Respondeo dicendum quod, inter ceteros animae motus, post tristitiam, timor magis rationem obtinet passionis. Ut enim supra dictum est, ad rationem passionis primo quidem pertinet quod sit motus passivae virtutis, ad quam scilicet comparetur suum obiectum per modum activi moventis, eo quod passio est effectus agentis. Et per hunc modum, etiam sentire et intelligere dicuntur pati. Secundo, magis proprie dicitur passio motus appetitivae virtutis. Et adhuc magis proprie, motus appetitivae virtutis habentis organum corporale, qui fit cum aliqua transmutatione corporali. Et adhuc propriissime illi motus passiones dicuntur, qui important aliquod nocumentum. Manifestum est autem quod timor, cum sit de malo, ad appetitivam potentiam pertinet, quae per se respicit bonum et malum. Pertinet autem ad appetitum sensitivum, fit enim cum quadam transmutatione, scilicet cum contractione, ut Damascenus dicit. Et importat etiam habitudinem ad malum, secundum quod malum habet quodammodo victoriam super aliquod bonum. Unde verissime sibi competit ratio passionis. Tamen post tristitiam, quae est de malo praesenti, nam timor est de malo futuro, quod non ita movet sicut praesens.

###### ad 1
Ad primum ergo dicendum quod virtus nominat quoddam principium actionis, et ideo, inquantum interiores motus appetitivae virtutis sunt principia exteriorum actuum, dicuntur virtutes. Philosophus autem negat passionem esse virtutem quae est habitus.

###### ad 2
Ad secundum dicendum quod, sicut passio corporis naturalis provenit ex corporali praesentia agentis, ita passio animae provenit ex animali praesentia agentis, absque praesentia corporali vel reali, inquantum scilicet malum quod est futurum realiter, est praesens secundum apprehensionem animae.

###### ad 3
Ad tertium dicendum quod sensus non apprehendit futurum, sed ex eo quod apprehendit praesens, animal naturali instinctu movetur ad sperandum futurum bonum, vel timendum futurum malum.

