## Quaestio 110

### Prooemium

Deinde considerandum est de gratia Dei quantum ad eius essentiam. Et circa hoc quaeruntur quatuor. Primo, utrum gratia ponat aliquid in anima. Secundo, utrum gratia sit qualitas. Tertio, utrum gratia differat a virtute infusa. Quarto, de subiecto gratiae.

![[II-I q. 110 a. 1#Articulus 1]]

![[II-I q. 110 a. 2#Articulus 2]]

![[II-I q. 110 a. 3#Articulus 3]]

![[II-I q. 110 a. 4#Articulus 4]]

