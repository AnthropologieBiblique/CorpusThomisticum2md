### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod amor sui non sit principium omnis peccati. Id enim quod est secundum se bonum et debitum, non est propria causa peccati. Sed amor sui est secundum se bonum et debitum, unde et praecipitur homini ut diligat proximum sicut seipsum, [[Lv 19]]. Ergo amor sui non potest esse propria causa peccati.

###### arg. 2
Praeterea, apostolus dicit, [[Rm 7]], *occasione accepta, peccatum per mandatum operatum est in me omnem concupiscentiam*, ubi Glossa dicit quod *bona est lex, quae, dum concupiscentiam prohibet, omne malum prohibet*, quod dicitur propter hoc, quia concupiscentia est causa omnis peccati. Sed concupiscentia est alia passio ab amore, ut supra habitum est. Ergo amor sui non est causa omnis peccati.

###### arg. 3
Praeterea, Augustinus, super illud Psalmi, incensa igni et suffossa, dicit quod omne peccatum est *ex amore male inflammante, vel ex timore male humiliante*. Non ergo solus amor sui est causa peccati.

###### arg. 4
Praeterea, sicut homo quandoque peccat propter inordinatum sui amorem, ita etiam interdum peccat propter inordinatum amorem proximi. Ergo amor sui non est causa omnis peccati.

###### s. c.
Sed contra est quod Augustinus dicit, XIV de Civ. Dei, quod *amor sui usque ad contemptum Dei, facit civitatem Babylonis*. Sed per quodlibet peccatum pertinet homo ad civitatem Babylonis. Ergo amor sui est causa omnis peccati.

###### co.
Respondeo dicendum quod, sicut supra dictum est, propria et per se causa peccati accipienda est ex parte conversionis ad commutabile bonum; ex qua quidem parte omnis actus peccati procedit ex aliquo inordinato appetitu alicuius temporalis boni. Quod autem aliquis appetat inordinate aliquod temporale bonum, procedit ex hoc quod inordinate amat seipsum, hoc enim est amare aliquem, velle ei bonum. Unde manifestum est quod inordinatus amor sui est causa omnis peccati.

###### ad 1
Ad primum ergo dicendum quod amor sui ordinatus est debitus et naturalis, ita scilicet quod velit sibi bonum quod congruit. Sed amor sui inordinatus, qui perducit ad contemptum Dei, ponitur esse causa peccati secundum Augustinum.

###### ad 2
Ad secundum dicendum quod concupiscentia, qua aliquis appetit sibi bonum, reducitur ad amorem sui sicut ad causam, ut iam dictum est.

###### ad 3
Ad tertium dicendum quod aliquis dicitur amare et illud bonum quod optat sibi, et se, cui bonum optat. Amor igitur secundum quod dicitur eius esse quod optatur, puta quod aliquis dicitur amare vinum vel pecuniam, recipit pro causa timorem, qui pertinet ad fugam mali. Omne enim peccatum provenit vel ex inordinato appetitu alicuius boni, vel ex inordinata fuga alicuius mali. Sed utrumque horum reducitur ad amorem sui. Propter hoc enim homo vel appetit bona vel fugit mala, quia amat seipsum.

###### ad 4
Ad quartum dicendum quod amicus est quasi alter ipse. Et ideo quod peccatur propter amorem amici, videtur propter amorem sui peccari.

