### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod peccatum quod est ex passione, non debeat dici ex infirmitate. Passio enim est quidam vehemens motus appetitus sensitivi, ut dictum est. Vehementia autem motus magis attestatur fortitudini quam infirmitati. Ergo peccatum quod est ex passione, non debet dici ex infirmitate.

###### arg. 2
Praeterea, infirmitas hominis maxime attenditur secundum illud quod est in eo fragilius. Hoc autem est caro, unde dicitur in Psalmo LXXVII, *recordatus est quia caro sunt*. Ergo magis debet dici peccatum ex infirmitate quod est ex aliquo corporis defectu, quam quod est ex animae passione.

###### arg. 3
Praeterea, ad ea non videtur homo esse infirmus, quae eius voluntati subduntur. Sed facere vel non facere ea ad quae passio inclinat, hominis voluntati subditur, secundum illud [[Gn 4]], *sub te erit appetitus tuus, et tu dominaberis illius*. Ergo peccatum quod est ex passione, non est ex infirmitate.

###### s. c.
Sed contra est quod Tullius, in IV libro de Tuscul. quaest., passiones animae aegritudines vocat. Aegritudines autem alio nomine infirmitates dicuntur. Ergo peccatum quod est ex passione, debet dici ex infirmitate.

###### co.
Respondeo dicendum quod causa peccati propria est ex parte animae in qua principaliter est peccatum. Potest autem dici infirmitas in anima ad similitudinem infirmitatis corporis. Dicitur autem corpus hominis esse infirmum, quando debilitatur vel impeditur in executione propriae operationis, propter aliquam inordinationem partium corporis, ita scilicet quod humores et membra hominis non subduntur virtuti regitivae et motivae corporis. Unde et membrum dicitur esse infirmum, quando non potest perficere operationem membri sani, sicut oculus quando non potest clare videre, ut dicit philosophus, in X de historiis animalium. Unde et infirmitas animae dicitur quando impeditur anima in propria operatione, propter inordinationem partium ipsius. Sicut autem partes corporis dicuntur esse inordinatae, quando non sequuntur ordinem naturae; ita et partes animae dicuntur inordinatae, quando non subduntur ordini rationis, ratio enim est vis regitiva partium animae. Sic ergo quando extra ordinem rationis vis concupiscibilis aut irascibilis aliqua passione afficitur, et per hoc impedimentum praestatur modo praedicto debitae actioni hominis, dicitur peccatum esse ex infirmitate. Unde et philosophus, in I Ethic., comparat incontinentem paralytico, cuius partes moventur in contrarium eius quod ipse disponit.

###### ad 1
Ad primum ergo dicendum quod, sicut quanto fuerit motus fortior in corpore praeter ordinem naturae, tanto est maior infirmitas; ita quanto fuerit motus fortior passionis praeter ordinem rationis, tanto est maior infirmitas animae.

###### ad 2
Ad secundum dicendum quod peccatum principaliter consistit in actu voluntatis, qui non impeditur per corporis infirmitatem, potest enim qui est corpore infirmus, promptam habere voluntatem ad aliquid faciendum. Impeditur autem per passionem, ut supra dictum est. Unde cum dicitur peccatum esse ex infirmitate, magis est referendum ad infirmitatem animae quam ad infirmitatem corporis. Dicitur tamen etiam ipsa infirmitas animae infirmitas carnis, inquantum ex conditione carnis passiones animae insurgunt in nobis, eo quod appetitus sensitivus est virtus utens organo corporali.

###### ad 3
Ad tertium dicendum quod in potestate quidem voluntatis est assentire vel non assentire his in quae passio inclinat, et pro tanto dicitur noster appetitus sub nobis esse. Sed tamen ipse assensus vel dissensus voluntatis impeditur per passionem, modo praedicto.

