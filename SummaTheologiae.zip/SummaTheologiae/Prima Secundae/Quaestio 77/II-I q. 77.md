## Quaestio 77

### Prooemium

Deinde considerandum est de causa peccati ex parte appetitus sensitivi, utrum passio animae sit causa peccati. Et circa hoc quaeruntur octo. Primo, utrum passio appetitus sensitivi possit movere vel inclinare voluntatem. Secundo, utrum possit superare rationem contra eius scientiam. Tertio, utrum peccatum quod ex passione provenit, sit peccatum ex infirmitate. Quarto, utrum haec passio quae est amor sui, sit causa omnis peccati. Quinto, de illis tribus causis quae ponuntur I Ioan. II, *concupiscentia oculorum, concupiscentia carnis, et superbia vitae*. Sexto, utrum passio quae est causa peccati, diminuat ipsum. Septimo, utrum totaliter excuset. Octavo, utrum peccatum quod ex passione est, possit esse mortale.

![[II-I q. 77 a. 1#Articulus 1]]

![[II-I q. 77 a. 2#Articulus 2]]

![[II-I q. 77 a. 3#Articulus 3]]

![[II-I q. 77 a. 4#Articulus 4]]

![[II-I q. 77 a. 5#Articulus 5]]

![[II-I q. 77 a. 6#Articulus 6]]

![[II-I q. 77 a. 7#Articulus 7]]

![[II-I q. 77 a. 8#Articulus 8]]

