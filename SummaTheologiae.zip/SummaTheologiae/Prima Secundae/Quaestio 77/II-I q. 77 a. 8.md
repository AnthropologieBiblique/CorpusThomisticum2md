### Articulus 8

###### arg. 1
Ad octavum sic proceditur. Videtur quod peccatum quod est ex passione, non possit esse mortale. Veniale enim peccatum dividitur contra mortale. Sed peccatum quod est ex infirmitate, est veniale, cum habeat in se causam veniae. Cum igitur peccatum quod est ex passione, sit ex infirmitate, videtur quod non possit esse mortale.

###### arg. 2
Praeterea, causa non est potior effectu. Sed passio non potest esse peccatum mortale, non enim in sensualitate est peccatum mortale, ut supra habitum est. Ergo peccatum quod est ex passione, non potest esse mortale.

###### arg. 3
Praeterea, passio abducit a ratione, ut ex dictis patet. Sed rationis est converti ad Deum vel averti ab eo, in quo consistit ratio peccati mortalis. Peccatum ergo quod est ex passione, non potest esse mortale.

###### s. c.
Sed contra est quod apostolus dicit, [[Rm 7]], quod *passiones peccatorum operantur in membris nostris ad fructificandum morti*. Hoc autem est proprium mortalis peccati, quod fructificet morti. Ergo peccatum quod est ex passione, potest esse mortale.

###### co.
Respondeo dicendum quod peccatum mortale, ut supra dictum est, consistit in aversione ab ultimo fine, qui est Deus, quae quidem aversio pertinet ad rationem deliberantem, cuius etiam est ordinare in finem. Hoc igitur solo modo potest contingere quod inclinatio animae in aliquid quod contrariatur ultimo fini, non sit peccatum mortale quia ratio deliberans non potest occurrere, quod contingit in subitis motibus. Cum autem ex passione aliquis procedit ad actum peccati, vel ad consensum deliberatum, hoc non fit subito. Unde ratio deliberans potest hic occurrere, potest enim excludere, vel saltem impedire passionem, ut dictum est. Unde si non occurrat, est peccatum mortale, sicut videmus quod multa homicidia et adulteria per passionem committuntur.

###### ad 1
Ad primum ergo dicendum quod veniale dicitur tripliciter. Uno modo, ex causa, quia scilicet habet aliquam causam veniae, quae diminuit peccatum, et sic peccatum ex infirmitate et ignorantia dicitur veniale. Alio modo, ex eventu, sicut omne peccatum per poenitentiam fit veniale, idest veniam consecutum. Tertio modo dicitur veniale ex genere, sicut verbum otiosum. Et hoc solum veniale opponitur mortali, obiectio autem procedit de primo.

###### ad 2
Ad secundum dicendum quod passio est causa peccati ex parte conversionis. Quod autem sit mortale, est ex parte aversionis, quae per accidens sequitur ad conversionem, ut dictum est. Unde ratio non sequitur.

###### ad 3
Ad tertium dicendum quod ratio non semper in suo actu totaliter a passione impeditur, unde remanet ei liberum arbitrium, ut possit averti vel converti ad Deum. Si autem totaliter tolleretur usus rationis, iam non esset peccatum nec mortale nec veniale.

