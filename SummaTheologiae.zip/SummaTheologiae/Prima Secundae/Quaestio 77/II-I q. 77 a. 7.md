### Articulus 7

###### arg. 1
Ad septimum sic proceditur. Videtur quod passio totaliter excuset a peccato. Quidquid enim causat involuntarium, excusat totaliter a peccato. Sed concupiscentia carnis, quae est quaedam passio, causat involuntarium, secundum illud [[Ga 5]], *caro concupiscit adversus spiritum, ut non quaecumque vultis, illa faciatis*. Ergo passio totaliter excusat a peccato.

###### arg. 2
Praeterea, passio causat ignorantiam quandam in particulari, ut dictum est. Sed ignorantia particularis totaliter excusat a peccato, sicut supra habitum est. Ergo passio totaliter excusat a peccato.

###### arg. 3
Praeterea, infirmitas animae gravior est quam infirmitas corporis. Sed infirmitas corporis totaliter excusat a peccato, ut patet in phreneticis. Ergo multo magis passio, quae est infirmitas animae.

###### s. c.
Sed contra est quod apostolus, [[Rm 7]], vocat passiones peccatorum, non nisi quia peccata causant. Quod non esset, si a peccato totaliter excusarent. Ergo passiones non totaliter a peccato excusant.

###### co.
Respondeo dicendum quod secundum hoc solum actus aliquis qui de genere suo est malus, totaliter a peccato excusatur, quod totaliter involuntarius redditur. Unde si sit talis passio quae totaliter involuntarium reddat actum sequentem, totaliter a peccato excusat, alioquin, non totaliter. Circa quod duo consideranda videntur. Primo quidem, quod aliquid potest esse voluntarium vel secundum se, sicut quando voluntas directe in ipsum fertur, vel secundum suam causam, quando voluntas fertur in causam et non in effectum, ut patet in eo qui voluntarie inebriatur; ex hoc enim quasi voluntarium ei imputatur quod per ebrietatem committit. Secundo considerandum est quod aliquid dicitur voluntarium directe, vel indirecte, directe quidem, id in quod voluntas fertur; indirecte autem, illud quod voluntas potuit prohibere, sed non prohibet. Secundum hoc igitur distinguendum est. Quia passio quandoque quidem est tanta quod totaliter aufert usum rationis, sicut patet in his qui propter amorem vel iram insaniunt. Et tunc si talis passio a principio fuit voluntaria, imputatur actus ad peccatum, quia est voluntarius in sua causa, sicut etiam de ebrietate dictum est. Si vero causa non fuit voluntaria, sed naturalis, puta cum aliquis ex aegritudine, vel aliqua huiusmodi causa, incidit in talem passionem quae totaliter aufert usum rationis; actus omnino redditur involuntarius, et per consequens totaliter a peccato excusatur. Quandoque vero passio non est tanta quod totaliter intercipiat usum rationis. Et tunc ratio potest passionem excludere, divertendo ad alias cogitationes; vel impedire ne suum consequatur effectum, quia membra non applicantur operi nisi per consensum rationis, ut supra dictum est. Unde talis passio non totaliter excusat a peccato.

###### ad 1
Ad primum ergo dicendum quod hoc quod dicitur, *ut non quaecumque vultis, illa faciatis*, non est referendum ad ea quae fiunt per exteriorem actum, sed ad interiorem concupiscentiae motum, vellet enim homo nunquam concupiscere malum. Sicut etiam exponitur id quod dicitur [[Rm 7]], quod *odi malum, illud facio*. Vel potest referri ad voluntatem praecedentem passionem, ut patet in continentibus qui contra suum propositum agunt propter suam concupiscentiam.

###### ad 2
Ad secundum dicendum quod ignorantia particularis quae totaliter excusat, est ignorantia circumstantiae quam quidem quis scire non potest, debita diligentia adhibita. Sed passio causat ignorantiam iuris in particulari, dum impedit applicationem communis scientiae ad particularem actum. Quam quidem passionem ratio repellere potest, ut dictum est.

###### ad 3
Ad tertium dicendum quod infirmitas corporis est involuntaria. Esset autem simile, si esset voluntaria, sicut de ebrietate dictum est, quae est quaedam corporalis infirmitas.

