## Quaestio 22

### Prooemium

Post hoc considerandum est de passionibus animae, et primo, in generali; secundo, in speciali. In generali autem, quatuor occurrunt circa eas consideranda, primo quidem, de subiecto earum; secundo, de differentia earum; tertio, de comparatione earum ad invicem; quarto, de malitia et bonitate ipsarum. Circa primum quaeruntur tria. Primo, utrum aliqua passio sit in anima. Secundo, utrum magis in parte appetitiva quam in apprehensiva. Tertio, utrum magis sit in appetitu sensitivo quam intellectivo, qui dicitur voluntas.

![[II-I q. 22 a. 1#Articulus 1]]

![[II-I q. 22 a. 2#Articulus 2]]

![[II-I q. 22 a. 3#Articulus 3]]

