### Articulus 7

###### arg. 1
Ad septimum sic proceditur. Videtur quod non omnium hominum sit unus finis ultimus. Maxime enim videtur hominis ultimus finis esse incommutabile bonum. Sed quidam avertuntur ab incommutabili bono, peccando. Non ergo omnium hominum est unus ultimus finis.

###### arg. 2
Praeterea, secundum ultimum finem tota vita hominis regulatur. Si igitur esset unus ultimus finis omnium hominum, sequeretur quod in hominibus non essent diversa studia vivendi. Quod patet esse falsum.

###### arg. 3
Praeterea, finis est actionis terminus. Actiones autem sunt singularium. Homines autem, etsi conveniant in natura speciei, tamen differunt secundum ea quae ad individua pertinent. Non ergo omnium hominum est unus ultimus finis.

###### s. c.
Sed contra est quod Augustinus dicit, XIII de Trin., quod omnes homines conveniunt in appetendo ultimum finem, qui est beatitudo.

###### co.
Respondeo dicendum quod de ultimo fine possumus loqui dupliciter, uno modo, secundum rationem ultimi finis; alio modo, secundum id in quo finis ultimi ratio invenitur. Quantum igitur ad rationem ultimi finis, omnes conveniunt in appetitu finis ultimi, quia omnes appetunt suam perfectionem adimpleri, quae est ratio ultimi finis, ut dictum est. Sed quantum ad id in quo ista ratio invenitur, non omnes homines conveniunt in ultimo fine, nam quidam appetunt divitias tanquam consummatum bonum, quidam autem voluptatem, quidam vero quodcumque aliud. Sicut et omni gustui delectabile est dulce, sed quibusdam maxime delectabilis est dulcedo vini, quibusdam dulcedo mellis, aut alicuius talium. Illud tamen dulce oportet esse simpliciter melius delectabile, in quo maxime delectatur qui habet optimum gustum. Et similiter illud bonum oportet esse completissimum, quod tanquam ultimum finem appetit habens affectum bene dispositum.

###### ad 1
Ad primum ergo dicendum quod illi qui peccant, avertuntur ab eo in quo vere invenitur ratio ultimi finis, non autem ab ipsa ultimi finis intentione, quam quaerunt falso in aliis rebus.

###### ad 2
Ad secundum dicendum quod diversa studia vivendi contingunt in hominibus propter diversas res in quibus quaeritur ratio summi boni.

###### ad 3
Ad tertium dicendum quod, etsi actiones sint singularium, tamen primum principium agendi in eis est natura, quae tendit ad unum, ut dictum est.

