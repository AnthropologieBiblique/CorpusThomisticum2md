### Articulus 8

###### arg. 1
Ad octavum sic proceditur. Videtur quod in ultimo fine hominis etiam omnia alia conveniant. Finis enim respondet principio. Sed illud quod est principium hominum, scilicet Deus, est etiam principium omnium aliorum. Ergo in ultimo fine hominis omnia alia communicant.

###### arg. 2
Praeterea, Dionysius dicit, in libro de Div. Nom., quod *Deus convertit omnia ad seipsum, tanquam ad ultimum finem*. Sed ipse est etiam ultimus finis hominis, quia solo ipso fruendum est, ut Augustinus dicit. Ergo in fine ultimo hominis etiam alia conveniunt.

###### arg. 3
Praeterea, finis ultimus hominis est obiectum voluntatis. Sed obiectum voluntatis est bonum universale, quod est finis omnium. Ergo necesse est quod in ultimo fine hominis omnia conveniant.

###### s. c.
Sed contra est quod ultimus finis hominum est beatitudo; quam omnes appetunt, ut Augustinus dicit. *Sed non cadit in animalia rationis expertia ut beata sint*, sicut Augustinus dicit in libro octoginta trium quaest. Non ergo in ultimo fine hominis alia conveniunt.

###### co.
Respondeo dicendum quod, sicut philosophus dicit in II Physic. et in V Metaphys., finis dupliciter dicitur, scilicet cuius, et quo, idest ipsa res in qua ratio boni invenitur, et usus sive adeptio illius rei. Sicut si dicamus quod motus corporis gravis finis est vel locus inferior ut res, vel hoc quod est esse in loco inferiori, ut usus, et finis avari est vel pecunia ut res, vel possessio pecuniae ut usus. Si ergo loquamur de ultimo fine hominis quantum ad ipsam rem quae est finis, sic in ultimo fine hominis omnia alia conveniunt, quia Deus est ultimus finis hominis et omnium aliarum rerum. Si autem loquamur de ultimo fine hominis quantum ad consecutionem finis, sic in hoc fine hominis non communicant creaturae irrationales. Nam homo et aliae rationales creaturae consequuntur ultimum finem cognoscendo et amando Deum, quod non competit aliis creaturis, quae adipiscuntur ultimum finem inquantum participant aliquam similitudinem Dei, secundum quod sunt, vel vivunt, vel etiam cognoscunt.

###### ad 
Et per hoc patet responsio ad obiecta.

