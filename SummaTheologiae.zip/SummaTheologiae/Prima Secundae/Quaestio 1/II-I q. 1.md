## Quaestio 1

### Prooemium

Ubi primo considerandum occurrit de ultimo fine humanae vitae; et deinde de his per quae homo ad hunc finem pervenire potest, vel ab eo deviare, ex fine enim oportet accipere rationes eorum quae ordinantur ad finem. Et quia ultimus finis humanae vitae ponitur esse beatitudo, oportet primo considerare de ultimo fine in communi; deinde de beatitudine. Circa primum quaeruntur octo. Primo, utrum hominis sit agere propter finem. Secundo, utrum hoc sit proprium rationalis naturae. Tertio, utrum actus hominis recipiant speciem a fine. Quarto, utrum sit aliquis ultimus finis humanae vitae. Quinto, utrum unius hominis possint esse plures ultimi fines. Sexto, utrum homo ordinet omnia in ultimum finem. Septimo, utrum idem sit finis ultimus omnium hominum. Octavo, utrum in illo ultimo fine omnes aliae creaturae conveniant.

![[II-I q. 1 a. 1#Articulus 1]]

![[II-I q. 1 a. 2#Articulus 2]]

![[II-I q. 1 a. 3#Articulus 3]]

![[II-I q. 1 a. 4#Articulus 4]]

![[II-I q. 1 a. 5#Articulus 5]]

![[II-I q. 1 a. 6#Articulus 6]]

![[II-I q. 1 a. 7#Articulus 7]]

![[II-I q. 1 a. 8#Articulus 8]]

