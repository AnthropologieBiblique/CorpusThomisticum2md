### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod voluntas de necessitate moveatur a suo obiecto. Obiectum enim voluntatis comparatur ad ipsam sicut motivum ad mobile, ut patet in III de anima. Sed motivum, si sit sufficiens, ex necessitate movet mobile. Ergo voluntas ex necessitate potest moveri a suo obiecto.

###### arg. 2
Praeterea, sicut voluntas est vis immaterialis, ita et intellectus, et utraque potentia ad obiectum universale ordinatur, ut dictum est. Sed intellectus ex necessitate movetur a suo obiecto. Ergo et voluntas a suo.

###### arg. 3
Praeterea, omne quod quis vult, aut est finis, aut aliquid ordinatum ad finem. Sed finem aliquis ex necessitate vult, ut videtur, quia est sicut principium in speculativis, cui ex necessitate assentimus. Finis autem est ratio volendi ea quae sunt ad finem, et sic videtur quod etiam ea quae sunt ad finem, ex necessitate velimus. Voluntas ergo ex necessitate movetur a suo obiecto.

###### s. c.
Sed contra est quod potentiae rationales, secundum philosophum, sunt ad opposita. Sed voluntas est potentia rationalis, est enim in ratione, ut dicitur in III de anima. Ergo voluntas se habet ad opposita. Non ergo ex necessitate movetur ad alterum oppositorum.

###### co.
Respondeo dicendum quod voluntas movetur dupliciter, uno modo, quantum ad exercitium actus; alio modo, quantum ad specificationem actus, quae est ex obiecto. Primo ergo modo, voluntas a nullo obiecto ex necessitate movetur, potest enim aliquis de quocumque obiecto non cogitare, et per consequens neque actu velle illud. Sed quantum ad secundum motionis modum, voluntas ab aliquo obiecto ex necessitate movetur, ab aliquo autem non. In motu enim cuiuslibet potentiae a suo obiecto, consideranda est ratio per quam obiectum movet potentiam. Visibile enim movet visum sub ratione coloris actu visibilis. Unde si color proponatur visui, ex necessitate movet visum, nisi aliquis visum avertat, quod pertinet ad exercitium actus. Si autem proponeretur aliquid visui quod non omnibus modis esset color in actu, sed secundum aliquid esset tale, secundum autem aliquid non tale, non ex necessitate visus tale obiectum videret, posset enim intendere in ipsum ex ea parte qua non est coloratum in actu, et sic ipsum non videret. Sicut autem coloratum in actu est obiectum visus, ita bonum est obiectum voluntatis. Unde si proponatur aliquod obiectum voluntati quod sit universaliter bonum et secundum omnem considerationem, ex necessitate voluntas in illud tendet, si aliquid velit, non enim poterit velle oppositum. Si autem proponatur sibi aliquod obiectum quod non secundum quamlibet considerationem sit bonum, non ex necessitate voluntas feretur in illud. Et quia defectus cuiuscumque boni habet rationem non boni, ideo illud solum bonum quod est perfectum et cui nihil deficit, est tale bonum quod voluntas non potest non velle, quod est beatitudo. Alia autem quaelibet particularia bona, inquantum deficiunt ab aliquo bono, possunt accipi ut non bona, et secundum hanc considerationem, possunt repudiari vel approbari a voluntate, quae potest in idem ferri secundum diversas considerationes.

###### ad 1
Ad primum ergo dicendum quod sufficiens motivum alicuius potentiae non est nisi obiectum quod totaliter habet rationem motivi. Si autem in aliquo deficiat, non ex necessitate movebit, ut dictum est.

###### ad 2
Ad secundum dicendum quod intellectus ex necessitate movetur a tali obiecto quod est semper et ex necessitate verum, non autem ab eo quod potest esse verum et falsum, scilicet a contingenti, sicut et de bono dictum est.

###### ad 3
Ad tertium dicendum quod finis ultimus ex necessitate movet voluntatem, quia est bonum perfectum. Et similiter illa quae ordinantur ad hunc finem, sine quibus finis haberi non potest, sicut esse et vivere et huiusmodi. Alia vero, sine quibus finis haberi potest, non ex necessitate vult qui vult finem, sicut conclusiones sine quibus principia possunt esse vera, non ex necessitate credit qui credit principia.

