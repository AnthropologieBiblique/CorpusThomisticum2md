### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod voluntas ex necessitate moveatur a Deo. Omne enim agens cui resisti non potest, ex necessitate movet. Sed Deo, cum sit infinitae virtutis, resisti non potest, unde dicitur [[Rm 9]], *voluntati eius quis resistit?* Ergo Deus ex necessitate movet voluntatem.

###### arg. 2
Praeterea, voluntas ex necessitate movetur in illa quae naturaliter vult, ut dictum est. *Sed hoc est unicuique rei naturale, quod Deus in ea operatur*, ut Augustinus dicit, XXVI contra Faustum. Ergo voluntas ex necessitate vult omne illud ad quod a Deo movetur.

###### arg. 3
Praeterea, possibile est quo posito non sequitur impossibile. Sequitur autem impossibile, si ponatur quod voluntas non velit hoc ad quod Deus eam movet, quia secundum hoc, operatio Dei esset inefficax. Non ergo est possibile voluntatem non velle hoc ad quod Deus eam movet. Ergo necesse est eam hoc velle.

###### s. c.
Sed contra est quod dicitur [[Si 15]], *Deus ab initio constituit hominem, et reliquit eum in manu consilii sui*. Non ergo ex necessitate movet voluntatem eius.

###### co.
Respondeo dicendum quod, sicut Dionysius dicit, IV cap. de Div. Nom., *ad providentiam divinam non pertinet naturam rerum corrumpere, sed servare*. Unde omnia movet secundum eorum conditionem, ita quod ex causis necessariis per motionem divinam consequuntur effectus ex necessitate; ex causis autem contingentibus sequuntur effectus contingenter. Quia igitur voluntas est activum principium non determinatum ad unum, sed indifferenter se habens ad multa, sic Deus ipsam movet, quod non ex necessitate ad unum determinat, sed remanet motus eius contingens et non necessarius, nisi in his ad quae naturaliter movetur.

###### ad 1
Ad primum ergo dicendum quod voluntas divina non solum se extendit ut aliquid fiat per rem quam movet, sed ut etiam eo modo fiat quo congruit naturae ipsius. Et ideo magis repugnaret divinae motioni, si voluntas ex necessitate moveretur, quod suae naturae non competit; quam si moveretur libere, prout competit suae naturae.

###### ad 2
Ad secundum dicendum quod naturale est unicuique quod Deus operatur in ipso ut sit ei naturale, sic enim unicuique convenit aliquid, secundum quod Deus vult quod ei conveniat. Non autem vult quod quidquid operatur in rebus, sit eis naturale, puta quod mortui resurgant. Sed hoc vult unicuique esse naturale, quod potestati divinae subdatur.

###### ad 3
Ad tertium dicendum quod, si Deus movet voluntatem ad aliquid, incompossibile est huic positioni quod voluntas ad illud non moveatur. Non tamen est impossibile simpliciter. Unde non sequitur quod voluntas a Deo ex necessitate moveatur.

