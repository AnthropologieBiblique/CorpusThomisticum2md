## Quaestio 10

### Prooemium

Deinde considerandum est de modo quo voluntas movetur. Et circa hoc quaeruntur quatuor. Primo, utrum voluntas ad aliquid naturaliter moveatur. Secundo, utrum de necessitate moveatur a suo obiecto. Tertio, utrum de necessitate moveatur ab appetitu inferiori. Quarto, utrum de necessitate moveatur ab exteriori motivo quod est Deus.

![[II-I q. 10 a. 1#Articulus 1]]

![[II-I q. 10 a. 2#Articulus 2]]

![[II-I q. 10 a. 3#Articulus 3]]

![[II-I q. 10 a. 4#Articulus 4]]

