### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod spes maneat post mortem in statu gloriae. Spes enim nobiliori modo perficit appetitum humanum quam virtutes morales. Sed virtutes morales manent post hanc vitam, ut patet per Augustinum, in XIV de Trin. Ergo multo magis spes.

###### arg. 2
Praeterea, spei opponitur timor. Sed timor manet post hanc vitam, et in beatis quidem timor filialis, qui manet in saeculum; et in damnatis timor poenarum. Ergo spes, pari ratione, potest permanere.

###### arg. 3
Praeterea, sicut spes est futuri boni, ita et desiderium. Sed in beatis est desiderium futuri boni, et quantum ad gloriam corporis, quam animae beatorum desiderant, ut dicit Augustinus, XII super Gen. ad Litt.; et etiam quantum ad gloriam animae, secundum illud [[Si 24]], *qui edunt me, adhuc esurient, et qui bibunt me, adhuc sitient*; et I Petr. I, dicitur, *in quem desiderant Angeli prospicere*. Ergo videtur quod possit esse spes post hanc vitam in beatis.

###### s. c.
Sed contra est quod apostolus dicit, [[Rm 8]], *quod videt quis, quid sperat?* Sed beati vident id quod est obiectum spei, scilicet Deum. Ergo non sperant.

###### co.
Respondeo dicendum quod, sicut dictum est, id quod de ratione sui importat imperfectionem subiecti, non potest simul stare cum subiecto opposita perfectione perfecto. Sicut patet quod motus in ratione sui importat imperfectionem subiecti, est enim actus existentis in potentia, inquantum huiusmodi, unde quando illa potentia reducitur ad actum, iam cessat motus; non enim adhuc albatur, postquam iam aliquid factum est album. Spes autem importat motum quendam in id quod non habetur; ut patet ex his quae supra de passione spei diximus. Et ideo quando habebitur id quod speratur, scilicet divina fruitio, iam spes esse non poterit.

###### ad 1
Ad primum ergo dicendum quod spes est nobilior virtutibus moralibus quantum ad obiectum, quod est Deus. Sed actus virtutum moralium non repugnant perfectioni beatitudinis, sicut actus spei; nisi forte ratione materiae, secundum quam non manent. Non enim virtus moralis perficit appetitum solum in id quod nondum habetur; sed etiam circa id quod praesentialiter habetur.

###### ad 2
Ad secundum dicendum quod timor est duplex, servilis et filialis, ut infra dicetur. Servilis quidem est timor poenae, qui non poterit esse in gloria, nulla possibilitate ad poenam remanente. Timor vero filialis habet duos actus, scilicet revereri Deum, et quantum ad hunc actum manet; et timere separationem ab ipso, et quantum ad hunc actum non manet. Separari enim a Deo habet rationem mali, nullum autem malum ibi timebitur, secundum illud Proverb. I, *abundantia perfruetur, malorum timore sublato*. Timor autem opponitur spei oppositione boni et mali, ut supra dictum est, et ideo timor qui remanet in gloria, non opponitur spei. In damnatis autem magis potest esse timor poenae, quam in beatis spes gloriae. Quia in damnatis erit successio poenarum, et sic remanet ibi ratio futuri, quod est obiectum timoris, sed gloria sanctorum est absque successione, secundum quandam aeternitatis participationem, in qua non est praeteritum et futurum, sed solum praesens. Et tamen nec etiam in damnatis est proprie timor. Nam sicut supra dictum est, timor nunquam est sine aliqua spe evasionis, quae omnino in damnatis non erit. Unde nec timor; nisi communiter loquendo, secundum quod quaelibet expectatio mali futuri dicitur timor.

###### ad 3
Ad tertium dicendum quod quantum ad gloriam animae, non potest esse in beatis desiderium, secundum quod respicit futurum, ratione iam dicta. Dicitur autem ibi esse esuries et sitis, per remotionem fastidii, et eadem ratione dicitur esse desiderium in Angelis. Respectu autem gloriae corporis, in animabus sanctorum potest quidem esse desiderium, non tamen spes, proprie loquendo, neque secundum quod spes est virtus theologica, sic enim eius obiectum est Deus, non autem aliquod bonum creatum; neque secundum quod communiter sumitur. Quia obiectum spei est arduum, ut supra dictum est, bonum autem cuius iam inevitabilem causam habemus, non comparatur ad nos in ratione ardui. Unde non proprie dicitur aliquis qui habet argentum, sperare se habiturum aliquid quod statim in potestate eius est ut emat. Et similiter illi qui habent gloriam animae, non proprie dicuntur sperare gloriam corporis; sed solum desiderare.

