### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod caritas non maneat post hanc vitam in gloria. Quia, ut dicitur I ad Cor. XIII, *cum venerit quod perfectum est, evacuabitur quod ex parte est*, idest quod est imperfectum. Sed caritas viae est imperfecta. Ergo evacuabitur, adveniente perfectione gloriae.

###### arg. 2
Praeterea, habitus et actus distinguuntur secundum obiecta. Sed obiectum amoris est bonum apprehensum. Cum ergo alia sit apprehensio praesentis vitae, et alia apprehensio futurae vitae; videtur quod non maneat eadem caritas utrobique.

###### arg. 3
Praeterea, eorum quae sunt unius rationis, imperfectum potest venire ad aequalitatem perfectionis, per continuum augmentum. Sed caritas viae nunquam potest pervenire ad aequalitatem caritatis patriae, quantumcumque augeatur. Ergo videtur quod caritas viae non remaneat in patria.

###### s. c.
Sed contra est quod apostolus dicit, I ad Cor. XIII, *caritas nunquam excidit*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, quando imperfectio alicuius rei non est de ratione speciei ipsius, nihil prohibet idem numero quod prius fuit imperfectum, postea perfectum esse, sicut homo per augmentum perficitur, et albedo per intensionem. Caritas autem est amor; de cuius ratione non est aliqua imperfectio, potest enim esse et habiti et non habiti, et visi et non visi. Unde caritas non evacuatur per gloriae perfectionem, sed eadem numero manet.

###### ad 1
Ad primum ergo dicendum quod imperfectio caritatis per accidens se habet ad ipsam, quia non est de ratione amoris imperfectio. Remoto autem eo quod est per accidens, nihilominus remanet substantia rei. Unde, evacuata imperfectione caritatis, non evacuatur ipsa caritas.

###### ad 2
Ad secundum dicendum quod caritas non habet pro obiecto ipsam cognitionem, sic enim non esset eadem in via et in patria. Sed habet pro obiecto ipsam rem cognitam, quae est eadem, scilicet ipsum Deum.

###### ad 3
Ad tertium dicendum quod caritas viae per augmentum non potest pervenire ad aequalitatem caritatis patriae, propter differentiam quae est ex parte causae, visio enim est quaedam causa amoris, ut dicitur in IX Ethic. Deus autem quanto perfectius cognoscitur, tanto perfectius amatur.

