### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod omnis passio animae habeat aliquid contrarium. Omnis enim passio animae vel est in irascibili vel in concupiscibili, sicut supra dictum est. Sed utraeque passiones habent contrarietatem suo modo. Ergo omnis passio animae habet contrarium.

###### arg. 2
Praeterea, omnis passio animae habet vel bonum vel malum pro obiecto, quae sunt obiecta universaliter appetitivae partis. Sed passioni cuius obiectum est bonum, opponitur passio cuius obiectum est malum. Ergo omnis passio habet contrarium.

###### arg. 3
Praeterea, omnis passio animae est secundum accessum vel secundum recessum, ut dictum est. Sed cuilibet accessui contrariatur recessus, et e converso. Ergo omnis passio animae habet contrarium.

###### s. c.
Sed contra, ira est quaedam passio animae. Sed nulla passio ponitur contraria irae, ut patet in IV Ethic. Ergo non omnis passio habet contrarium.

###### co.
Respondeo dicendum quod singulare est in passione irae, quod non potest habere contrarium, neque secundum accessum et recessum, neque secundum contrarietatem boni et mali. Causatur enim ira ex malo difficili iam iniacente. Ad cuius praesentiam, necesse est quod aut appetitus succumbat, et sic non exit terminos tristitiae, quae est passio concupiscibilis, aut habet motum ad invadendum malum laesivum, quod pertinet ad iram. Motum autem ad fugiendum habere non potest, quia iam malum ponitur praesens vel praeteritum. Et sic motui irae non contrariatur aliqua passio secundum contrarietatem accessus et recessus. Similiter etiam nec secundum contrarietatem boni et mali. Quia malo iam iniacenti opponitur bonum iam adeptum, quod iam non potest habere rationem ardui vel difficilis. Nec post adeptionem boni remanet alius motus, nisi quietatio appetitus in bono adepto, quae pertinet ad gaudium, quod est passio concupiscibilis. Unde motus irae non potest habere aliquem motum animae contrarium, sed solummodo opponitur ei cessatio a motu, sicut philosophus dicit, in sua rhetorica, quod *mitescere opponitur ei quod est irasci*, quod non est oppositum contrarie, sed negative vel privative.

###### ad 
Et per hoc patet responsio ad obiecta.

