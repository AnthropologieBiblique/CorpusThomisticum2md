## Quaestio 23

### Prooemium

Deinde considerandum est de passionum differentia ad invicem. Et circa hoc quaeruntur quatuor. Primo, utrum passiones quae sunt in concupiscibili, sint diversae ab his quae sunt in irascibili. Secundo, utrum contrarietas passionum irascibili sit secundum contrarietatem boni et mali. Tertio, utrum sit aliqua passio non habens contrarium. Quarto, utrum sint aliquae passiones differentes specie, in eadem potentia, non contrariae ad invicem.

![[II-I q. 23 a. 1#Articulus 1]]

![[II-I q. 23 a. 2#Articulus 2]]

![[II-I q. 23 a. 3#Articulus 3]]

![[II-I q. 23 a. 4#Articulus 4]]

