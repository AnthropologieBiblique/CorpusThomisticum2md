## Quaestio 103

### Prooemium

Deinde considerandum est de duratione caeremonialium praeceptorum. Et circa hoc quaeruntur quatuor. Primo, utrum praecepta caeremonialia fuerint ante legem. Secundo, utrum in lege aliquam virtutem habuerint iustificandi. Tertio, utrum cessaverint Christo veniente. Quarto, utrum sit peccatum mortale observare ea post Christum.

![[II-I q. 103 a. 1#Articulus 1]]

![[II-I q. 103 a. 2#Articulus 2]]

![[II-I q. 103 a. 3#Articulus 3]]

![[II-I q. 103 a. 4#Articulus 4]]

