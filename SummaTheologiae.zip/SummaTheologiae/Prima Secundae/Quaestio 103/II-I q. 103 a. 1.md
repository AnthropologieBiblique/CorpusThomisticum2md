### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod caeremoniae legis fuerint ante legem. Sacrificia enim et holocausta pertinent ad caeremonias veteris legis, ut supra dictum est. Sed sacrificia et holocausta fuerunt ante legem. Dicitur enim [[Gn 4]], quod *Cain obtulit de fructibus terrae munera domino; Abel autem obtulit de primogenitis gregis sui, et de adipibus eorum*. Noe etiam obtulit holocausta domino, ut dicitur [[Gn 4]]; et Abraham similiter, ut dicitur [[Gn 4]]. Ergo caeremoniae veteris legis fuerunt ante legem.

###### arg. 2
Praeterea, ad caeremonias sacrorum pertinet constructio altaris, et eius inunctio. Sed ista fuerunt ante legem. Legitur enim [[Gn 13]], quod Abraham aedificavit altare domino; et de Iacob dicitur [[Gn 13]], quod *tulit lapidem et erexit in titulum fundens oleum desuper*. Ergo caeremoniae legales fuerunt ante legem.

###### arg. 3
Praeterea, inter sacramenta legalia primum videtur fuisse circumcisio. Sed circumcisio fuit ante legem, ut patet [[Gn 17]]. Similiter etiam sacerdotium fuit ante legem, dicitur enim [[Gn 17]], quod Melchisedech erat sacerdos Dei summi. Ergo caeremoniae sacramentorum fuerunt ante legem.

###### arg. 4
Praeterea, discretio mundorum animalium ab immundis pertinet ad caeremonias observantiarum, ut supra dictum est. Sed talis discretio fuit ante legem, dicitur enim [[Gn 7]], *ex omnibus mundis animalibus tolle septena et septena; de animantibus vero immundis, duo et duo*. Ergo caeremoniae legales fuerunt ante legem.

###### s. c.
Sed contra est quod dicitur [[Dt 6]], *haec sunt praecepta et caeremoniae quae mandavit dominus Deus vester ut docerem vos*. Non autem indiguissent super his doceri, si prius praedictae caeremoniae fuissent. Ergo caeremoniae legis non fuerunt ante legem.

###### co.
Respondeo dicendum quod, sicut ex dictis patet, caeremoniae legis ad duo ordinabantur, scilicet ad cultum Dei, et ad figurandum Christum. Quicumque autem colit Deum, oportet quod per aliqua determinata eum colat, quae ad exteriorem cultum pertinent. Determinatio autem divini cultus ad caeremonias pertinet; sicut etiam determinatio eorum per quae ordinamur ad proximum, pertinet ad praecepta iudicialia; ut supra dictum est. Et ideo sicut inter homines communiter erant aliqua iudicialia, non tamen ex auctoritate legis divinae instituta, sed ratione hominum ordinata; ita etiam erant quaedam caeremoniae, non quidem ex auctoritate alicuius legis determinatae, sed solum secundum voluntatem et devotionem hominum Deum colentium. Sed quia etiam ante legem fuerunt quidam viri praecipui prophetico spiritu pollentes, credendum est quod ex instinctu divino, quasi ex quadam privata lege, inducerentur ad aliquem certum modum colendi Deum, qui et conveniens esset interiori cultui, et etiam congrueret ad significandum Christi mysteria, quae figurabantur etiam per alia eorum gesta, secundum illud I ad Cor. X, *omnia in figuram contingebant illis*. Fuerunt igitur ante legem quaedam caeremoniae, non tamen caeremoniae legis, quia non erant per aliquam legislationem institutae.

###### ad 1
Ad primum ergo dicendum quod huiusmodi oblationes et sacrificia et holocausta offerebant antiqui ante legem ex quadam devotione propriae voluntatis, secundum quod eis videbatur conveniens ut in rebus quas a Deo acceperant, quas in reverentiam divinam offerrent, protestarentur se colere Deum, qui est omnium principium et finis.

###### ad 2
Ad secundum dicendum quod etiam sacra quaedam instituerunt, quia videbatur eis conveniens ut in reverentiam divinam essent aliqua loca ab aliis discreta, divino cultui mancipata.

###### ad 3
Ad tertium dicendum quod sacramentum circumcisionis praecepto divino fuit statutum ante legem. Unde non potest dici sacramentum legis quasi in lege institutum, sed solum quasi in lege observatum. Et hoc est quod dominus dicit, [[Jn 7]], *circumcisio non ex Moyse est, sed ex patribus eius*. Sacerdotium etiam erat ante legem apud colentes Deum, secundum humanam determinationem, quia hanc dignitatem primogenitis attribuebant.

###### ad 4
Ad quartum dicendum quod distinctio mundorum animalium et immundorum non fuit ante legem quantum ad esum, cum dictum sit [[Gn 9]], *omne quod movetur et vivit, erit vobis in cibum*, sed solum quantum ad sacrificiorum oblationem, quia de quibusdam determinatis animalibus sacrificia offerebant. Si tamen quantum ad esum erat aliqua discretio animalium, hoc non erat quia esus illorum reputaretur illicitus, cum nulla lege esset prohibitus, sed propter abominationem vel consuetudinem, sicut et nunc videmus quod aliqua cibaria sunt in aliquibus terris abominabilia, quae in aliis comeduntur.

