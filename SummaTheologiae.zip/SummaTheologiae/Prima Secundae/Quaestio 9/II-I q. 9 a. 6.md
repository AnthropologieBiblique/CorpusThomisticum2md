### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod voluntas non a solo Deo moveatur sicut ab exteriori principio. Inferius enim natum est moveri a suo superiori, sicut corpora inferiora a corporibus caelestibus. Sed voluntas hominis habet aliquid superius post Deum; scilicet Angelum. Ergo voluntas hominis potest moveri, sicut ab exteriori principio, etiam ab Angelo.

###### arg. 2
Praeterea, actus voluntatis sequitur actum intellectus. Sed intellectus hominis reducitur in suum actum non solum a Deo, sed etiam ab Angelo per illuminationes, ut Dionysius dicit. Ergo eadem ratione et voluntas.

###### arg. 3
Praeterea, Deus non est causa nisi bonorum; secundum illud [[Gn 1]], *vidit Deus cuncta quae fecerat, et erant valde bona*. Si ergo a solo Deo voluntas hominis moveretur, nunquam moveretur ad malum, cum tamen voluntas sit qua peccatur et recte vivitur, ut Augustinus dicit.

###### s. c.
Sed contra est quod apostolus dicit, ad [[Ph 2]], *Deus est qui operatur in nobis velle et perficere*.

###### co.
Respondeo dicendum quod motus voluntatis est ab intrinseco, sicut et motus naturalis. Quamvis autem rem naturalem possit aliquid movere quod non est causa naturae rei motae, tamen motum naturalem causare non potest nisi quod est aliqualiter causa naturae. Movetur enim lapis sursum ab homine, qui naturam lapidis non causat, sed hic motus non est lapidi naturalis, naturalis autem motus eius non causatur nisi ab eo quod causat naturam. Unde dicitur in VIII Physic. quod generans movet secundum locum gravia et levia. Sic ergo hominem, voluntatem habentem, contingit moveri ab aliquo qui non est causa eius, sed quod motus voluntarius eius sit ab aliquo principio extrinseco quod non est causa voluntatis, est impossibile. Voluntatis autem causa nihil aliud esse potest quam Deus. Et hoc patet dupliciter. Primo quidem, ex hoc quod voluntas est potentia animae rationalis, quae a solo Deo causatur per creationem, ut in primo dictum est. Secundo vero ex hoc patet, quod voluntas habet ordinem ad universale bonum. Unde nihil aliud potest esse voluntatis causa, nisi ipse Deus, qui est universale bonum. Omne autem aliud bonum per participationem dicitur, et est quoddam particulare bonum, particularis autem causa non dat inclinationem universalem. Unde nec materia prima, quae est in potentia ad omnes formas, potest causari ab aliquo particulari agente.

###### ad 1
Ad primum ergo dicendum quod Angelus non sic est supra hominem, quod sit causa voluntatis eius; sicut corpora caelestia sunt causa formarum naturalium, ad quas consequuntur naturales motus corporum naturalium.

###### ad 2
Ad secundum dicendum quod intellectus hominis movetur ab Angelo ex parte obiecti, quod sibi proponitur virtute angelici luminis ad cognoscendum. Et sic etiam voluntas ab exteriori creatura potest moveri, ut dictum est.

###### ad 3
Ad tertium dicendum quod Deus movet voluntatem hominis, sicut universalis motor, ad universale obiectum voluntatis, quod est bonum. Et sine hac universali motione homo non potest aliquid velle. Sed homo per rationem determinat se ad volendum hoc vel illud, quod est vere bonum vel apparens bonum. Sed tamen interdum specialiter Deus movet aliquos ad aliquid determinate volendum, quod est bonum, sicut in his quos movet per gratiam, ut infra dicetur.

