## Quaestio 9

### Prooemium

Deinde considerandum est de motivo voluntatis. Et circa hoc quaeruntur sex. Primo, utrum voluntas moveatur ab intellectu. Secundo, utrum moveatur ab appetitu sensitivo. Tertio, utrum voluntas moveat seipsam. Quarto, utrum moveatur ab aliquo exteriori principio. Quinto, utrum moveatur a corpore caelesti. Sexto, utrum voluntas moveatur a solo Deo, sicut ab exteriori principio.

![[II-I q. 9 a. 1#Articulus 1]]

![[II-I q. 9 a. 2#Articulus 2]]

![[II-I q. 9 a. 3#Articulus 3]]

![[II-I q. 9 a. 4#Articulus 4]]

![[II-I q. 9 a. 5#Articulus 5]]

![[II-I q. 9 a. 6#Articulus 6]]

