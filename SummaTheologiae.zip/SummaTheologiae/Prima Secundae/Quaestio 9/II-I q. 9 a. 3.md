### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod voluntas non moveat seipsam. Omne enim movens, inquantum huiusmodi, est in actu, quod autem movetur, est in potentia, nam motus est actus existentis in potentia, inquantum huiusmodi. Sed non est idem in potentia et in actu respectu eiusdem. Ergo nihil movet seipsum. Neque ergo voluntas seipsam movere potest.

###### arg. 2
Praeterea, mobile movetur ad praesentiam moventis. Sed voluntas semper sibi est praesens. Si ergo ipsa seipsam moveret, semper moveretur. Quod patet esse falsum.

###### arg. 3
Praeterea, voluntas movetur ab intellectu, ut dictum est. Si igitur voluntas movet seipsam, sequitur quod idem simul moveatur a duobus motoribus immediate, quod videtur inconveniens. Non ergo voluntas movet seipsam.

###### s. c.
Sed contra est quia voluntas domina est sui actus, et in ipsa est velle et non velle. Quod non esset, si non haberet in potestate movere seipsam ad volendum. Ergo ipsa movet seipsam.

###### co.
Respondeo dicendum quod, sicut supra dictum est, ad voluntatem pertinet movere alias potentias ex ratione finis, qui est voluntatis obiectum. Sed sicut dictum est, hoc modo se habet finis in appetibilibus, sicut principium in intelligibilibus. Manifestum est autem quod intellectus per hoc quod cognoscit principium, reducit seipsum de potentia in actum, quantum ad cognitionem conclusionum, et hoc modo movet seipsum. Et similiter voluntas per hoc quod vult finem, movet seipsam ad volendum ea quae sunt ad finem.

###### ad 1
Ad primum ergo dicendum quod voluntas non secundum idem movet et movetur. Unde nec secundum idem est in actu et in potentia. Sed inquantum actu vult finem, reducit se de potentia in actum respectu eorum quae sunt ad finem, ut scilicet actu ea velit.

###### ad 2
Ad secundum dicendum quod potentia voluntatis semper actu est sibi praesens, sed actus voluntatis, quo vult finem aliquem, non semper est in ipsa voluntate. Per hunc autem movet seipsam. Unde non sequitur quod semper seipsam moveat.

###### ad 3
Ad tertium dicendum quod non eodem modo voluntas movetur ab intellectu, et a seipsa. Sed ab intellectu quidem movetur secundum rationem obiecti, a seipsa vero, quantum ad exercitium actus, secundum rationem finis.

