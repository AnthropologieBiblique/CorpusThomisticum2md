### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod voluntas non moveatur ab aliquo exteriori. Motus enim voluntatis est voluntarius. Sed de ratione voluntarii est quod sit a principio intrinseco, sicut et de ratione naturalis. Non ergo motus voluntatis est ab aliquo extrinseco.

###### arg. 2
Praeterea, voluntas violentiam pati non potest, ut supra ostensum est. Sed violentum est cuius principium est extra. Ergo voluntas non potest ab aliquo exteriori moveri.

###### arg. 3
Praeterea, quod sufficienter movetur ab uno motore, non indiget moveri ab alio. Sed voluntas sufficienter movet seipsam. Non ergo movetur ab aliquo exteriori.

###### s. c.
Sed contra, voluntas movetur ab obiecto, ut dictum est. Sed obiectum voluntatis potest esse aliqua exterior res sensui proposita. Ergo voluntas potest ab aliquo exteriori moveri.

###### co.
Respondeo dicendum quod, secundum quod voluntas movetur ab obiecto, manifestum est quod moveri potest ab aliquo exteriori. Sed eo modo quo movetur quantum ad exercitium actus, adhuc necesse est ponere voluntatem ab aliquo principio exteriori moveri. Omne enim quod quandoque est agens in actu et quandoque in potentia, indiget moveri ab aliquo movente. Manifestum est autem quod voluntas incipit velle aliquid, cum hoc prius non vellet. Necesse est ergo quod ab aliquo moveatur ad volendum. Et quidem, sicut dictum est, ipsa movet seipsam, inquantum per hoc quod vult finem, reducit seipsam ad volendum ea quae sunt ad finem. Hoc autem non potest facere nisi consilio mediante, cum enim aliquis vult sanari, incipit cogitare quomodo hoc consequi possit, et per talem cogitationem pervenit ad hoc quod potest sanari per medicum, et hoc vult. Sed quia non semper sanitatem actu voluit, necesse est quod inciperet velle sanari, aliquo movente. Et si quidem ipsa moveret seipsam ad volendum, oportuisset quod mediante consilio hoc ageret, ex aliqua voluntate praesupposita. Hoc autem non est procedere in infinitum. Unde necesse est ponere quod in primum motum voluntatis voluntas prodeat ex instinctu alicuius exterioris moventis, ut Aristoteles concludit in quodam capitulo Ethicae Eudemicae.

###### ad 1
Ad primum ergo dicendum quod de ratione voluntarii est quod principium eius sit intra, sed non oportet quod hoc principium intrinsecum sit primum principium non motum ab alio. Unde motus voluntarius etsi habeat principium proximum intrinsecum, tamen principium primum est ab extra. Sicut et primum principium motus naturalis est ab extra, quod scilicet movet naturam.

###### ad 2
Ad secundum dicendum quod hoc non sufficit ad rationem violenti, quod principium sit extra, sed oportet addere quod nil conferat vim patiens. Quod non contingit, dum voluntas ab exteriori movetur, nam ipsa est quae vult, ab alio tamen mota. Esset autem motus iste violentus, si esset contrarius motui voluntatis. Quod in proposito esse non potest, quia sic idem vellet et non vellet.

###### ad 3
Ad tertium dicendum quod voluntas quantum ad aliquid sufficienter se movet, et in suo ordine, scilicet sicut agens proximum, sed non potest seipsam movere quantum ad omnia, ut ostensum est. Unde indiget moveri ab alio sicut a primo movente.

