### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod peccatum non habeat causam interiorem. Id enim quod est interius alicui rei, semper adest ei. Si igitur peccatum habeat causam interiorem, semper homo peccaret, cum, posita causa, ponatur effectus.

###### arg. 2
Praeterea, idem non est causa sui ipsius. Sed interiores motus hominis sunt peccatum. Ergo non sunt causa peccati.

###### arg. 3
Praeterea, quidquid est intra hominem, aut est naturale, aut voluntarium. Sed id quod est naturale, non potest esse peccati causa, quia peccatum est contra naturam, ut dicit Damascenus. Quod autem est voluntarium, si sit inordinatum, iam est peccatum. Non ergo aliquid intrinsecum potest esse causa primi peccati.

###### s. c.
Sed contra est quod Augustinus dicit, quod voluntas est causa peccati.

###### co.
Respondeo dicendum quod, sicut iam dictum est, per se causam peccati oportet accipere ex parte ipsius actus. Actus autem humani potest accipi causa interior et mediata, et immediata. Immediata quidem causa humani actus est ratio et voluntas, secundum quam homo est liber arbitrio. Causa autem remota est apprehensio sensitivae partis, et etiam appetitus sensitivus, sicut enim ex iudicio rationis voluntas movetur ad aliquid secundum rationem, ita etiam ex apprehensione sensus appetitus sensitivus in aliquid inclinatur. Quae quidem inclinatio interdum trahit voluntatem et rationem, sicut infra patebit. Sic igitur duplex causa peccati interior potest assignari, una proxima, ex parte rationis et voluntatis; alia vero remota, ex parte imaginationis vel appetitus sensitivi. Sed quia supra dictum est quod causa peccati est aliquod bonum apparens motivum cum defectu debiti motivi, scilicet regulae rationis vel legis divinae; ipsum motivum quod est apparens bonum, pertinet ad apprehensionem sensus et appetitum. Ipsa autem absentia debitae regulae pertinet ad rationem, quae nata est huiusmodi regulam considerare. Sed ipsa perfectio voluntarii actus peccati pertinet ad voluntatem, ita quod ipse voluntatis actus, praemissis suppositis, iam est quoddam peccatum.

###### ad 1
Ad primum ergo dicendum quod id quod est intrinsecum sicut potentia naturalis, semper inest, id autem quod est intrinsecum sicut actus interior appetitivae vel apprehensivae virtutis, non semper inest. Ipsa autem potentia voluntatis est causa peccati in potentia, sed reducitur in actum per motus praecedentes et sensitivae partis primo, et rationis consequenter. Ex hoc enim quod aliquid proponitur ut appetibile secundum sensum et appetitus sensitivus inclinatur in illud, ratio interdum cessat a consideratione regulae debitae, et sic voluntas producit actum peccati. Quia igitur motus praecedentes non semper sunt in actu, neque peccatum semper est in actu.

###### ad 2
Ad secundum dicendum quod non omnes motus interiores sunt de substantia peccati, quod consistit principaliter in actu voluntatis, sed quidam praecedunt, et quidam consequuntur ipsum peccatum.

###### ad 3
Ad tertium dicendum quod illud quod est causa peccati sicut potentia producens actum, est naturale. Motus etiam sensitivae partis, ex quo sequitur peccatum, interdum est naturalis, sicut cum propter appetitum cibi aliquis peccat. Sed efficitur peccatum innaturale ex hoc ipso quod deficit regula naturalis, quam homo secundum naturam suam debet attendere.

