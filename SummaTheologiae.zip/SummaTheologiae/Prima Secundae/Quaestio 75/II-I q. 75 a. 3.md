### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod peccatum non habeat causam exteriorem. Peccatum enim est actus voluntarius. Voluntaria autem sunt eorum quae sunt in nobis; et ita non habent exteriorem causam. Ergo peccatum non habet exteriorem causam.

###### arg. 2
Praeterea, sicut natura est principium interius, ita etiam voluntas. Sed peccatum in rebus naturalibus nunquam accidit nisi ex aliqua interiori causa, ut puta monstruosi partus proveniunt ex corruptione alicuius principii interioris. Ergo neque in moralibus potest contingere peccatum nisi ex interiori causa. Non ergo habet peccatum causam exteriorem.

###### arg. 3
Praeterea, multiplicata causa, multiplicatur effectus. Sed quanto plura sunt et maiora exterius inducentia ad peccandum, tanto minus id quod quis inordinate agit, ei imputatur ad peccatum. Ergo nihil exterius est causa peccati.

###### s. c.
Sed contra est quod dicitur [[Nb 31]], *nonne istae sunt quae deceperunt filios Israel, et praevaricari vos fecerunt in domino super peccato Phogor?* Ergo aliquid exterius potest esse causa faciens peccare.

###### co.
Respondeo dicendum quod, sicut supra dictum est, causa interior peccati est et voluntas, ut perficiens actum peccati; et ratio, quantum ad carentiam debitae regulae; et appetitus sensitivus inclinans. Sic ergo aliquid extrinsecum tripliciter posset esse causa peccati, vel quia moveret immediate ipsam voluntatem; vel quia moveret rationem; vel quia moveret appetitum sensitivum. Voluntatem autem, ut supra dictum est, interius movere non potest nisi Deus; qui non potest esse causa peccati, ut infra ostendetur. Unde relinquitur quod nihil exterius potest esse causa peccati, nisi vel inquantum movet rationem, sicut homo vel Daemon persuadens peccatum; vel sicut movens appetitum sensitivum, sicut aliqua sensibilia exteriora movent appetitum sensitivum. Sed neque persuasio exterior in rebus agendis ex necessitate movet rationem; neque etiam res exterius propositae ex necessitate movent appetitum sensitivum, nisi forte aliquo modo dispositum; et tamen etiam appetitus sensitivus non ex necessitate movet rationem et voluntatem. Unde aliquid exterius potest esse aliqua causa movens ad peccandum, non tamen sufficienter ad peccatum inducens, sed causa sufficienter complens peccatum est sola voluntas.

###### ad 1
Ad primum ergo dicendum quod ex hoc ipso quod exteriora moventia ad peccandum non sufficienter et ex necessitate inducunt, sequitur quod remaneat in nobis peccare et non peccare.

###### ad 2
Ad secundum dicendum quod per hoc quod ponitur interior causa peccati, non excluditur exterior, non enim id quod est exterius est causa peccati, nisi mediante causa interiori, ut dictum est.

###### ad 3
Ad tertium dicendum quod, multiplicatis exterioribus causis inclinantibus ad peccandum, multiplicantur actus peccati, quia plures ex illis causis, et pluries, inclinantur ad actus peccati. Sed tamen minuitur ratio culpae, quae consistit in hoc quod aliquid sit voluntarium et in nobis.

