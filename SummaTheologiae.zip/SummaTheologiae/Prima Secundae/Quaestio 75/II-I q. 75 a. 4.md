### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod peccatum non sit causa peccati. Sunt enim quatuor genera causarum, quorum nullum potest ad hoc congruere quod peccatum sit causa peccati. Finis enim habet rationem boni, quod non competit peccato, quod de sua ratione est malum. Et eadem ratione nec peccatum potest esse causa efficiens, quia malum non est causa agens, sed est infirmum et impotens, ut Dionysius dicit, IV cap. de Div. Nom. Causa autem materialis et formalis videntur habere solum locum in naturalibus corporibus quae sunt composita ex materia et forma. Ergo peccatum non potest habere causam materialem et formalem.

###### arg. 2
Praeterea, agere sibi simile est rei perfectae, ut dicitur in IV Meteor. Sed peccatum de sui ratione est imperfectum. Ergo peccatum non potest esse causa peccati.

###### arg. 3
Praeterea, si huius peccati sit causa aliud peccatum, eadem ratione et illius erit causa aliquod aliud peccatum, et sic procedetur in infinitum, quod est inconveniens. Non ergo peccatum est causa peccati.

###### s. c.
Sed contra est quod Gregorius dicit, super Ezech., *peccatum quod per poenitentiam citius non deletur, peccatum est et causa peccati*.

###### co.
Respondeo dicendum quod, cum peccatum habeat causam ex parte actus, hoc modo unum peccatum posset esse causa alterius, sicut unus actus humanus potest esse causa alterius. Contingit igitur unum peccatum esse causam alterius secundum quatuor genera causarum. Primo quidem, secundum modum causae efficientis vel moventis, et per se et per accidens. Per accidens quidem, sicut removens prohibens dicitur movens per accidens, cum enim per unum actum peccati homo amittit gratiam, vel caritatem, vel verecundiam, vel quodcumque aliud retrahens a peccato, incidit ex hoc in aliud peccatum; et sic primum peccatum est causa secundi per accidens. Per se autem, sicut cum ex uno actu peccati homo disponitur ad hoc quod alium actum consimilem facilius committit, ex actibus enim causantur dispositiones et habitus inclinantes ad similes actus. Secundum vero genus causae materialis, unum peccatum est causa alterius, inquantum praeparat ei materiam, sicut avaritia praeparat materiam litigio, quod plerumque est de divitiis congregatis. Secundum vero genus causae finalis, unum peccatum est causa alterius, inquantum propter finem unius peccati aliquis committit aliud peccatum, sicut cum aliquis committit simoniam propter finem ambitionis, vel fornicationem propter furtum. Et quia finis dat formam in moralibus, ut supra habitum est, ex hoc etiam sequitur quod unum peccatum sit formalis causa alterius, in actu enim fornicationis quae propter furtum committitur, est quidem fornicatio sicut materiale, furtum vero sicut formale.

###### ad 1
Ad primum ergo dicendum quod peccatum, inquantum est inordinatum, habet rationem mali, sed inquantum est actus quidam, habet aliquod bonum, saltem apparens, pro fine. Et ita ex parte actus potest esse causa et finalis et effectiva alterius peccati, licet non ex parte inordinationis. Materiam autem habet peccatum non ex qua, sed circa quam. Formam autem habet ex fine. Et ideo secundum quatuor genera causarum peccatum potest dici causa peccati, ut dictum est.

###### ad 2
Ad secundum dicendum quod peccatum est imperfectum imperfectione morali ex parte inordinationis, sed ex parte actus potest habere perfectionem naturae. Et secundum hoc potest esse causa peccati.

###### ad 3
Ad tertium dicendum quod non omnis causa peccati est peccatum. Unde non oportet quod procedatur in infinitum; sed potest perveniri ad aliquod primum peccatum, cuius causa non est aliud peccatum.

