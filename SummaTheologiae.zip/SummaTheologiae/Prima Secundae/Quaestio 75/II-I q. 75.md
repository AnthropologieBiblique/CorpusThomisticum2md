## Quaestio 75

### Prooemium

Deinde considerandum est de causis peccatorum. Et primo, in generali; secundo, in speciali. Circa primum quaeruntur quatuor. Primo, utrum peccatum habeat causam. Secundo, utrum habeat causam interiorem. Tertio, utrum habeat causam exteriorem. Quarto, utrum peccatum sit causa peccati.

![[II-I q. 75 a. 1#Articulus 1]]

![[II-I q. 75 a. 2#Articulus 2]]

![[II-I q. 75 a. 3#Articulus 3]]

![[II-I q. 75 a. 4#Articulus 4]]

