### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod peccatum non habeat causam. Peccatum enim habet rationem mali, ut dictum est. Sed malum non habet causam, ut Dionysius dicit, IV cap. de Div. Nom. Ergo peccatum non habet causam.

###### arg. 2
Praeterea, causa est ad quam de necessitate sequitur aliud. Sed quod est ex necessitate, non videtur esse peccatum, eo quod omne peccatum est voluntarium. Ergo peccatum non habet causam.

###### arg. 3
Praeterea, si peccatum habet causam, aut habet pro causa bonum, aut malum. Non autem bonum, quia bonum non facit nisi bonum; *non enim potest arbor bona fructus malos facere*, ut dicitur [[Mt 7]] similiter autem nec malum potest esse causa peccati, quia malum poenae sequitur ad peccatum; malum autem culpae est idem quod peccatum. Peccatum igitur non habet causam.

###### s. c.
Sed contra, omne quod fit, habet causam, quia, ut dicitur [[Jb 5]], nihil in terra sine causa fit. Sed peccatum fit, est enim dictum vel factum vel concupitum contra legem Dei. Ergo peccatum habet causam.

###### co.
Respondeo dicendum quod peccatum est quidam actus inordinatus. Ex parte igitur actus, potest habere per se causam, sicut et quilibet alius actus. Ex parte autem inordinationis, habet causam eo modo quo negatio vel privatio potest habere causam. Negationis autem alicuius potest duplex causa assignari. Primo quidem, defectus causae, idest ipsius causae negatio, est causa negationis secundum seipsam, ad remotionem enim causae sequitur remotio effectus; sicut obscuritatis causa est absentia solis. Alio modo, causa affirmationis ad quam sequitur negatio, est per accidens causa negationis consequentis, sicut ignis, causando calorem ex principali intentione, consequenter causat privationem frigiditatis. Quorum primum potest sufficere ad simplicem negationem. Sed cum inordinatio peccati, et quodlibet malum, non sit simplex negatio, sed privatio eius quod quid natum est et debet habere; necesse est quod talis inordinatio habeat causam agentem per accidens, quod enim natum est inesse et debet, nunquam abesset nisi propter causam aliquam impedientem. Et secundum hoc consuevit dici quod malum, quod in quadam privatione consistit, habet causam deficientem, vel agentem per accidens. Omnis autem causa per accidens reducitur ad causam per se. Cum igitur peccatum ex parte inordinationis habeat causam agentem per accidens, ex parte autem actus habeat causam agentem per se; sequitur quod inordinatio peccati consequatur ex ipsa causa actus. Sic igitur voluntas carens directione regulae rationis et legis divinae, intendens aliquod bonum commutabile, causat actum quidem peccati per se, sed inordinationem actus per accidens et praeter intentionem, provenit enim defectus ordinis in actu, ex defectu directionis in voluntate.

###### ad 1
Ad primum ergo dicendum quod peccatum non solum significat ipsam privationem boni, quae est inordinatio; sed significat actum sub tali privatione, quae habet rationem mali. Quod quidem qualiter habeat causam, dictum est.

###### ad 2
Ad secundum dicendum quod, si illa definitio causae universaliter debeat verificari, oportet ut intelligatur de causa sufficienti et non impedita. Contingit enim aliquid esse causam sufficientem alterius, et tamen non ex necessitate sequitur effectus, propter aliquod impedimentum superveniens, alioquin sequeretur quod omnia ex necessitate contingerent, ut patet in VI Metaphys. Sic igitur, etsi peccatum habeat causam, non tamen sequitur quod sit necessaria, quia effectus potest impediri.

###### ad 3
Ad tertium dicendum quod, sicut dictum est, voluntas sine adhibitione regulae rationis vel legis divinae, est causa peccati. Hoc autem quod est non adhibere regulam rationis vel legis divinae, secundum se non habet rationem mali, nec poenae nec culpae, antequam applicetur ad actum. Unde secundum hoc, peccati primi non est causa aliquod malum, sed bonum aliquod cum absentia alicuius alterius boni.

