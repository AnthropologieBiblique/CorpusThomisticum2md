### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod ars non sit virtus intellectualis. Dicit enim Augustinus, in libro de libero arbitrio, quod virtute nullus male utitur. Sed arte aliquis male utitur, potest enim aliquis artifex, secundum scientiam artis suae, male operari. Ergo ars non est virtus.

###### arg. 2
Praeterea, virtutis non est virtus. Artis autem est aliqua virtus, ut dicitur in VI Ethic. Ergo ars non est virtus.

###### arg. 3
Praeterea, artes liberales sunt excellentiores quam artes mechanicae. Sed sicut artes mechanicae sunt practicae, ita artes liberales sunt speculativae. Ergo si ars esset virtus intellectualis, deberet virtutibus speculativis annumerari.

###### s. c.
Sed contra est quod philosophus, in VI Ethic., ponit artem esse virtutem; nec tamen connumerat eam virtutibus speculativis, quarum subiectum ponit scientificam partem animae.

###### co.
Respondeo dicendum quod ars nihil aliud est quam ratio recta aliquorum operum faciendorum. Quorum tamen bonum non consistit in eo quod appetitus humanus aliquo modo se habet, sed in eo quod ipsum opus quod fit, in se bonum est. Non enim pertinet ad laudem artificis, inquantum artifex est, qua voluntate opus faciat; sed quale sit opus quod facit. Sic igitur ars, proprie loquendo, habitus operativus est. Et tamen in aliquo convenit cum habitibus speculativis, quia etiam ad ipsos habitus speculativos pertinet qualiter se habeat res quam considerant, non autem qualiter se habeat appetitus humanus ad illas. Dummodo enim verum geometra demonstret, non refert qualiter se habeat secundum appetitivam partem, utrum sit laetus vel iratus, sicut nec in artifice refert, ut dictum est. Et ideo eo modo ars habet rationem virtutis, sicut et habitus speculativi, inquantum scilicet nec ars, nec habitus speculativus, faciunt bonum opus quantum ad usum, quod est proprium virtutis perficientis appetitum; sed solum quantum ad facultatem bene agendi.

###### ad 1
Ad primum ergo dicendum quod, cum aliquis habens artem operatur malum artificium, hoc non est opus artis, immo est contra artem, sicut etiam cum aliquis sciens verum mentitur, hoc quod dicit non est secundum scientiam, sed contra scientiam. Unde sicut scientia se habet semper ad bonum, ut dictum est, ita et ars, et secundum hoc dicitur virtus. In hoc tamen deficit a perfecta ratione virtutis, quia non facit ipsum bonum usum, sed ad hoc aliquid aliud requiritur, quamvis bonus usus sine arte esse non possit.

###### ad 2
Ad secundum dicendum quod, quia ad hoc ut homo bene utatur arte quam habet, requiritur bona voluntas, quae perficitur per virtutem moralem; ideo philosophus dicit quod artis est virtus, scilicet moralis, inquantum ad bonum usum eius aliqua virtus moralis requiritur. Manifestum est enim quod artifex per iustitiam, quae facit voluntatem rectam, inclinatur ut opus fidele faciat.

###### ad 3
Ad tertium dicendum quod etiam in ipsis speculabilibus est aliquid per modum cuiusdam operis, puta constructio syllogismi aut orationis congruae aut opus numerandi vel mensurandi. Et ideo quicumque ad huiusmodi opera rationis habitus speculativi ordinantur, dicuntur per quandam similitudinem artes, sed liberales; ad differentiam illarum artium quae ordinantur ad opera per corpus exercita, quae sunt quodammodo serviles, inquantum corpus serviliter subditur animae, et homo secundum animam est liber. Illae vero scientiae quae ad nullum huiusmodi opus ordinantur, simpliciter scientiae dicuntur, non autem artes. Nec oportet, si liberales artes sunt nobiliores, quod magis eis conveniat ratio artis.

