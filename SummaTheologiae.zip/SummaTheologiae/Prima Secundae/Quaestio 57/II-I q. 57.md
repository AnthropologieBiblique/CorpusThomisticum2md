## Quaestio 57

### Prooemium

Deinde considerandum est de distinctione virtutum. Et primo, quantum ad virtutes intellectuales; secundo, quantum ad morales; tertio, quantum ad theologicas. Circa primum quaeruntur sex. Primo, utrum habitus intellectuales speculativi sint virtutes. Secundo, utrum sint tres, scilicet sapientia, scientia et intellectus. Tertio, utrum habitus intellectualis qui est ars, sit virtus. Quarto, utrum prudentia sit virtus distincta ab arte. Quinto, utrum prudentia sit virtus necessaria homini. Sexto, utrum eubulia, synesis et gnome sint virtutes adiunctae prudentiae.

![[II-I q. 57 a. 1#Articulus 1]]

![[II-I q. 57 a. 2#Articulus 2]]

![[II-I q. 57 a. 3#Articulus 3]]

![[II-I q. 57 a. 4#Articulus 4]]

![[II-I q. 57 a. 5#Articulus 5]]

![[II-I q. 57 a. 6#Articulus 6]]

