## Quaestio 84

### Prooemium

Deinde considerandum est de causa peccati secundum quod unum peccatum est causa alterius. Et circa hoc quaeruntur quatuor. Primo, utrum cupiditas sit radix omnium peccatorum. Secundo, utrum superbia sit initium omnis peccati. Tertio, utrum praeter superbiam et avaritiam, debeant dici capitalia vitia aliqua specialia peccata. Quarto, quot et quae sint capitalia vitia.

![[II-I q. 84 a. 1#Articulus 1]]

![[II-I q. 84 a. 2#Articulus 2]]

![[II-I q. 84 a. 3#Articulus 3]]

