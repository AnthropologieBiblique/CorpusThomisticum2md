## Quaestio 32

### Prooemium

Deinde considerandum est de causis delectationis. Et circa hoc quaeruntur octo. Primo, utrum operatio sit causa propria delectationis. Secundo, utrum motus sit causa delectationis. Tertio, utrum spes et memoria. Quarto, utrum tristitia. Quinto, utrum actiones aliorum sint nobis delectationis causa. Sexto, utrum benefacere alteri sit causa delectationis. Septimo, utrum similitudo sit causa delectationis. Octavo, utrum admiratio sit causa delectationis.

![[II-I q. 32 a. 1#Articulus 1]]

![[II-I q. 32 a. 2#Articulus 2]]

![[II-I q. 32 a. 3#Articulus 3]]

![[II-I q. 32 a. 4#Articulus 4]]

![[II-I q. 32 a. 5#Articulus 5]]

![[II-I q. 32 a. 6#Articulus 6]]

![[II-I q. 32 a. 7#Articulus 7]]

![[II-I q. 32 a. 8#Articulus 8]]

