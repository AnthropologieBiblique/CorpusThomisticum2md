### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod tristitia non sit causa delectationis. Contrarium enim non est causa contrarii. Sed tristitia contrariatur delectationi. Ergo non est causa delectationis.

###### arg. 2
Praeterea, contrariorum contrarii sunt effectus. Sed delectabilia memorata sunt causa delectationis. Ergo tristia memorata sunt causa doloris, et non delectationis.

###### arg. 3
Praeterea, sicut se habet tristitia ad delectationem, ita odium ad amorem. Sed odium non est causa amoris, sed magis e converso, ut supra dictum est. Ergo tristitia non est causa delectationis.

###### s. c.
Sed contra est quod in Psalmo XLI, dicitur, *fuerunt mihi lacrimae meae panes die ac nocte*. Per panem autem refectio delectationis intelligitur. Ergo lacrimae, quae ex tristitia oriuntur, possunt esse delectabiles.

###### co.
Respondeo dicendum quod tristitia potest dupliciter considerari, uno modo, secundum quod est in actu; alio modo, secundum quod est in memoria. Et utroque modo tristitia potest esse delectationis causa. Tristitia siquidem in actu existens est causa delectationis, inquantum facit memoriam rei dilectae, de cuius absentia aliquis tristatur, et tamen de sola eius apprehensione delectatur. Memoria autem tristitiae fit causa delectationis, propter subsequentem evasionem. Nam carere malo accipitur in ratione boni, unde secundum quod homo apprehendit se evasisse ab aliquibus tristibus et dolorosis, accrescit ei gaudii materia; secundum quod Augustinus dicit, XXII de Civ. Dei, quod *saepe laeti tristium meminimus, et sani dolorum sine dolore, et inde amplius laeti et grati sumus*. Et in VIII Confess. dicit quod *quanto maius fuit periculum in proelio, tanto maius erit gaudium in triumpho*.

###### ad 1
Ad primum ergo dicendum quod contrarium quandoque per accidens est causa contrarii, sicut frigidum quandoque calefacit, ut dicitur in VIII Physic. Et similiter tristitia per accidens est delectationis causa, inquantum fit per eam apprehensio alicuius delectabilis.

###### ad 2
Ad secundum dicendum quod tristia memorata, inquantum sunt tristia et delectabilibus contraria, non causant delectationem, sed inquantum ab eis homo liberatur. Et similiter memoria delectabilium, ex eo quod sunt amissa, potest causare tristitiam.

###### ad 3
Ad tertium dicendum quod odium etiam per accidens potest esse causa amoris, prout scilicet aliqui diligunt se, inquantum conveniunt in odio unius et eiusdem.

