### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod nullus habitus hominibus infundatur a Deo. Deus enim aequaliter se habet ad omnes. Si igitur quibusdam infundit habitus aliquos, omnibus eos infunderet. Quod patet esse falsum.

###### arg. 2
Praeterea, Deus operatur in omnibus secundum modum qui convenit naturae ipsorum, quia divinae providentiae est naturam salvare, ut dicit Dionysius, IV cap. de Div. Nom. Sed habitus in homine naturaliter causantur ex actibus, ut dictum est. Non ergo causat Deus in hominibus aliquos habitus absque actibus.

###### arg. 3
Praeterea, si aliquis habitus a Deo infunditur, per illum habitum homo potest multos actus producere. Sed ex illis actibus causatur similis habitus, ut in II Ethic. dicitur. Sequitur ergo duos habitus eiusdem speciei esse in eodem, unum acquisitum, et alterum infusum. Quod videtur esse impossibile, non enim duae formae unius speciei possunt esse in eodem subiecto. Non ergo habitus aliquis infunditur homini a Deo.

###### s. c.
Sed contra est quod dicitur [[Si 15]], *implevit eum dominus spiritu sapientiae et intellectus*. Sed sapientia et intellectus quidam habitus sunt. Ergo aliqui habitus homini a Deo infunduntur.

###### co.
Respondeo dicendum quod duplici ratione aliqui habitus homini a Deo infunduntur. Prima ratio est, quia aliqui habitus sunt quibus homo bene disponitur ad finem excedentem facultatem humanae naturae, qui est ultima et perfecta hominis beatitudo, ut supra dictum est. Et quia habitus oportet esse proportionatos ei ad quod homo disponitur secundum ipsos, ideo necesse est quod etiam habitus ad huiusmodi finem disponentes, excedant facultatem humanae naturae. Unde tales habitus nunquam possunt homini inesse nisi ex infusione divina, sicut est de omnibus gratuitis virtutibus. Alia ratio est, quia Deus potest producere effectus causarum secundarum absque ipsis causis secundis, ut in primo dictum est. Sicut igitur quandoque, ad ostensionem suae virtutis, producit sanitatem absque naturali causa, quae tamen per naturam posset causari; ita etiam quandoque, ad ostendendam suam virtutem, infundit homini illos etiam habitus qui naturali virtute possunt causari. Sicut apostolis dedit scientiam Scripturarum et omnium linguarum, quam homines per studium vel consuetudinem acquirere possunt, licet non ita perfecte.

###### ad 1
Ad primum ergo dicendum quod Deus, quantum ad suam naturam, aequaliter se habet ad omnes, sed secundum ordinem suae sapientiae certa ratione quaedam tribuit aliquibus, quae non tribuit aliis.

###### ad 2
Ad secundum dicendum quod hoc quod Deus in omnibus operatur secundum modum eorum, non excludit quin Deus quaedam operetur quae natura operari non potest, sed ex hoc sequitur quod nihil operatur contra id quod naturae convenit.

###### ad 3
Ad tertium dicendum quod actus qui producuntur ex habitu infuso, non causant aliquem habitum, sed confirmant habitum praeexistentem, sicut medicinalia remedia adhibita homini sano per naturam, non causant aliquam sanitatem, sed sanitatem prius habitam corroborant.

