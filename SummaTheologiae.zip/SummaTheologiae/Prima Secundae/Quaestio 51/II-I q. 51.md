## Quaestio 51

### Prooemium

Deinde considerandum est de causa habituum. Et primo, quantum ad generationem ipsorum; secundo, quantum ad augmentum; tertio, quantum ad diminutionem et corruptionem. Circa primum quaeruntur quatuor. Primo, utrum aliquis habitus sit a natura. Secundo, utrum aliquis habitus ex actibus causetur. Tertio, utrum per unum actum possit generari habitus. Quarto, utrum aliqui habitus sint in hominibus infusi a Deo.

![[II-I q. 51 a. 1#Articulus 1]]

![[II-I q. 51 a. 2#Articulus 2]]

![[II-I q. 51 a. 3#Articulus 3]]

![[II-I q. 51 a. 4#Articulus 4]]

