## Quaestio 40

### Prooemium

Consequenter considerandum est de passionibus irascibilis, et primo, de spe et desperatione; secundo, de timore et audacia; tertio, de ira. Circa primum quaeruntur octo. Primo, utrum spes sit idem quod desiderium vel cupiditas. Secundo, utrum spes sit in vi apprehensiva, vel in vi appetitiva. Tertio, utrum spes sit in brutis animalibus. Quarto, utrum spei contrarietur desperatio. Quinto, utrum causa spei sit experientia. Sexto, utrum in iuvenibus et ebriosis spes abundet. Septimo, de ordine spei ad amorem. Octavo, utrum spes conferat ad operationem.

![[II-I q. 40 a. 1#Articulus 1]]

![[II-I q. 40 a. 2#Articulus 2]]

![[II-I q. 40 a. 3#Articulus 3]]

![[II-I q. 40 a. 4#Articulus 4]]

![[II-I q. 40 a. 5#Articulus 5]]

![[II-I q. 40 a. 6#Articulus 6]]

![[II-I q. 40 a. 7#Articulus 7]]

![[II-I q. 40 a. 8#Articulus 8]]

