### Articulus 7

###### arg. 1
Ad septimum sic proceditur. Videtur quod spes non sit causa amoris. Quia secundum Augustinum, XIV de Civ. Dei, prima affectionum animae est amor. Sed spes est quaedam affectio animae. Amor ergo praecedit spem. Non ergo spes causat amorem.

###### arg. 2
Praeterea, desiderium praecedit spem. Sed desiderium causatur ex amore, ut dictum est. Ergo etiam spes sequitur amorem. Non ergo causat ipsum.

###### arg. 3
Praeterea, spes causat delectationem, ut supra dictum est. Sed delectatio non est nisi de bono amato. Ergo amor praecedit spem.

###### s. c.
Sed contra est quod [[Mt 1]], super illud, Abraham genuit Isaac, Isaac autem genuit Iacob, dicit Glossa, *idest, fides spem, spes caritatem*. Caritas autem est amor. Ergo amor causatur a spe.

###### co.
Respondeo dicendum quod spes duo respicere potest. Respicit enim sicut obiectum, bonum speratum. Sed quia bonum speratum est arduum possibile; aliquando autem fit aliquod arduum possibile nobis, non per nos, sed per alios; ideo spes etiam respicit illud per quod fit nobis aliquid possibile. Inquantum igitur spes respicit bonum speratum, spes ex amore causatur, non enim est spes nisi de bono desiderato et amato. Inquantum vero spes respicit illum per quem fit aliquid nobis possibile, sic amor causatur ex spe, et non e converso. Ex hoc enim quod per aliquem speramus nobis posse provenire bona, movemur in ipsum sicut in bonum nostrum, et sic incipimus ipsum amare. Ex hoc autem quod amamus aliquem, non speramus de eo, nisi per accidens, inquantum scilicet credimus nos redamari ab ipso. Unde amari ab aliquo facit nos sperare de eo, sed amor eius causatur ex spe quam de eo habemus.

###### ad 
Et per haec patet responsio ad obiecta.

