### Articulus 8

###### arg. 1
Ad octavum sic proceditur. Videtur quod spes non adiuvet operationem, sed magis impediat. Ad spem enim securitas pertinet. Sed securitas parit negligentiam, quae impedit operationem. Ergo spes impedit operationem.

###### arg. 2
Praeterea, tristitia impedit operationem, ut supra dictum est. Sed spes quandoque causat tristitiam, dicitur enim [[Pr 13]], *spes quae differtur, affligit animam*. Ergo spes impedit operationem.

###### arg. 3
Praeterea, desperatio contrariatur spei, ut dictum est. Sed desperatio, maxime in rebus bellicis, adiuvat operationem, dicitur enim [[2S 2]], quod *periculosa res est desperatio*. Ergo spes facit contrarium effectum, impediendo scilicet operationem.

###### s. c.
Sed contra est quod dicitur I ad Cor. IX, quod *qui arat, debet arare in spe fructus percipiendi*. Et eadem ratio est in omnibus aliis.

###### co.
Respondeo dicendum quod spes per se habet quod adiuvet operationem, intendendo ipsam. Et hoc ex duobus. Primo quidem, ex ratione sui obiecti, quod est bonum arduum possibile. Existimatio enim ardui excitat attentionem, existimatio vero possibilis non retardat conatum. Unde sequitur quod homo intente operetur propter spem. Secundo vero, ex ratione sui effectus. Spes enim, ut supra dictum est, causat delectationem, quae adiuvat operationem, ut supra dictum est. Unde spes operationem adiuvat.

###### ad 1
Ad primum ergo dicendum quod spes respicit bonum consequendum, securitas autem respicit malum vitandum. Unde securitas magis videtur opponi timori, quam ad spem pertinere. Et tamen securitas non causat negligentiam, nisi inquantum diminuit existimationem ardui, in quo etiam diminuitur ratio spei. Illa enim in quibus homo nullum impedimentum timet, quasi iam non reputantur ardua.

###### ad 2
Ad secundum dicendum quod spes per se causat delectationem, sed per accidens est ut causet tristitiam, ut supra dictum est.

###### ad 3
Ad tertium dicendum quod desperatio in bello fit periculosa, propter aliquam spem adiunctam. Illi enim qui desperant de fuga, debilitantur in fugiendo, sed sperant mortem suam vindicare. Et ideo ex hac spe acrius pugnant, unde periculosi hostibus fiunt.

