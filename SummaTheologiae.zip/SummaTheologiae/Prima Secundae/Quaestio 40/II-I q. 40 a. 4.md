### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod desperatio non sit contraria spei. Uni enim unum est contrarium, ut dicitur in X Metaphys. Sed spei contrariatur timor. Non ergo contrariatur ei desperatio.

###### arg. 2
Praeterea, contraria videntur esse circa idem. Sed spes et desperatio non sunt circa idem, nam spes respicit bonum, desperatio autem est propter aliquod malum impeditivum adeptionis boni. Ergo spes non contrariatur desperationi.

###### arg. 3
Praeterea, motui contrariatur motus, quies vero opponitur motui ut privatio. Sed desperatio magis videtur importare immobilitatem quam motum. Ergo non contrariatur spei, quae importat motum extensionis in bonum speratum.

###### s. c.
Sed contra est quod desperatio nominatur per contrarium spei.

###### co.
Respondeo dicendum quod, sicut supra dictum est, in mutationibus invenitur duplex contrarietas. Una secundum accessum ad contrarios terminos, et talis contrarietas sola invenitur in passionibus concupiscibilis, sicut amor et odium contrariantur. Alio modo, per accessum et per recessum respectu eiusdem termini, et talis contrarietas invenitur in passionibus irascibilis, sicut supra dictum est. Obiectum autem spei, quod est bonum arduum, habet quidem rationem attractivi, prout consideratur cum possibilitate adipiscendi, et sic tendit in ipsum spes, quae importat quendam accessum. Sed secundum quod consideratur cum impossibilitate obtinendi, habet rationem repulsivi, quia, ut dicitur in III Ethic., *cum ventum fuerit ad aliquid impossibile, tunc homines discedunt*. Et sic respicit hoc obiectum desperatio. Unde importat motum cuiusdam recessus. Et propter hoc, contrariatur spei sicut recessus accessui.

###### ad 1
Ad primum ergo dicendum quod timor contrariatur spei secundum contrarietatem obiectorum, scilicet boni et mali, haec enim contrarietas invenitur in passionibus irascibilis, secundum quod derivantur a passionibus concupiscibilis. Sed desperatio contrariatur ei solum secundum contrarietatem accessus et recessus.

###### ad 2
Ad secundum dicendum quod desperatio non respicit malum sub ratione mali, sed per accidens quandoque respicit malum, inquantum facit impossibilitatem adipiscendi. Potest autem esse desperatio ex solo superexcessu boni.

###### ad 3
Ad tertium dicendum quod desperatio non importat solam privationem spei; sed importat quendam recessum a re desiderata, propter aestimatam impossibilitatem adipiscendi. Unde desperatio praesupponit desiderium, sicut et spes, de eo enim quod sub desiderio nostro non cadit, neque spem neque desperationem habemus. Et propter hoc etiam, utrumque eorum est de bono, quod sub desiderio cadit.

