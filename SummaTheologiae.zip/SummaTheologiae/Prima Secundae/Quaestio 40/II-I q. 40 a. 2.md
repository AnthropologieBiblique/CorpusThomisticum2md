### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod spes pertineat ad vim cognitivam. Spes enim videtur esse expectatio quaedam, dicit enim apostolus, [[Rm 8]], *si autem quod non videmus speramus, per patientiam expectamus*. Sed expectatio videtur ad vim cognitivam pertinere, cuius est exspectare. Ergo spes ad cognitivam pertinet.

###### arg. 2
Praeterea, idem est, ut videtur, spes quod fiducia, unde et sperantes confidentes vocamus, quasi pro eodem utentes eo quod est confidere et sperare. Sed fiducia, sicut et fides, videtur ad vim cognitivam pertinere. Ergo et spes.

###### arg. 3
Praeterea, certitudo est proprietas cognitivae virtutis. Sed certitudo attribuitur spei. Ergo spes ad vim cognitivam pertinet.

###### s. c.
Sed contra, spes est de bono, sicut dictum est. Bonum autem, inquantum huiusmodi, non est obiectum cognitivae, sed appetitivae virtutis. Ergo spes non pertinet ad cognitivam, sed ad appetitivam virtutem.

###### co.
Respondeo dicendum quod, cum spes importet extensionem quandam appetitus in bonum, manifeste pertinet ad appetitivam virtutem, motus enim ad res pertinet proprie ad appetitum. Actio vero virtutis cognitivae perficitur non secundum motum cognoscentis ad res, sed potius secundum quod res cognitae sunt in cognoscente. Sed quia vis cognitiva movet appetitivam, repraesentando ei suum obiectum; secundum diversas rationes obiecti apprehensi, subsequuntur diversi motus in vi appetitiva. Alius enim motus sequitur in appetitu ex apprehensione boni, et alius ex apprehensione mali, et similiter alius motus ex apprehensione praesentis et futuri, absoluti et ardui, possibilis et impossibilis. Et secundum hoc, spes est motus appetitivae virtutis consequens apprehensionem boni futuri ardui possibilis adipisci, scilicet extensio appetitus in huiusmodi obiectum.

###### ad 1
Ad primum ergo dicendum quod, quia spes respicit ad bonum possibile, insurgit dupliciter homini motus spei, sicut dupliciter est ei aliquid possibile, scilicet secundum propriam virtutem, et secundum virtutem alterius. Quod ergo aliquis sperat per propriam virtutem adipisci, non dicitur expectare, sed sperare tantum. Sed proprie dicitur expectare quod sperat ex auxilio virtutis alienae, ut dicatur exspectare quasi ex alio spectare, inquantum scilicet vis apprehensiva praecedens non solum respicit ad bonum quod intendit adipisci, sed etiam ad illud cuius virtute adipisci sperat; secundum illud Eccli. li, *respiciens eram ad adiutorium hominum*. Motus ergo spei quandoque dicitur expectatio, propter inspectionem virtutis cognitivae praecedentem.

###### ad 2
Ad secundum dicendum quod illud quod homo desiderat, et aestimat se posse adipisci, credit se adepturum, et ex tali fide in cognitiva praecedente, motus sequens in appetitu fiducia nominatur. Denominatur enim motus appetitivus a cognitione praecedente, sicut effectus ex causa magis nota, magis enim cognoscit vis apprehensiva suum actum quam actum appetitivae.

###### ad 3
Ad tertium dicendum quod certitudo attribuitur motui non solum appetitus sensitivi, sed etiam appetitus naturalis, sicut dicitur quod lapis certitudinaliter tendit deorsum. Et hoc propter infallibilitatem quam habet ex certitudine cognitionis quae praecedit motum appetitus sensitivi, vel etiam naturalis.

