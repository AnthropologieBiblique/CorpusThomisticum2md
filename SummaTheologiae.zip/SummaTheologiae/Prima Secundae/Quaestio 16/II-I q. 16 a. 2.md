### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod uti conveniat brutis animalibus. Frui enim est nobilius quam uti, quia, ut Augustinus dicit in X de Trin., *utimur eis quae ad aliud referimus, quo fruendum est*. Sed frui convenit brutis animalibus, ut supra dictum est. Ergo multo magis convenit eis uti.

###### arg. 2
Praeterea, applicare membra ad agendum est uti membris. Sed bruta animalia applicant membra ad aliquid agendum; sicut pedes ad ambulandum, cornua ad percutiendum. Ergo brutis animalibus convenit uti.

###### s. c.
Sed contra est quod Augustinus dicit, in libro octoginta trium quaest., *uti aliqua re non potest nisi animal quod rationis est particeps*.

###### co.
Respondeo dicendum quod, sicut dictum est, uti est applicare aliquod principium actionis ad actionem, sicut consentire est applicare motum appetitivum ad aliquid appetendum, ut dictum est. Applicare autem aliquid ad alterum non est nisi eius quod habet arbitrium super illud, quod non est nisi eius qui scit referre aliquid in alterum, quod ad rationem pertinet. Et ideo solum animal rationale et consentit, et utitur.

###### ad 1
Ad primum ergo dicendum quod frui importat absolutum motum appetitus in appetibile, sed uti importat motum appetitus ad aliquid in ordine ad alterum. Si ergo comparentur uti et frui quantum ad obiecta, sic frui est nobilius quam uti, quia id quod est absolute appetibile, est melius quam id quod est appetibile solum in ordine ad aliud. Sed si comparentur quantum ad vim apprehensivam praecedentem, maior nobilitas requiritur ex parte usus, quia ordinare aliquid in alterum est rationis; absolute autem aliquid apprehendere potest etiam sensus.

###### ad 2
Ad secundum dicendum quod animalia per sua membra aliquid agunt instinctu naturae, non per hoc quod cognoscant ordinem membrorum ad illas operationes. Unde non dicuntur proprie applicare membra ad agendum, nec uti membris.

