### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod usus praecedat electionem. Post electionem enim nihil sequitur nisi executio. Sed usus, cum pertineat ad voluntatem, praecedit executionem. Ergo praecedit etiam electionem.

###### arg. 2
Praeterea, absolutum est ante relatum. Ergo minus relatum est ante magis relatum. Sed electio importat duas relationes, unam eius quod eligitur ad finem, aliam vero ad id cui praeeligitur, usus autem importat solam relationem ad finem. Ergo usus est prior electione.

###### arg. 3
Praeterea, voluntas utitur aliis potentiis inquantum movet eas. Sed voluntas movet etiam seipsam ut dictum est. Ergo etiam utitur seipsa, applicando se ad agendum. Sed hoc facit cum consentit. Ergo in ipso consensu est usus. Sed consensus praecedit electionem ut dictum est. Ergo et usus.

###### s. c.
Sed contra est quod Damascenus dicit, quod *voluntas post electionem impetum facit ad operationem, et postea utitur*. Ergo usus sequitur electionem.

###### co.
Respondeo dicendum quod voluntas duplicem habitudinem habet ad volitum. Unam quidem, secundum quod volitum est quodammodo in volente, per quandam proportionem vel ordinem ad volitum. Unde et res quae naturaliter sunt proportionatae ad aliquem finem, dicuntur appetere illum naturaliter. Sed sic habere finem, est imperfecte habere ipsum. Omne autem imperfectum tendit in perfectionem. Et ideo tam appetitus naturalis, quam voluntarius, tendit ut habeat ipsum finem realiter, quod est perfecte habere ipsum. Et haec est secunda habitudo voluntatis ad volitum. Volitum autem non solum est finis, sed id quod est ad finem. Ultimum autem quod pertinet ad primam habitudinem voluntatis, respectu eius quod est ad finem, est electio, ibi enim completur proportio voluntatis, ut complete velit id quod est ad finem. Sed usus iam pertinet ad secundam habitudinem voluntatis, qua tendit ad consequendum rem volitam. Unde manifestum est quod usus sequitur electionem, si tamen accipiatur usus, secundum quod voluntas utitur executiva potentia movendo ipsam. Sed quia voluntas etiam quodammodo rationem movet, et utitur ea, potest intelligi usus eius quod est ad finem, secundum quod est in consideratione rationis referentis ipsum in finem. Et hoc modo usus praecedit electionem.

###### ad 1
Ad primum ergo dicendum quod ipsam executionem operis praecedit motio qua voluntas movet ad exequendum, sequitur autem electionem. Et sic, cum usus pertineat ad praedictam motionem voluntatis, medium est inter electionem et executionem.

###### ad 2
Ad secundum dicendum quod id quod est per essentiam suam relatum, posterius est absoluto, sed id cui attribuuntur relationes, non oportet quod sit posterius. Immo quanto causa est prior, tanto habet relationem ad plures effectus.

###### ad 3
Ad tertium dicendum quod electio praecedit usum, si referantur ad idem. Nihil autem prohibet quod usus unius praecedat electionem alterius. Et quia actus voluntatis reflectuntur supra seipsos, in quolibet actu voluntatis potest accipi et consensus, et electio, et usus, ut si dicatur quod voluntas consentit se eligere, et consentit se consentire, et utitur se ad consentiendum et eligendum. Et semper isti actus ordinati ad id quod est prius, sunt priores.

