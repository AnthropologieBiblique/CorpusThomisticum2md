## Quaestio 16

### Prooemium

Deinde considerandum est de usu. Et circa hoc quaeruntur quatuor. Primo, utrum uti sit actus voluntatis. Secundo, utrum conveniat brutis animalibus. Tertio, utrum sit tantum eorum quae sunt ad finem, vel etiam finis. Quarto, de ordine usus ad electionem.

![[II-I q. 16 a. 1#Articulus 1]]

![[II-I q. 16 a. 2#Articulus 2]]

![[II-I q. 16 a. 3#Articulus 3]]

![[II-I q. 16 a. 4#Articulus 4]]

