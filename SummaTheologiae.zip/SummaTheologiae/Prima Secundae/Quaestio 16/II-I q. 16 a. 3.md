### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod usus possit esse etiam ultimi finis. Dicit enim Augustinus, in X de Trin., *omnis qui fruitur, utitur*. Sed ultimo fine fruitur aliquis. Ergo ultimo fine aliquis utitur.

###### arg. 2
*Praeterea, uti est assumere aliquid in facultatem voluntatis*, ut ibidem dicitur. Sed nihil magis assumitur a voluntate quam ultimus finis. Ergo usus potest esse ultimi finis.

###### arg. 3
Praeterea, Hilarius dicit, in II de Trin., quod aeternitas est in patre, species in imagine, idest in filio, usus in munere, idest in spiritu sancto. Sed spiritus sanctus, cum sit Deus, est ultimus finis. Ergo ultimo fine contingit uti.

###### s. c.
Sed contra est quod dicit Augustinus, in libro octoginta trium quaest., *Deo nullus recte utitur, sed fruitur*. Sed solus Deus est ultimus finis. Ergo ultimo fine non est utendum.

###### co.
Respondeo dicendum quod uti, sicut dictum est, importat applicationem alicuius ad aliquid. Quod autem applicatur ad aliud, se habet in ratione eius quod est ad finem. Et ideo uti semper est eius quod est ad finem. Propter quod et ea quae sunt ad finem accommoda, utilia dicuntur; et ipsa utilitas interdum usus nominatur. Sed considerandum est quod ultimus finis dicitur dupliciter, uno modo, simpliciter; et alio modo, quoad aliquem. Cum enim finis, ut supra dictum est, dicatur quandoque quidem res, quandoque autem adeptio rei vel possessio eius, sicut avaro finis est vel pecunia vel possessio pecuniae; manifestum est quod, simpliciter loquendo, ultimus finis est ipsa res, non enim possessio pecuniae est bona, nisi propter bonum pecuniae. Sed quoad hunc, adeptio pecuniae est finis ultimus, non enim quaereret pecuniam avarus, nisi ut haberet eam. Ergo, simpliciter loquendo et proprie, pecunia homo aliquis fruitur, quia in ea ultimum finem constituit, sed inquantum refert eam ad possessionem, dicitur uti ea.

###### ad 1
Ad primum ergo dicendum quod Augustinus loquitur de usu communiter, secundum quod importat ordinem finis ad ipsam finis fruitionem, quam aliquis quaerit de fine.

###### ad 2
Ad secundum dicendum quod finis assumitur in facultatem voluntatis, ut voluntas in illo quiescat. Unde ipsa requies in fine, quae fruitio est, dicitur hoc modo usus finis. Sed id quod est ad finem, assumitur in facultatem voluntatis non solum in ordine ad usum eius quod est ad finem, sed in ordine ad aliam rem, in qua voluntas quiescit.

###### ad 3
Ad tertium dicendum quod usus accipitur in verbis Hilarii pro quiete in ultimo fine, eo modo quo aliquis, communiter loquendo, dicitur uti fine ad obtinendum ipsum, sicut dictum est. Unde Augustinus, in VI de Trin., dicit quod *illa dilectio, delectatio, felicitas vel beatitudo usus ab eo appellatur*.

