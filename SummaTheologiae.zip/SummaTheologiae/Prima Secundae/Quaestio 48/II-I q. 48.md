## Quaestio 48

### Prooemium

Deinde considerandum est de effectibus irae. Et circa hoc quaeruntur quatuor. Primo, utrum ira causet delectationem. Secundo, utrum maxime causet fervorem in corde. Tertio, utrum maxime impediat rationis usum. Quarto, utrum causet taciturnitatem.

![[II-I q. 48 a. 1#Articulus 1]]

![[II-I q. 48 a. 2#Articulus 2]]

![[II-I q. 48 a. 3#Articulus 3]]

