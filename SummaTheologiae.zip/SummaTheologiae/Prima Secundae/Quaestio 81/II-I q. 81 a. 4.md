### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod, si aliquis formaretur ex carne humana miraculose, contraheret originale peccatum. Dicit enim quaedam Glossa [[Gn 4]], quod *in lumbis Adae fuit tota posteritas corrupta, quia non est separata prius in loco vitae, sed postea in loco exilii*. Sed si aliquis homo sic formaretur sicut dictum est, caro eius separaretur in loco exilii. Ergo contraheret originale peccatum.

###### arg. 2
Praeterea, peccatum originale causatur in nobis inquantum anima inficitur ex carne. Sed caro tota hominis est infecta. Ergo ex quacumque parte carnis homo formaretur, anima eius inficeretur infectione originalis peccati.

###### arg. 3
Praeterea, peccatum originale a primo parente pervenit in omnes, inquantum omnes in eo peccante fuerunt. Sed illi qui ex carne humana formarentur, in Adam fuissent. Ergo peccatum originale contraherent.

###### s. c.
Sed contra est quia non fuissent in Adam secundum seminalem rationem; quod solum causat traductionem peccati originalis, ut Augustinus dicit, X super Gen. ad Litt.

###### co.
Respondeo dicendum quod, sicut iam dictum est, peccatum originale a primo parente traducitur in posteros, inquantum moventur ab ipso per generationem, sicut membra moventur ab anima ad peccatum actuale. Non autem est motio ad generationem nisi per virtutem activam in generatione. Unde illi soli peccatum originale contrahunt, qui ab Adam descendunt per virtutem activam in generatione originaliter ab Adam derivatam, quod est secundum seminalem rationem ab eo descendere, nam ratio seminalis nihil aliud est quam vis activa in generatione. Si autem aliquis formaretur virtute divina ex carne humana, manifestum est quod vis activa non derivaretur ab Adam. Unde non contraheret peccatum originale, sicut nec actus manus pertineret ad peccatum humanum, si manus non moveretur a voluntate hominis, sed ab aliquo extrinseco movente.

###### ad 1
Ad primum ergo dicendum quod Adam non fuit in loco exilii nisi post peccatum. Unde non propter locum exilii, sed propter peccatum, traducitur originalis culpa ad eos ad quos activa eius generatio pervenit.

###### ad 2
Ad secundum dicendum quod caro non inficit animam nisi inquantum est principium activum in generatione, ut dictum est.

###### ad 3
Ad tertium dicendum quod ille qui formaretur ex carne humana, fuisset in Adam secundum corpulentam substantiam; sed non secundum seminalem rationem, ut dictum est. Et ideo non contraheret originale peccatum.

