## Quaestio 81

### Prooemium

Deinde considerandum est de causa peccati ex parte hominis. Cum autem homo sit causa peccati alteri homini exterius suggerendo, sicut et Diabolus, habet quendam specialem modum causandi peccatum in alterum per originem. Unde de peccato originali dicendum est. Circa quod tria consideranda occurrunt, primo, de eius traductione; secundo, de eius essentia; tertio, de eius subiecto. Circa primum quaeruntur quinque. Primo, utrum primum peccatum hominis derivetur per originem in posteros. Secundo, utrum omnia alia peccata primi parentis, vel etiam aliorum parentum, per originem in posteros deriventur. Tertio, utrum peccatum originale derivetur ad omnes qui ex Adam per viam seminis generantur. Quarto, utrum derivaretur ad illos qui miraculose ex aliqua parte humani corporis formarentur. Quinto, utrum si femina peccasset, viro non peccante, traduceretur originale peccatum.

![[II-I q. 81 a. 1#Articulus 1]]

![[II-I q. 81 a. 2#Articulus 2]]

![[II-I q. 81 a. 3#Articulus 3]]

![[II-I q. 81 a. 4#Articulus 4]]

![[II-I q. 81 a. 5#Articulus 5]]

