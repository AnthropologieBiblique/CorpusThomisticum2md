### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod in voluntate non sit aliquis habitus. Habitus enim qui in intellectu est, sunt species intelligibiles, quibus intelligit actu. Sed voluntas non operatur per aliquas species. Ergo voluntas non est subiectum alicuius habitus.

###### arg. 2
Praeterea, in intellectu agente non ponitur aliquis habitus, sicut in intellectu possibili, quia est potentia activa. Sed voluntas est maxime potentia activa, quia movet omnes potentias ad suos actus, ut supra dictum est. Ergo in ipsa non est aliquis habitus.

###### arg. 3
Praeterea, in potentiis naturalibus non est aliquis habitus, quia ex sua natura sunt ad aliquid determinatae. Sed voluntas ex sua natura ordinatur ad hoc quod tendat in bonum ordinatum ratione. Ergo in voluntate non est aliquis habitus.

###### s. c.
Sed contra est quod iustitia est habitus quidam. Sed iustitia est in voluntate, est enim iustitia *habitus secundum quem aliqui volunt et operantur iusta*, ut dicitur in V Ethic. Ergo voluntas est subiectum alicuius habitus.

###### co.
Respondeo dicendum quod omnis potentia quae diversimode potest ordinari ad agendum, indiget habitu quo bene disponatur ad suum actum. Voluntas autem, cum sit potentia rationalis, diversimode potest ad agendum ordinari. Et ideo oportet in voluntate aliquem habitum ponere, quo bene disponatur ad suum actum. Ex ipsa etiam ratione habitus apparet quod habet quendam principalem ordinem ad voluntatem, prout habitus est quo quis utitur cum voluerit, ut supra dictum est.

###### ad 1
Ad primum ergo dicendum quod, sicut in intellectu est aliqua species quae est similitudo obiecti, ita oportet in voluntate, et in qualibet vi appetitiva, esse aliquid quo inclinetur in suum obiectum, cum nihil aliud sit actus appetitivae virtutis quam inclinatio quaedam, ut supra dictum est. Ad ea ergo ad quae sufficienter inclinatur per naturam ipsius potentiae, non indiget aliqua qualitate inclinante. Sed quia necessarium est ad finem humanae vitae, quod vis appetitiva inclinetur in aliquid determinatum, ad quod non inclinatur ex natura potentiae, quae se habet ad multa et diversa; ideo necesse est quod in voluntate, et in aliis viribus appetitivis, sint quaedam qualitates inclinantes, quae dicuntur habitus.

###### ad 2
Ad secundum dicendum quod intellectus agens est agens tantum, et nullo modo patiens. Sed voluntas, et quaelibet vis appetitiva, est movens motum, ut dicitur in III de anima. Et ideo non est similis ratio de utroque, nam esse susceptivum habitus convenit ei quod est quodammodo in potentia.

###### ad 3
Ad tertium dicendum quod voluntas ex ipsa natura potentiae inclinatur in bonum rationis. Sed quia hoc bonum multipliciter diversificatur, necessarium est ut ad aliquod determinatum bonum rationis voluntas per aliquem habitum inclinetur, ad hoc quod sequatur promptior operatio.

