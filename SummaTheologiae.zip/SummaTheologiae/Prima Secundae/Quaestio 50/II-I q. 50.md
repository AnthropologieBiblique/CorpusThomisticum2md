## Quaestio 50

### Prooemium

Deinde considerandum est de subiecto habituum. Et circa hoc quaeruntur sex. Primo, utrum in corpore sit aliquis habitus. Secundo, utrum anima sit subiectum habitus secundum suam essentiam, vel secundum suam potentiam. Tertio, utrum in potentiis sensitivae partis possit esse aliquis habitus. Quarto, utrum in ipso intellectu sit aliquis habitus. Quinto, utrum in voluntate sit aliquis habitus. Sexto, utrum in substantiis separatis.

![[II-I q. 50 a. 1#Articulus 1]]

![[II-I q. 50 a. 2#Articulus 2]]

![[II-I q. 50 a. 3#Articulus 3]]

![[II-I q. 50 a. 4#Articulus 4]]

![[II-I q. 50 a. 5#Articulus 5]]

![[II-I q. 50 a. 6#Articulus 6]]

