### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod privatio modi, speciei et ordinis, non sit effectus peccati. Dicit enim Augustinus, in libro de natura boni, quod *ubi haec tria magna sunt, magnum bonum est; ubi parva, parvum; ubi nulla, nullum*. Sed peccatum non annullat bonum naturae. Ergo non privat modum, speciem et ordinem.

###### arg. 2
Praeterea, nihil est causa sui ipsius. Sed ipsum peccatum est privatio modi, speciei et ordinis, ut Augustinus dicit, in libro de natura boni. Ergo privatio modi, speciei et ordinis, non est effectus peccati.

###### arg. 3
Praeterea, diversa peccata diversos habent effectus. Sed modus, species et ordo, cum sint quaedam diversa, diversas privationes habere videntur. Ergo per diversa peccata privantur. Non ergo est effectus cuiuslibet peccati privatio modi, speciei et ordinis.

###### s. c.
Sed contra est quod peccatum est in anima sicut infirmitas in corpore; secundum illud [[Ps 6]], *miserere mei, domine, quoniam infirmus sum*. Sed infirmitas privat modum, speciem et ordinem ipsius corporis. Ergo peccatum privat modum, speciem et ordinem animae.

###### co.
Respondeo dicendum quod, sicut in primo dictum est, modus, species et ordo consequuntur unumquodque bonum creatum inquantum huiusmodi, et etiam unumquodque ens. Omne enim esse et bonum consideratur per aliquam formam, secundum quam sumitur species. Forma autem uniuscuiusque rei, qualiscumque sit, sive substantialis sive accidentalis, est secundum aliquam mensuram, unde et in VIII Metaphys. dicitur quod formae rerum sunt sicut numeri. Et ex hoc habet modum quendam, qui mensuram respicit. Ex forma vero sua unumquodque ordinatur ad aliud. Sic igitur secundum diversos gradus bonorum, sunt diversi gradus modi, speciei et ordinis. Est ergo quoddam bonum pertinens ad ipsam substantiam naturae, quod habet suum modum, speciem et ordinem, et illud nec privatur nec diminuitur per peccatum. Est etiam quoddam bonum naturalis inclinationis, et hoc etiam habet suum modum, speciem et ordinem, et hoc diminuitur per peccatum, ut dictum est, sed non totaliter tollitur. Est etiam quoddam bonum virtutis et gratiae, quod etiam habet suum modum, speciem et ordinem, et hoc totaliter tollitur per peccatum mortale. Est etiam quoddam bonum quod est ipse actus ordinatus, quod etiam habet suum modum, speciem et ordinem, et huius privatio est essentialiter ipsum peccatum. Et sic patet qualiter peccatum et est privatio modi, speciei et ordinis; et privat vel diminuit modum, speciem et ordinem.

###### ad 1
Unde patet responsio ad duo prima.

###### ad 3
Ad tertium dicendum quod modus, species et ordo se consequuntur, sicut ex dictis patet. Unde simul privantur et diminuuntur.

