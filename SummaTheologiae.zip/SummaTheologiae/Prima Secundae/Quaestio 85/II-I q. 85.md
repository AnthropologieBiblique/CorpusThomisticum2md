## Quaestio 85

### Prooemium

Deinde considerandum est de effectibus peccati. Et primo quidem, de corruptione boni naturae; secundo, de macula animae; tertio, de reatu poenae. Circa primum quaeruntur sex. Primo, utrum bonum naturae diminuatur per peccatum. Secundo, utrum totaliter tolli possit. Tertio, de quatuor vulneribus quae Beda ponit, quibus natura humana vulnerata est propter peccatum. Quarto, utrum privatio modi, speciei et ordinis, sit effectus peccati. Quinto, utrum mors et alii defectus corporales sint effectus peccati. Sexto, utrum sint aliquo modo homini naturales.

![[II-I q. 85 a. 1#Articulus 1]]

![[II-I q. 85 a. 2#Articulus 2]]

![[II-I q. 85 a. 3#Articulus 3]]

![[II-I q. 85 a. 4#Articulus 4]]

![[II-I q. 85 a. 5#Articulus 5]]

![[II-I q. 85 a. 6#Articulus 6]]

