## Quaestio 102

### Prooemium

Deinde considerandum est de causis caeremonialium praeceptorum. Et circa hoc quaeruntur sex. Primo, utrum praecepta caeremonialia habeant causam. Secundo, utrum habeant causam litteralem, vel solum figuralem. Tertio, de causis sacrificiorum. Quarto, de causis sacramentorum. Quinto, de causis sacrorum. Sexto, de causis observantiarum.

![[II-I q. 102 a. 1#Articulus 1]]

![[II-I q. 102 a. 2#Articulus 2]]

![[II-I q. 102 a. 3#Articulus 3]]

![[II-I q. 102 a. 4#Articulus 4]]

![[II-I q. 102 a. 5#Articulus 5]]

![[II-I q. 102 a. 6#Articulus 6]]

