### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod macula non maneat in anima post actum peccati. Nihil enim manet in anima post actum, nisi habitus vel dispositio. Sed macula non est habitus vel dispositio, ut supra habitum est. Ergo macula non manet in anima post actum peccati.

###### arg. 2
Praeterea, hoc modo se habet macula ad peccatum, sicut umbra ad corpus, ut supra dictum est. Sed transeunte corpore, non manet umbra. Ergo, transeunte actu peccati, non manet macula.

###### arg. 3
Praeterea, omnis effectus dependet ex sua causa. Causa autem maculae est actus peccati. Ergo, remoto actu peccati, non remanet macula in anima.

###### s. c.
Sed contra est quod dicitur [[Jos 22]], *an parum vobis est quod peccastis in Beelphegor, et usque in praesentem diem macula huius sceleris in vobis permanet?*

###### co.
Respondeo dicendum quod macula peccati remanet in anima, etiam transeunte actu peccati. Cuius ratio est quia macula, sicut dictum est, importat quendam defectum nitoris propter recessum a lumine rationis vel divinae legis. Et ideo quandiu homo manet extra huiusmodi lumen, manet in eo macula peccati, sed postquam redit ad lumen divinum et ad lumen rationis, quod fit per gratiam, tunc macula cessat. Licet autem cesset actus peccati, quo homo discessit a lumine rationis vel legis divinae, non tamen statim homo ad illud redit in quo fuerat, sed requiritur aliquis motus voluntatis contrarius primo motui. Sicut si aliquis sit distans alicui per aliquem motum, non statim cessante motu fit ei propinquus, sed oportet quod appropinquet rediens per motum contrarium.

###### ad 1
Ad primum ergo dicendum quod post actum peccati nihil positive remanet in anima nisi dispositio vel habitus, remanet tamen aliquid privative, scilicet privatio coniunctionis ad divinum lumen.

###### ad 2
Ad secundum dicendum quod, transeunte obstaculo corporis, remanet corpus diaphanum in aequali propinquitate et habitudine ad corpus illuminans, et ideo statim umbra transit. Sed remoto actu peccati, non remanet anima in eadem habitudine ad Deum. Unde non est similis ratio.

###### ad 3
Ad tertium dicendum quod actus peccati facit distantiam a Deo, quam quidem distantiam sequitur defectus nitoris, hoc modo sicut motus localis facit localem distantiam. Unde sicut, cessante motu, non tollitur distantia localis; ita nec, cessante actu peccati, tollitur macula.

