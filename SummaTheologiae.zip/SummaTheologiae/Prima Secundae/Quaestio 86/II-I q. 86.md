## Quaestio 86

### Prooemium

Deinde considerandum est de macula peccati. Et circa hoc quaeruntur duo. Primo, utrum macula animae sit effectus peccati. Secundo, utrum remaneat in anima post actum peccati.

![[II-I q. 86 a. 1#Articulus 1]]

![[II-I q. 86 a. 2#Articulus 2]]

