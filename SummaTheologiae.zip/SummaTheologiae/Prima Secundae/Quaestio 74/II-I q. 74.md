## Quaestio 74

### Prooemium

Deinde considerandum est de subiecto vitiorum, sive peccatorum. Et circa hoc quaeruntur decem. Primo, utrum voluntas possit esse subiectum peccati. Secundo, utrum voluntas sola sit peccati subiectum. Tertio, utrum sensualitas possit esse subiectum peccati. Quarto, utrum possit esse subiectum peccati mortalis. Quinto, utrum ratio possit esse subiectum peccati. Sexto, utrum delectatio morosa, vel non morosa, sit in ratione inferiori sicut in subiecto. Septimo, utrum peccatum consensus in actum sit in superiori ratione sicut in subiecto. Octavo, utrum ratio inferior possit esse subiectum peccati mortalis. Nono, utrum ratio superior possit esse subiectum peccati venialis. Decimo, utrum in ratione superiori possit esse peccatum veniale circa proprium obiectum.

![[II-I q. 74 a. 1#Articulus 1]]

![[II-I q. 74 a. 2#Articulus 2]]

![[II-I q. 74 a. 3#Articulus 3]]

![[II-I q. 74 a. 4#Articulus 4]]

![[II-I q. 74 a. 5#Articulus 5]]

![[II-I q. 74 a. 6#Articulus 6]]

![[II-I q. 74 a. 7#Articulus 7]]

![[II-I q. 74 a. 8#Articulus 8]]

![[II-I q. 74 a. 9#Articulus 9]]

