### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod peccatum non possit esse in ratione. Cuiuslibet enim potentiae peccatum est aliquis defectus ipsius. Sed defectus rationis non est peccatum, sed magis excusat peccatum, excusatur enim aliquis a peccato propter ignorantiam. Ergo in ratione non potest esse peccatum.

###### arg. 2
Praeterea, primum subiectum peccati est voluntas, ut dictum est. Sed ratio praecedit voluntatem, cum sit directiva ipsius. Ergo peccatum esse non potest in ratione.

###### arg. 3
Praeterea, non potest esse peccatum nisi circa ea quae sunt in nobis. Sed perfectio et defectus rationis non est eorum quae sunt in nobis, quidam enim sunt naturaliter ratione deficientes, vel ratione solertes. Ergo in ratione non est peccatum.

###### s. c.
Sed contra est quod Augustinus dicit, in libro XII de Trin., quod peccatum est in ratione inferiori et in ratione superiori.

###### co.
Respondeo dicendum quod peccatum cuiuslibet potentiae consistit in actu ipsius, sicut ex dictis patet. Habet autem ratio duplicem actum, unum quidem secundum se, in comparatione ad proprium obiectum, quod est cognoscere aliquod verum; alius autem actus rationis est inquantum est directiva aliarum virium. Utroque igitur modo contingit esse peccatum in ratione. Et primo quidem, inquantum errat in cognitione veri, quod quidem tunc imputatur ei ad peccatum, quando habet ignorantiam vel errorem circa id quod potest et debet scire. Secundo, quando inordinatos actus inferiorum virium vel imperat, vel etiam post deliberationem non coercet.

###### ad 1
Ad primum ergo dicendum quod ratio illa procedit de defectu rationis qui pertinet ad actum proprium respectu proprii obiecti, et hoc quando est defectus cognitionis eius quod quis non potest scire. Tunc enim talis defectus rationis non est peccatum, sed excusat a peccato, sicut patet in his quae per furiosos committuntur. Si vero sit defectus rationis circa id quod homo potest et debet scire, non omnino homo excusatur a peccato, sed ipse defectus imputatur ei ad peccatum. Defectus autem qui est solum in dirigendo alias vires, semper imputatur ei ad peccatum, quia huic defectui occurrere potest per proprium actum.

###### ad 2
Ad secundum dicendum quod, sicut supra dictum est, cum de actibus voluntatis et rationis ageretur, voluntas quodammodo movet et praecedit rationem, et ratio quodammodo voluntatem, unde et motus voluntatis dici potest rationalis, et actus rationis potest dici voluntarius. Et secundum hoc in ratione invenitur peccatum, vel prout est defectus eius voluntarius, vel prout actus rationis est principium actus voluntatis.

###### ad 3
Ad tertium patet responsio ex dictis.

