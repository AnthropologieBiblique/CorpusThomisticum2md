### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod sola voluntas sit subiectum peccati. Dicit enim Augustinus, in libro de duabus animabus, quod *non nisi voluntate peccatur*. Sed peccatum est sicut in subiecto in potentia qua peccatur. Ergo sola voluntas est subiectum peccati.

###### arg. 2
Praeterea, peccatum est quoddam malum contra rationem. Sed bonum et malum ad rationem pertinens, est obiectum solius voluntatis. Ergo sola voluntas est subiectum peccati.

###### arg. 3
Praeterea, omne peccatum est actus voluntarius, quia, ut dicit Augustinus, in libro de Lib. Arb., *peccatum adeo est voluntarium, quod si non sit voluntarium, non est peccatum*. Sed actus aliarum virium non sunt voluntarii nisi inquantum illae vires moventur a voluntate. Hoc autem non sufficit ad hoc quod sint subiectum peccati, quia secundum hoc etiam membra exteriora, quae moventur a voluntate, essent subiectum peccati; quod patet esse falsum. Ergo sola voluntas est subiectum peccati.

###### s. c.
Sed contra, peccatum virtuti contrariatur. Contraria autem sunt circa idem. Sed aliae etiam vires animae praeter voluntatem, sunt subiecta virtutum, ut supra dictum est. Ergo non sola voluntas est subiectum peccati.

###### co.
Respondeo dicendum quod, sicut ex praedictis patet, omne quod est principium voluntarii actus, est subiectum peccati. Actus autem voluntarii dicuntur non solum illi qui eliciuntur a voluntate, sed etiam illi qui a voluntate imperantur; ut supra dictum est, cum de voluntario ageretur. Unde non sola voluntas potest esse subiectum peccati, sed omnes illae potentiae quae possunt moveri ad suos actus, vel ab eis reprimi, per voluntatem. Et eaedem etiam potentiae sunt subiecta habituum moralium bonorum vel malorum, quia eiusdem est actus et habitus.

###### ad 1
Ad primum ergo dicendum quod non peccatur nisi voluntate sicut primo movente, aliis autem potentiis peccatur sicut ab ea motis.

###### ad 2
Ad secundum dicendum quod bonum et malum pertinent ad voluntatem sicut per se obiecta ipsius, sed aliae potentiae habent aliquod determinatum bonum et malum, ratione cuius potest in eis esse et virtus et vitium et peccatum, secundum quod participant voluntate et ratione.

###### ad 3
Ad tertium dicendum quod membra corporis non sunt principia actuum, sed solum organa, unde et comparantur ad animam moventem sicut servus, qui agitur et non agit. Potentiae autem appetitivae interiores comparantur ad rationem quasi liberae, quia agunt quodammodo et aguntur, ut patet per id quod dicitur I Polit. Et praeterea actus exteriorum membrorum sunt actiones in exteriorem materiam transeuntes, sicut patet de percussione in peccato homicidii. Et propter hoc non est similis ratio.

