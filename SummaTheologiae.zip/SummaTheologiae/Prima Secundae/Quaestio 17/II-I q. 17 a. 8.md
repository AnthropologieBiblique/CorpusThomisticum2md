### Articulus 8

###### arg. 1
Ad octavum sic proceditur. Videtur quod actus vegetabilis animae imperio rationis subdantur. Vires enim sensitivae nobiliores sunt viribus animae vegetabilis. Sed vires animae sensitivae subduntur imperio rationis. Ergo multo magis vires animae vegetabilis.

###### arg. 2
Praeterea, homo dicitur minor mundus, quia sic est anima in corpore, sicut Deus in mundo. Sed Deus sic est in mundo, quod omnia quae sunt in mundo, obediunt eius imperio. Ergo et omnia quae sunt in homine, obediunt imperio rationis, etiam vires vegetabilis animae.

###### arg. 3
Praeterea, laus et vituperium non contingit nisi in actibus qui subduntur imperio rationis. Sed in actibus nutritivae et generativae potentiae, contingit esse laudem et vituperium, et virtutem et vitium, sicut patet in gula et luxuria, et virtutibus oppositis. Ergo actus harum potentiarum subduntur imperio rationis.

###### s. c.
Sed contra est quod Gregorius Nyssenus dicit, quod *id quod non persuadetur a ratione, est nutritivum et generativum*.

###### co.
Respondeo dicendum quod actuum quidam procedunt ex appetitu naturali, quidam autem ex appetitu animali vel intellectuali, omne enim agens aliquo modo appetit finem. Appetitus autem naturalis non consequitur aliquam apprehensionem, sicut sequitur appetitus animalis et intellectualis. Ratio autem imperat per modum apprehensivae virtutis. Et ideo actus illi qui procedunt ab appetitu intellectivo vel animali, possunt a ratione imperari, non autem actus illi qui procedunt ex appetitu naturali. Huiusmodi autem sunt actus vegetabilis animae, unde Gregorius Nyssenus dicit quod vocatur naturale quod generativum et nutritivum. Et propter hoc, actus vegetabilis animae non subduntur imperio rationis.

###### ad 1
Ad primum ergo dicendum quod, quanto aliquis actus est immaterialior, tanto est nobilior, et magis subditus imperio rationis. Unde ex hoc ipso quod vires animae vegetabilis non obediunt rationi, apparet has vires infimas esse.

###### ad 2
Ad secundum dicendum quod similitudo attenditur quantum ad aliquid, quia scilicet, sicut Deus movet mundum, ita anima movet corpus. Non autem quantum ad omnia, non enim anima creavit corpus ex nihilo, sicut Deus mundum; propter quod totaliter subditur eius imperio.

###### ad 3
Ad tertium dicendum quod virtus et vitium, laus et vituperium, non debentur ipsis actibus nutritivae vel generativae potentiae, qui sunt digestio et formatio corporis humani; sed actibus sensitivae partis ordinatis ad actus generativae vel nutritivae; puta in concupiscendo delectationem cibi et venereorum, et utendo, secundum quod oportet, vel non secundum quod oportet.

