## Quaestio 17

### Prooemium

Deinde considerandum est de actibus imperatis a voluntate. Et circa hoc quaeruntur novem. Primo, utrum imperare sit actus voluntatis, vel rationis. Secundo, utrum imperare pertineat ad bruta animalia. Tertio, de ordine imperii ad usum. Quarto, utrum imperium et actus imperatus sint unus actus, vel diversi. Quinto, utrum actus voluntatis imperetur. Sexto, utrum actus rationis. Septimo, utrum actus appetitus sensitivi. Octavo, utrum actus animae vegetabilis. Nono, utrum actus exteriorum membrorum.

![[II-I q. 17 a. 1#Articulus 1]]

![[II-I q. 17 a. 2#Articulus 2]]

![[II-I q. 17 a. 3#Articulus 3]]

![[II-I q. 17 a. 4#Articulus 4]]

![[II-I q. 17 a. 5#Articulus 5]]

![[II-I q. 17 a. 6#Articulus 6]]

![[II-I q. 17 a. 7#Articulus 7]]

![[II-I q. 17 a. 8#Articulus 8]]

![[II-I q. 17 a. 9#Articulus 9]]

