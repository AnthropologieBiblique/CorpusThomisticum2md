### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod actus rationis non possit esse imperatus. Inconveniens enim videtur quod aliquid imperet sibi ipsi. Sed ratio est quae imperat, ut supra dictum est. Ergo rationis actus non imperatur.

###### arg. 2
Praeterea, id quod est per essentiam, diversum est ab eo quod est per participationem. Sed potentia cuius actus imperatur a ratione, est ratio per participationem, ut dicitur in I Ethic. Ergo illius potentiae actus non imperatur, quae est ratio per essentiam.

###### arg. 3
Praeterea, ille actus imperatur, qui est in potestate nostra. Sed cognoscere et iudicare verum, quod est actus rationis, non est semper in potestate nostra. Non ergo actus rationis potest esse imperatus.

###### s. c.
Sed contra, id quod libero arbitrio agimus, nostro imperio agi potest. Sed actus rationis exercentur per liberum arbitrium, dicit enim Damascenus quod *libero arbitrio homo exquirit, et scrutatur, et iudicat, et disponit*. Ergo actus rationis possunt esse imperati.

###### co.
Respondeo dicendum quod, quia ratio supra seipsam reflectitur, sicut ordinat de actibus aliarum potentiarum, ita etiam potest ordinare de actu suo. Unde etiam actus suus potest esse imperatus. Sed attendendum est quod actus rationis potest considerari dupliciter. Uno modo, quantum ad exercitium actus. Et sic actus rationis semper imperari potest, sicut cum indicitur alicui quod attendat, et ratione utatur. Alio modo, quantum ad obiectum, respectu cuius, duo actus rationis attenduntur. Primo quidem, ut veritatem circa aliquid apprehendat. Et hoc non est in potestate nostra, hoc enim contingit per virtutem alicuius luminis, vel naturalis vel supernaturalis. Et ideo quantum ad hoc, actus rationis non est in potestate nostra, nec imperari potest. Alius autem actus rationis est, dum his quae apprehendit assentit. Si igitur fuerint talia apprehensa, quibus naturaliter intellectus assentiat, sicut prima principia, assensus talium vel dissensus non est in potestate nostra, sed in ordine naturae, et ideo, proprie loquendo, nec imperio subiacet. Sunt autem quaedam apprehensa, quae non adeo convincunt intellectum, quin possit assentire vel dissentire, vel saltem assensum vel dissensum suspendere, propter aliquam causam, et in talibus assensus ipse vel dissensus in potestate nostra est, et sub imperio cadit.

###### ad 1
Ad primum ergo dicendum quod ratio hoc modo imperat sibi ipsi, sicut et voluntas movet seipsam, ut supra dictum est, inquantum scilicet utraque potentia reflectitur supra suum actum, et ex uno in aliud tendit.

###### ad 2
Ad secundum dicendum quod, propter diversitatem obiectorum quae actui rationis subduntur, nihil prohibet rationem seipsam participare, sicut in cognitione conclusionum participatur cognitio principiorum.

###### ad 3
Ad tertium patet responsio ex dictis.

