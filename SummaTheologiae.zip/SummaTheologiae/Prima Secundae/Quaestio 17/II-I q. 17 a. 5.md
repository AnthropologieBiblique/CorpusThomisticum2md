### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod actus voluntatis non sit imperatus. Dicit enim Augustinus, in VIII Confess., *imperat animus ut velit animus, nec tamen facit*. Velle autem est actus voluntatis. Ergo actus voluntatis non imperatur.

###### arg. 2
Praeterea, ei convenit imperari, cui convenit imperium intelligere. Sed voluntatis non est intelligere imperium, differt enim voluntas ab intellectu, cuius est intelligere. Ergo actus voluntatis non imperatur.

###### arg. 3
Praeterea, si aliquis actus voluntatis imperatur, pari ratione omnes imperantur. Sed si omnes actus voluntatis imperantur, necesse est in infinitum procedere, quia actus voluntatis praecedit actum imperantis rationis, ut dictum est; qui voluntatis actus si iterum imperatur, illud iterum imperium praecedet alius rationis actus, et sic in infinitum. Hoc autem est inconveniens, quod procedatur in infinitum. Non ergo actus voluntatis imperatur.

###### s. c.
Sed contra, omne quod est in potestate nostra, subiacet imperio nostro. Sed actus voluntatis sunt maxime in potestate nostra, nam omnes actus nostri intantum dicuntur in potestate nostra esse, inquantum voluntarii sunt. Ergo actus voluntatis imperantur a nobis.

###### co.
Respondeo dicendum quod, sicut dictum est, imperium nihil aliud est quam actus rationis ordinantis, cum quadam motione, aliquid ad agendum. Manifestum est autem quod ratio potest ordinare de actu voluntatis, sicut enim potest iudicare quod bonum sit aliquid velle, ita potest ordinare imperando quod homo velit. Ex quo patet quod actus voluntatis potest esse imperatus.

###### ad 1
Ad primum ergo dicendum quod, sicut Augustinus ibidem dicit, animus, quando perfecte imperat sibi ut velit, tunc iam vult, sed quod aliquando imperet et non velit, hoc contingit ex hoc quod non perfecte imperat. Imperfectum autem imperium contingit ex hoc, quod ratio ex diversis partibus movetur ad imperandum vel non imperandum, unde fluctuat inter duo, et non perfecte imperat.

###### ad 2
Ad secundum dicendum quod, sicut in membris corporalibus quodlibet membrum operatur non sibi soli, sed toti corpori, ut oculus videt toti corpori; ita etiam est in potentiis animae. Nam intellectus intelligit non solum sibi, sed omnibus potentiis; et voluntas vult non solum sibi, sed omnibus potentiis. Et ideo homo imperat sibi ipsi actum voluntatis, inquantum est intelligens et volens.

###### ad 3
Ad tertium dicendum quod, cum imperium sit actus rationis, ille actus imperatur, qui rationi subditur. Primus autem voluntatis actus non est ex rationis ordinatione, sed ex instinctu naturae, aut superioris causae, ut supra dictum est. Et ideo non oportet quod in infinitum procedatur.

