### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod usus praecedat imperium. Imperium enim est actus rationis praesupponens actum voluntatis, ut supra dictum est. Sed usus est actus voluntatis, ut supra dictum est. Ergo usus praecedit imperium.

###### arg. 2
Praeterea, imperium est aliquid eorum quae ad finem ordinantur. Eorum autem quae sunt ad finem, est usus. Ergo videtur quod usus sit prius quam imperium.

###### arg. 3
Praeterea, omnis actus potentiae motae a voluntate, usus dicitur, quia voluntas utitur aliis potentiis, ut supra dictum est. Sed imperium est actus rationis prout mota est a voluntate, sicut dictum est. Ergo imperium est quidam usus. Commune autem est prius proprio. Ergo usus est prius quam imperium.

###### s. c.
Sed contra est quod Damascenus dicit, quod impetus ad operationem praecedit usum. Sed impetus ad operationem fit per imperium. Ergo imperium praecedit usum.

###### co.
Respondeo dicendum quod usus eius quod est ad finem, secundum quod est in ratione referente ipsum in finem, praecedit electionem, ut supra dictum est. Unde multo magis praecedit imperium. Sed usus eius quod est ad finem, secundum quod subditur potentiae executivae, sequitur imperium, eo quod usus utentis coniunctus est cum actu eius quo quis utitur; non enim utitur aliquis baculo, antequam aliquo modo per baculum operetur. Imperium autem non est simul cum actu eius cui imperatur, sed naturaliter prius est imperium quam imperio obediatur, et aliquando etiam est prius tempore. Unde manifestum est quod imperium est prius quam usus.

###### ad 1
Ad primum ergo dicendum quod non omnis actus voluntatis praecedit hunc actum rationis qui est imperium, sed aliquis praecedit, scilicet electio; et aliquis sequitur, scilicet usus. Quia post determinationem consilii, quae est iudicium rationis, voluntas eligit; et post electionem, ratio imperat ei per quod agendum est quod eligitur; et tunc demum voluntas alicuius incipit uti, exequendo imperium rationis; quandoque quidem voluntas alterius, cum aliquis imperat alteri; quandoque autem voluntas ipsius imperantis, cum aliquis imperat sibi ipsi.

###### ad 2
Ad secundum dicendum quod, sicut actus sunt praevii potentiis, ita obiecta actibus. Obiectum autem usus est id quod est ad finem. Ex hoc ergo quod ipsum imperium est ad finem, magis potest concludi quod imperium sit prius usu, quam quod sit posterius.

###### ad 3
Ad tertium dicendum quod, sicut actus voluntatis utentis ratione ad imperandum, praecedit ipsum imperium; ita etiam potest dici quod et istum usum voluntatis praecedit aliquod imperium rationis, eo quod actus harum potentiarum supra seipsos invicem reflectuntur.

