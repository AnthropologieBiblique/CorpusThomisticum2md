### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod imperare conveniat brutis animalibus. Quia secundum Avicennam, *virtus imperans motum est appetitiva, et virtus exequens motum est in musculis et in nervis*. Sed utraque virtus est in brutis animalibus. Ergo imperium invenitur in brutis animalibus.

###### arg. 2
Praeterea, de ratione servi est quod ei imperetur. Sed corpus comparatur ad animam sicut servus ad dominum, sicut dicit philosophus in I Polit. Ergo corpori imperatur ab anima, etiam in brutis, quae sunt composita ex anima et corpore.

###### arg. 3
Praeterea, per imperium homo facit impetum ad opus. Sed impetus in opus invenitur in brutis animalibus, ut Damascenus dicit. Ergo in brutis animalibus invenitur imperium.

###### s. c.
Sed contra, imperium est actus rationis, ut dictum est. Sed in brutis non est ratio. Ergo neque imperium.

###### co.
Respondeo dicendum quod imperare nihil aliud est quam ordinare aliquem ad aliquid agendum, cum quadam intimativa motione. Ordinare autem est proprius actus rationis. Unde impossibile est quod in brutis animalibus, in quibus non est ratio, sit aliquo modo imperium.

###### ad 1
Ad primum ergo dicendum quod vis appetitiva dicitur imperare motum, inquantum movet rationem imperantem. Sed hoc est solum in hominibus. In brutis autem animalibus virtus appetitiva non est proprie imperativa, nisi imperativum sumatur large pro motivo.

###### ad 2
Ad secundum dicendum quod in brutis animalibus corpus quidem habet unde obediat, sed anima non habet unde imperet, quia non habet unde ordinet. Et ideo non est ibi ratio imperantis et imperati; sed solum moventis et moti.

###### ad 3
Ad tertium dicendum quod aliter invenitur impetus ad opus in brutis animalibus, et aliter in hominibus. Homines enim faciunt impetum ad opus per ordinationem rationis, unde habet in eis impetus rationem imperii. In brutis autem fit impetus ad opus per instinctum naturae, quia scilicet appetitus eorum statim apprehenso convenienti vel inconvenienti, naturaliter movetur ad prosecutionem vel fugam. Unde ordinantur ab alio ad agendum, non autem ipsa seipsa ordinant ad actionem. Et ideo in eis est impetus, sed non imperium.

