### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod imperare non sit actus rationis, sed voluntatis. Imperare enim est movere quoddam, dicit enim Avicenna quod quadruplex est movens, scilicet perficiens, disponens, imperans et consilians. Sed ad voluntatem pertinet movere omnes alias vires animae, ut dictum est supra. Ergo imperare est actus voluntatis.

###### arg. 2
Praeterea, sicut imperari pertinet ad id quod est subiectum, ita imperare pertinere videtur ad id quod est maxime liberum. Sed radix libertatis est maxime in voluntate. Ergo voluntatis est imperare.

###### arg. 3
Praeterea, ad imperium statim sequitur actus. Sed ad actum rationis non statim sequitur actus, non enim qui iudicat aliquid esse faciendum, statim illud operatur. Ergo imperare non est actus rationis, sed voluntatis.

###### s. c.
Sed contra est quod Gregorius Nyssenus dicit, et etiam philosophus quod appetitivum obedit rationi. Ergo rationis est imperare.

###### co.
Respondeo dicendum quod imperare est actus rationis, praesupposito tamen actu voluntatis. Ad cuius evidentiam, considerandum est quod, quia actus voluntatis et rationis supra se invicem possunt ferri, prout scilicet ratio ratiocinatur de volendo, et voluntas vult ratiocinari; contingit actum voluntatis praeveniri ab actu rationis, et e converso. Et quia virtus prioris actus remanet in actu sequenti, contingit quandoque quod est aliquis actus voluntatis, secundum quod manet virtute in ipso aliquid de actu rationis, ut dictum est de usu et de electione; et e converso aliquis est actus rationis, secundum quod virtute manet in ipso aliquid de actu voluntatis. Imperare autem est quidem essentialiter actus rationis, imperans enim ordinat eum cui imperat, ad aliquid agendum, intimando vel denuntiando; sic autem ordinare per modum cuiusdam intimationis, est rationis. Sed ratio potest aliquid intimare vel denuntiare dupliciter. Uno modo, absolute, quae quidem intimatio exprimitur per verbum indicativi modi; sicut si aliquis alicui dicat, hoc est tibi faciendum. Aliquando autem ratio intimat aliquid alicui, movendo ipsum ad hoc, et talis intimatio exprimitur per verbum imperativi modi; puta cum alicui dicitur, fac hoc. Primum autem movens in viribus animae ad exercitium actus, est voluntas, ut supra dictum est. Cum ergo secundum movens non moveat nisi in virtute primi moventis, sequitur quod hoc ipsum quod ratio movet imperando, sit ei ex virtute voluntatis. Unde relinquitur quod imperare sit actus rationis, praesupposito actu voluntatis, in cuius virtute ratio movet per imperium ad exercitium actus.

###### ad 1
Ad primum ergo dicendum quod imperare non est movere quocumque modo, sed cum quadam intimatione denuntiativa ad alterum. Quod est rationis.

###### ad 2
Ad secundum dicendum quod radix libertatis est voluntas sicut subiectum, sed sicut causa, est ratio. Ex hoc enim voluntas libere potest ad diversa ferri, quia ratio potest habere diversas conceptiones boni. Et ideo philosophi definiunt liberum arbitrium quod est liberum de ratione iudicium, quasi ratio sit causa libertatis.

###### ad 3
Ad tertium dicendum quod ratio illa concludit quod imperium non sit actus rationis absolute, sed cum quadam motione, ut dictum est.

