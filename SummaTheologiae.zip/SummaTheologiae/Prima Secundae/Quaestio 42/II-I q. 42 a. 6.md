### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod ea quae non habent remedium, non sint magis timenda. Ad timorem enim requiritur quod remaneat aliqua spes salutis, ut supra dictum est. Sed in malis quae non habent remedium, nulla remanet spes salutis. Ergo talia mala nullo modo timentur.

###### arg. 2
Praeterea, malo mortis nullum remedium adhiberi potest, non enim, secundum naturam, potest esse reditus a morte ad vitam. Non tamen mors maxime timetur, ut dicit philosophus, in II Rhetoric. Non ergo ea magis timentur quae remedium non habent.

###### arg. 3
Praeterea, philosophus dicit, in I Ethic., quod *non est magis bonum quod est diuturnius, eo quod est unius diei, neque quod est perpetuum, eo quod non est perpetuum*. Ergo, eadem ratione, neque maius malum. Sed ea quae non habent remedium, non videntur differre ab aliis nisi propter diuturnitatem vel perpetuitatem. Ergo propter hoc non sunt peiora, vel magis timenda.

###### s. c.
Sed contra est quod philosophus dicit, in II Rhetoric., quod *omnia timenda sunt terribiliora quaecumque, si peccaverint, corrigi non contingit; aut quorum auxilia non sunt; aut non facilia*.

###### co.
Respondeo dicendum quod obiectum timoris est malum, unde illud quod facit ad augmentum mali, facit ad augmentum timoris. Malum autem augetur non solum secundum speciem ipsius mali, sed etiam secundum circumstantias, ut ex supra dictis apparet. Inter ceteras autem circumstantias, diuturnitas, vel etiam perpetuitas, magis videtur facere ad augmentum mali. Ea enim quae sunt in tempore, secundum durationem temporis quodammodo mensurantur, unde si pati aliquid in tanto tempore est malum, pati idem in duplo tempore apprehenditur ut duplatum. Et secundum hanc rationem, pati idem in infinito tempore, quod est perpetuo pati, habet quodammodo infinitum augmentum. Mala autem quae, postquam advenerint, non possunt habere remedium, vel non de facili, accipiuntur ut perpetua vel diuturna. Et ideo maxime redduntur timenda.

###### ad 1
Ad primum ergo dicendum quod remedium mali est duplex. Unum, per quod impeditur futurum malum, ne adveniat. Et tali remedio sublato, aufertur spes, et per consequens timor. Unde de tali remedio nunc non loquimur. Aliud remedium mali est, quo malum iam praesens removetur. Et de tali remedio nunc loquimur.

###### ad 2
Ad secundum dicendum quod, licet mors sit irremediabile malum, tamen, quia non imminet de prope, non timetur, ut supra dictum est.

###### ad 3
Ad tertium dicendum quod philosophus ibi loquitur de per se bono, quod est bonum secundum speciem suam. Sic autem non fit aliquid magis bonum propter diuturnitatem vel perpetuitatem, sed propter naturam ipsius boni.

