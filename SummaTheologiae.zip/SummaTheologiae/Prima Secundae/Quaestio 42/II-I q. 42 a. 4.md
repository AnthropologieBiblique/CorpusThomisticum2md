### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod timor timeri non possit. Omne enim quod timetur, timendo custoditur, ne amittatur, sicut ille qui timet amittere sanitatem timendo custodit eam. Si igitur timor timeatur, timendo se custodiet homo ne timeat. Quod videtur esse inconveniens.

###### arg. 2
Praeterea, timor est quaedam fuga. Sed nihil fugit seipsum. Ergo timor non timet timorem.

###### arg. 3
Praeterea, timor est de futuro. Sed ille qui timet, iam habet timorem. Non ergo potest timere timorem.

###### s. c.
Sed contra est quod homo potest amare amorem, et dolere de dolore. Ergo etiam, pari ratione, potest timere timorem.

###### co.
Respondeo dicendum quod, sicut dictum est, illud solum habet rationem terribilis, quod ex causa extrinseca provenit, non autem quod provenit ex voluntate nostra. Timor autem partim provenit ex causa extrinseca, et partim subiacet voluntati. Provenit quidem ex causa extrinseca, inquantum est passio quaedam consequens phantasiam imminentis mali. Et secundum hoc, potest aliquis timere timorem, ne scilicet immineat ei necessitas timendi, propter ingruentiam alicuius excellentis mali. Subiacet autem voluntati, inquantum appetitus inferior obedit rationi, unde homo potest timorem repellere. Et secundum hoc, timor non potest timeri, ut dicit Augustinus, in libro octoginta trium quaest. Sed quia rationibus quas inducit, aliquis posset uti ad ostendendum quod timor nullo modo timeatur, ideo ad eas respondendum est.

###### ad 1
Ad primum ergo dicendum quod, non omnis timor est unus timor, sed secundum diversa quae timentur, sunt diversi timores. Nihil ergo prohibet quin uno timore aliquis praeservet se ab alio timore, et sic custodiat se non timentem illo timore.

###### ad 2
Ad secundum dicendum quod, cum sit alius timor quo timetur malum imminens, et alius timor quo timetur ipse timor mali imminentis; non sequitur quod idem fugiat seipsum, vel quod sit idem fuga sui ipsius.

###### ad 3
Ad tertium dicendum quod propter diversitatem timorum iam dictam, timore praesenti potest homo timere futurum timorem.

