### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod insolita et repentina non sint magis terribilia. Sicut enim spes est de bono, ita timor est de malo. Sed experientia facit ad augmentum spei in bonis. Ergo etiam facit ad augmentum timoris in malis.

###### arg. 2
Praeterea, philosophus dicit, in II Rhetoric., quod magis timentur non qui acutae sunt irae, sed mites et astuti. Constat autem quod illi qui acutae irae sunt, magis habent subitos motus. Ergo ea quae sunt subita, sunt minus terribilia.

###### arg. 3
Praeterea, quae sunt subita, minus considerari possunt. Sed tanto aliqua magis timentur, quanto magis considerantur, unde philosophus dicit, in III Ethic., quod *aliqui videntur fortes propter ignorantiam, qui, si cognoverint quod aliud sit quam suspicantur, fugiunt*. Ergo repentina minus timentur.

###### s. c.
Sed contra est quod Augustinus dicit, in II Confess., *timor insolita et repentina exhorrescit, rebus quae amantur adversantia, dum praecavet securitati*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, obiectum timoris est malum imminens quod non de facili repelli potest. Hoc autem ex duobus contingit, scilicet ex magnitudine mali, et ex debilitate timentis. Ad utrumque autem horum operatur quod aliquid sit insolitum et repentinum. Primo quidem, facit ad hoc quod malum imminens maius appareat. Omnia enim corporalia, et bona et mala, quanto magis considerantur, minora apparent. Et ideo, sicut propter diuturnitatem dolor praesentis mali mitigatur, ut patet per Tullium in III de Tusculanis quaest.; ita etiam ex praemeditatione minuitur timor futuri mali. Secundo, aliquid esse insolitum et repentinum facit ad debilitatem timentis, inquantum subtrahit remedia quae homo potest praeparare ad repellendum futurum malum, quae esse non possunt quando ex improviso malum occurrit.

###### ad 1
Ad primum ergo dicendum quod obiectum spei est bonum quod quis potest adipisci. Et ideo ea quae augmentant potestatem hominis, nata sunt augere spem, et eadem ratione, diminuere timorem, quia timor est de malo cui non de facili potest resisti. Quia igitur experientia facit hominem magis potentem ad operandum, ideo, sicut auget spem, ita diminuit timorem.

###### ad 2
Ad secundum dicendum quod illi qui habent iram acutam, non occultant eam, et ideo nocumenta ab eis illata non ita sunt repentina, quin praevideantur. Sed homines mites et astuti occultant iram, et ideo nocumentum quod ab eis imminet, non potest praevideri, sed ex improviso advenit. Et propter hoc philosophus dicit quod tales magis timentur.

###### ad 3
Ad tertium dicendum quod, per se loquendo, bona vel mala corporalia in principio maiora apparent. Cuius ratio est, quia unumquodque magis apparet, contrario iuxta se posito. Unde cum aliquis statim a paupertate ad divitias transit, propter paupertatem praeexistentem divitias magis aestimat, et e contrario divites statim ad paupertatem devenientes, eam magis horrent. Et propter hoc, malum repentinum magis timetur, quia magis videtur esse malum. Sed potest propter aliquod accidens contingere quod magnitudo alicuius mali lateat, puta cum hostes se insidiose occultant. Et tunc verum est quod malum ex diligenti consideratione fit terribilius.

