### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod bonum sit obiectum timoris. Dicit enim Augustinus, in libro octoginta trium quaest., quod *nihil timemus, nisi ne id quod amamus, aut adeptum amittamus, aut non adipiscamur speratum*. Sed id quod amamus est bonum. Ergo timor respicit bonum sicut proprium obiectum.

###### arg. 2
Praeterea, philosophus dicit, in II Rhetoric., quod *potestas, et super alium ipsum esse, est terribile*. Sed huiusmodi est quoddam bonum. Ergo bonum est obiectum timoris.

###### arg. 3
Praeterea, in Deo nihil malum esse potest. Sed mandatur nobis ut Deum timeamus; secundum illud [[Ps 33]], *timete dominum, omnes sancti eius*. Ergo etiam timor est de bono.

###### s. c.
Sed contra est quod Damascenus dicit, in II libro, quod timor est de malo futuro.

###### co.
Respondeo dicendum quod timor est quidam motus appetitivae virtutis. Ad virtutem autem appetitivam pertinet prosecutio et fuga, ut dicitur in VI Ethic. Est autem prosecutio boni. Fuga autem mali. Unde quicumque motus appetitivae virtutis importat prosecutionem, habet aliquod bonum pro obiecto, quicumque autem importat fugam, habet malum pro obiecto. Unde, cum timor fugam quandam importet, primo et per se respicit malum sicut proprium obiectum. Potest autem respicere etiam bonum, secundum quod habet habitudinem ad malum. Quod quidem potest esse dupliciter. Uno quidem modo, inquantum per malum privatur bonum. Ex hoc autem ipso est aliquid malum, quod est privativum boni. Unde, cum fugiatur malum quia malum est, sequitur ut fugiatur quia privat bonum quod quis amando prosequitur. Et secundum hoc dicit Augustinus quod nulla est causa timendi, nisi ne amittatur bonum amatum. Alio modo comparatur bonum ad malum, ut causa ipsius, inquantum scilicet aliquod bonum sua virtute potest inducere aliquod nocumentum in bono amato. Et ideo, sicut spes, ut supra dictum est, ad duo respicit, scilicet ad bonum in quod tendit, et ad id per quod sperat se bonum concupitum adipisci; ita etiam timor ad duo respicit, scilicet ad malum quod refugit, et ad illud bonum quod sua virtute potest infligere malum. Et per hunc modum Deus timetur ab homine, inquantum potest infligere poenam, vel spiritualem vel corporalem. Per hunc etiam modum timetur potestas alicuius hominis, maxime quando est laesa, vel quando est iniusta, quia sic in promptu habet nocumentum inferre. Ita etiam timetur super alium esse, idest inniti alii, ut scilicet in eius potestate sic constitutum nobis nocumentum inferre, sicut ille qui est conscius criminis, timetur, ne crimen revelet.

###### ad 
Et per hoc patet responsio ad obiecta.

