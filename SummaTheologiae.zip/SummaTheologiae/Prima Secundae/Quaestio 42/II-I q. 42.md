## Quaestio 42

### Prooemium

Deinde considerandum est de obiecto timoris. Et circa hoc quaeruntur sex. Primo, utrum bonum sit obiectum timoris, vel malum. Secundo, utrum malum naturae sit obiectum timoris. Tertio, utrum timor sit de malo culpae. Quarto, utrum ipse timor timeri possit. Quinto, utrum repentina magis timeantur. Sexto, utrum ea contra quae non est remedium, magis timeantur.

![[II-I q. 42 a. 1#Articulus 1]]

![[II-I q. 42 a. 2#Articulus 2]]

![[II-I q. 42 a. 3#Articulus 3]]

![[II-I q. 42 a. 4#Articulus 4]]

![[II-I q. 42 a. 5#Articulus 5]]

![[II-I q. 42 a. 6#Articulus 6]]

