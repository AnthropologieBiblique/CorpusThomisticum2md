## Quaestio 56

### Prooemium

Deinde considerandum est de subiecto virtutis. Et circa hoc quaeruntur sex. Primo, utrum virtus sit in potentia animae sicut in subiecto. Secundo, utrum una virtus possit esse in pluribus potentiis. Tertio, utrum intellectus possit esse subiectum virtutis. Quarto, utrum irascibilis et concupiscibilis. Quinto, utrum vires apprehensivae sensitivae. Sexto, utrum voluntas.

![[II-I q. 56 a. 1#Articulus 1]]

![[II-I q. 56 a. 2#Articulus 2]]

![[II-I q. 56 a. 3#Articulus 3]]

![[II-I q. 56 a. 4#Articulus 4]]

![[II-I q. 56 a. 5#Articulus 5]]

![[II-I q. 56 a. 6#Articulus 6]]

