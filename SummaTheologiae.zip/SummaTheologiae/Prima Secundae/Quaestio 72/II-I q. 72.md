## Quaestio 72

### Prooemium

Deinde considerandum est de distinctione peccatorum vel vitiorum. Et circa hoc quaeruntur novem. Primo, utrum peccata distinguantur specie secundum obiecta. Secundo, de distinctione peccatorum spiritualium et carnalium. Tertio, utrum secundum causas. Quarto, utrum secundum eos in quos peccatur. Quinto, utrum secundum diversitatem reatus. Sexto, utrum secundum omissionem et commissionem. Septimo, utrum secundum diversum processum peccati. Octavo, utrum secundum abundantiam et defectum. Nono, utrum secundum diversas circumstantias.

![[II-I q. 72 a. 1#Articulus 1]]

![[II-I q. 72 a. 2#Articulus 2]]

![[II-I q. 72 a. 3#Articulus 3]]

![[II-I q. 72 a. 4#Articulus 4]]

![[II-I q. 72 a. 5#Articulus 5]]

![[II-I q. 72 a. 6#Articulus 6]]

![[II-I q. 72 a. 7#Articulus 7]]

![[II-I q. 72 a. 8#Articulus 8]]

