### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod inconvenienter peccatum distinguatur per peccatum quod est in Deum, in proximum, et in seipsum. Illud enim quod est commune omni peccato, non debet poni quasi pars in divisione peccati. Sed commune est omni peccato quod sit contra Deum, ponitur enim in definitione peccati quod sit contra legem Dei, ut supra dictum est. Non ergo peccatum in Deum debet poni quasi pars in divisione peccatorum.

###### arg. 2
Praeterea, omnis divisio debet fieri per opposita. Sed ista tria genera peccatorum non sunt opposita, quicumque enim peccat in proximum, peccat etiam in seipsum et in Deum. Non ergo peccatum convenienter dividitur secundum haec tria.

###### arg. 3
Praeterea, ea quae sunt extrinsecus, non conferunt speciem. Sed Deus et proximus sunt extra nos. Ergo per haec non distinguuntur peccata secundum speciem. Inconvenienter igitur secundum haec tria peccatum dividitur.

###### s. c.
Sed contra est quod Isidorus, in libro de summo bono, distinguens peccata, dicit quod *homo dicitur peccare in se, in Deum, et in proximum*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, peccatum est actus inordinatus. Triplex autem ordo in homine debet esse. Unus quidem secundum comparationem ad regulam rationis, prout scilicet omnes actiones et passiones nostrae debent secundum regulam rationis commensurari. Alius autem ordo est per comparationem ad regulam divinae legis, per quam homo in omnibus dirigi debet. Et si quidem homo naturaliter esset animal solitarium, hic duplex ordo sufficeret, sed quia homo est naturaliter animal politicum et sociale, ut probatur in I Polit., ideo necesse est quod sit tertius ordo, quo homo ordinetur ad alios homines, quibus convivere debet. Horum autem ordinum secundus continet primum, et excedit ipsum. Quaecumque enim continentur sub ordine rationis, continentur sub ordine ipsius Dei, sed quaedam continentur sub ordine ipsius Dei, quae excedunt rationem humanam, sicut ea quae sunt fidei, et quae debentur soli Deo. Unde qui in talibus peccat, dicitur in Deum peccare, sicut haereticus et sacrilegus et blasphemus. Similiter etiam secundus ordo includit tertium, et excedit ipsum. Quia in omnibus in quibus ordinamur ad proximum, oportet nos dirigi secundum regulam rationis, sed in quibusdam dirigimur secundum rationem quantum ad nos tantum, non autem quantum ad proximum. Et quando in his peccatur, dicitur homo peccare in seipsum, sicut patet de guloso, luxurioso et prodigo. Quando vero peccat homo in his quibus ad proximum ordinatur, dicitur peccare in proximum, sicut patet de fure et homicida. Sunt autem diversa quibus homo ordinatur ad Deum, et ad proximum, et ad seipsum. Unde haec distinctio peccatorum est secundum obiecta, secundum quae diversificantur species peccatorum. Unde haec distinctio peccatorum proprie est secundum diversas peccatorum species. Nam et virtutes, quibus peccata opponuntur, secundum hanc differentiam specie distinguuntur, manifestum est enim ex dictis quod virtutibus theologicis homo ordinatur ad Deum, temperantia vero et fortitudine ad seipsum, iustitia autem ad proximum.

###### ad 1
Ad primum ergo dicendum quod peccare in Deum, secundum quod ordo qui est ad Deum, includit omnem humanum ordinem, commune est omni peccato. Sed quantum ad id quod ordo Dei excedit alios duos ordines, sic peccatum in Deum est speciale genus peccati.

###### ad 2
Ad secundum dicendum quod quando aliqua quorum unum includit alterum, ab invicem distinguuntur, intelligitur fieri distinctio non secundum illud quod unum continetur in altero, sed secundum illud quod unum excedit alterum. Sicut patet in divisione numerorum et figurarum, non enim triangulus dividitur contra quadratum secundum quod continetur in eo, sed secundum quod exceditur ab eo; et similiter est de ternario et quaternario.

###### ad 3
Ad tertium dicendum quod Deus et proximus, quamvis sint exteriora respectu ipsius peccantis, non tamen sunt extranea respectu actus peccati; sed comparantur ad ipsum sicut propria obiecta ipsius.

