### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod bonum et malum quod est ex fine, non diversificent speciem in actibus. Actus enim habent speciem ex obiecto. Sed finis est praeter rationem obiecti. Ergo bonum et malum quod est ex fine, non diversificant speciem actus.

###### arg. 2
Praeterea, id quod est per accidens, non constituit speciem, ut dictum est. Sed accidit alicui actui quod ordinetur ad aliquem finem; sicut quod aliquis det eleemosynam propter inanem gloriam. Ergo secundum bonum et malum quod est ex fine, non diversificantur actus secundum speciem.

###### arg. 3
Praeterea, diversi actus secundum speciem, ad unum finem ordinari possunt, sicut ad finem inanis gloriae ordinari possunt actus diversarum virtutum, et diversorum vitiorum. Non ergo bonum et malum quod accipitur secundum finem, diversificat speciem actuum.

###### s. c.
Sed contra est quod supra ostensum est, quod actus humani habent speciem a fine. Ergo bonum et malum quod accipitur secundum finem, diversificat speciem actuum.

###### co.
Respondeo dicendum quod aliqui actus dicuntur humani, inquantum sunt voluntarii, sicut supra dictum est. In actu autem voluntario invenitur duplex actus, scilicet actus interior voluntatis, et actus exterior, et uterque horum actuum habet suum obiectum. Finis autem proprie est obiectum interioris actus voluntarii, id autem circa quod est actio exterior, est obiectum eius. Sicut igitur actus exterior accipit speciem ab obiecto circa quod est; ita actus interior voluntatis accipit speciem a fine, sicut a proprio obiecto. Ita autem quod est ex parte voluntatis, se habet ut formale ad id quod est ex parte exterioris actus, quia voluntas utitur membris ad agendum, sicut instrumentis; neque actus exteriores habent rationem moralitatis, nisi inquantum sunt voluntarii. Et ideo actus humani species formaliter consideratur secundum finem, materialiter autem secundum obiectum exterioris actus. Unde philosophus dicit, in V Ethic., quod *ille qui furatur ut committat adulterium, est, per se loquendo, magis adulter quam fur*.

###### ad 1
Ad primum ergo dicendum quod etiam finis habet rationem obiecti, ut dictum est.

###### ad 2
Ad secundum dicendum quod ordinari ad talem finem, etsi accidat exteriori actui, non tamen accidit actui interiori voluntatis, qui comparatur ad exteriorem sicut formale ad materiale.

###### ad 3
Ad tertium dicendum quod quando multi actus specie differentes ordinantur ad unum finem, est quidem diversitas speciei ex parte exteriorum actuum; sed unitas speciei ex parte actus interioris.

