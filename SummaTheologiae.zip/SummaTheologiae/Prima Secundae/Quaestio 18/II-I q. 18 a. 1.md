### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod omnis actio hominis sit bona, et nulla sit mala. Dicit enim Dionysius, IV cap. de Div. Nom., quod malum non agit nisi virtute boni. Sed virtute boni non fit malum. Ergo nulla actio est mala.

###### arg. 2
Praeterea, nihil agit nisi secundum quod est actu. Non est autem aliquid malum secundum quod est actu, sed secundum quod potentia privatur actu, inquantum autem potentia perficitur per actum, est bonum, ut dicitur in IX Metaphys. Nihil ergo agit inquantum est malum, sed solum inquantum est bonum. Omnis ergo actio est bona, et nulla mala.

###### arg. 3
Praeterea, malum non potest esse causa nisi per accidens, ut patet per Dionysium, IV cap. de Div. Nom. Sed omnis actionis est aliquis per se effectus. Nulla ergo actio est mala, sed omnis actio est bona.

###### s. c.
Sed contra est quod dominus dicit, [[Jn 3]], *omnis qui male agit, odit lucem*. Est ergo aliqua actio hominis mala.

###### co.
Respondeo dicendum quod de bono et malo in actionibus oportet loqui sicut de bono et malo in rebus, eo quod unaquaeque res talem actionem producit, qualis est ipsa. In rebus autem unumquodque tantum habet de bono, quantum habet de esse, bonum enim et ens convertuntur, ut in primo dictum est. Solus autem Deus habet totam plenitudinem sui esse secundum aliquid unum et simplex, unaquaeque vero res alia habet plenitudinem essendi sibi convenientem secundum diversa. Unde in aliquibus contingit quod quantum ad aliquid habent esse, et tamen eis aliquid deficit ad plenitudinem essendi eis debitam. Sicut ad plenitudinem esse humani requiritur quod sit quoddam compositum ex anima et corpore, habens omnes potentias et instrumenta cognitionis et motus, unde si aliquid horum deficiat alicui homini deficit ei aliquid de plenitudine sui esse. Quantum igitur habet de esse, tantum habet de bonitate, inquantum vero aliquid ei deficit de plenitudine essendi, intantum deficit a bonitate, et dicitur malum, sicut homo caecus habet de bonitate quod vivit, et malum est ei quod caret visu. Si vero nihil haberet de entitate vel bonitate, neque malum neque bonum dici posset. Sed quia de ratione boni est ipsa plenitudo essendi, si quidem alicui aliquid defuerit de debita essendi plenitudine, non dicetur simpliciter bonum, sed secundum quid, inquantum est ens, poterit tamen dici simpliciter ens et secundum quid non ens, ut in primo dictum est. Sic igitur dicendum est quod omnis actio, inquantum habet aliquid de esse, intantum habet de bonitate, inquantum vero deficit ei aliquid de plenitudine essendi quae debetur actioni humanae, intantum deficit a bonitate, et sic dicitur mala, puta si deficiat ei vel determinata quantitas secundum rationem, vel debitus locus, vel aliquid huiusmodi.

###### ad 1
Ad primum ergo dicendum quod malum agit in virtute boni deficientis. Si enim nihil esset ibi de bono, neque esset ens, neque agere posset. Si autem non esset deficiens, non esset malum. Unde et actio causata est quoddam bonum deficiens, quod secundum quid est bonum, simpliciter autem malum.

###### ad 2
Ad secundum dicendum quod nihil prohibet aliquid esse secundum quid in actu, unde agere possit; et secundum aliud privari actu, unde causet deficientem actionem. Sicut homo caecus actu habet virtutem gressivam, per quam ambulare potest, sed inquantum caret visu, qui dirigit in ambulando, patitur defectum in ambulando, dum ambulat cespitando.

###### ad 3
Ad tertium dicendum quod actio mala potest habere aliquem effectum per se, secundum id quod habet de bonitate et entitate. Sicut adulterium est causa generationis humanae, inquantum habet commixtionem maris et feminae, non autem inquantum caret ordine rationis.

