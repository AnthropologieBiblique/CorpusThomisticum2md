## Quaestio 18

### Prooemium

Post hoc considerandum est de bonitate et malitia humanorum actuum. Et primo, quomodo actio humana sit bona vel mala; secundo, de his quae consequuntur ad bonitatem vel malitiam humanorum actuum, puta meritum vel demeritum, peccatum et culpa. Circa primum occurrit triplex consideratio, prima est de bonitate et malitia humanorum actuum in generali; secunda, de bonitate et malitia interiorum actuum; tertia, de bonitate et malitia exteriorum actuum. Circa primum quaeruntur undecim. Primo, utrum omnis actio sit bona, vel aliqua sit mala. Secundo, utrum actio hominis habeat quod sit bona vel mala, ex obiecto. Tertio, utrum hoc habeat ex circumstantia. Quarto, utrum hoc habeat ex fine. Quinto, utrum aliqua actio hominis sit bona vel mala in sua specie. Sexto, utrum actus habeat speciem boni vel mali ex fine. Septimo, utrum species quae est ex fine, contineatur sub specie quae est ex obiecto, sicut sub genere, aut e converso. Octavo, utrum sit aliquis actus indifferens secundum suam speciem. Nono, utrum aliquis actus sit indifferens secundum individuum. Decimo, utrum aliqua circumstantia constituat actum moralem in specie boni vel mali. Undecimo, utrum omnis circumstantia augens bonitatem vel malitiam, constituat actum moralem in specie boni vel mali.

![[II-I q. 18 a. 1#Articulus 1]]

![[II-I q. 18 a. 2#Articulus 2]]

![[II-I q. 18 a. 3#Articulus 3]]

![[II-I q. 18 a. 4#Articulus 4]]

![[II-I q. 18 a. 5#Articulus 5]]

![[II-I q. 18 a. 6#Articulus 6]]

![[II-I q. 18 a. 7#Articulus 7]]

![[II-I q. 18 a. 8#Articulus 8]]

![[II-I q. 18 a. 9#Articulus 9]]

![[II-I q. 18 a. 10#Articulus 10]]

![[II-I q. 18 a. 11#Articulus 11]]

