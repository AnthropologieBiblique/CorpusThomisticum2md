### Articulus 10

###### arg. 1
Ad decimum sic proceditur. Videtur quod circumstantia non possit constituere aliquam speciem boni vel mali actus. Species enim actus est ex obiecto. Sed circumstantiae differunt ab obiecto. Ergo circumstantiae non dant speciem actus.

###### arg. 2
Praeterea, circumstantiae comparantur ad actum moralem sicut accidentia eius, ut dictum est. Sed accidens non constituit speciem. Ergo circumstantia non constituit aliquam speciem boni vel mali.

###### arg. 3
Praeterea, unius rei non sunt plures species. Unius autem actus sunt plures circumstantiae. Ergo circumstantia non constituit actum moralem in aliqua specie boni vel mali.

###### s. c.
Sed contra, locus est circumstantia quaedam. Sed locus constituit actum moralem in quadam specie mali, furari enim aliquid de loco sacro est sacrilegium. Ergo circumstantia constituit actum moralem in aliqua specie boni vel mali.

###### co.
Respondeo dicendum quod, sicut species rerum naturalium constituuntur ex naturalibus formis, ita species moralium actuum constituuntur ex formis prout sunt a ratione conceptae, sicut ex supradictis patet. Quia vero natura determinata est ad unum, nec potest esse processus naturae in infinitum, necesse est pervenire ad aliquam ultimam formam, ex qua sumatur differentia specifica, post quam alia differentia specifica esse non possit. Et inde est quod in rebus naturalibus, id quod est accidens alicui rei, non potest accipi ut differentia constituens speciem. Sed processus rationis non est determinatus ad aliquid unum, sed quolibet dato, potest ulterius procedere. Et ideo quod in uno actu accipitur ut circumstantia superaddita obiecto quod determinat speciem actus, potest iterum accipi a ratione ordinante ut principalis conditio obiecti determinantis speciem actus. Sicut tollere alienum habet speciem ex ratione alieni, ex hoc enim constituitur in specie furti, et si consideretur super hoc ratio loci vel temporis, se habebit in ratione circumstantiae. Sed quia ratio etiam de loco vel de tempore, et aliis huiusmodi, ordinare potest; contingit conditionem loci circa obiectum accipi ut contrariam ordini rationis; puta quod ratio ordinat non esse iniuriam faciendam loco sacro. Unde tollere aliquid alienum de loco sacro addit specialem repugnantiam ad ordinem rationis. Et ideo locus, qui prius considerabatur ut circumstantia, nunc consideratur ut principalis conditio obiecti rationi repugnans. Et per hunc modum, quandocumque aliqua circumstantia respicit specialem ordinem rationis vel pro vel contra, oportet quod circumstantia det speciem actui morali vel bono vel malo.

###### ad 1
Ad primum ergo dicendum quod circumstantia secundum quod dat speciem actui, consideratur ut quaedam conditio obiecti, sicut dictum est, et quasi quaedam specifica differentia eius.

###### ad 2
Ad secundum dicendum quod circumstantia manens in ratione circumstantiae, cum habeat rationem accidentis, non dat speciem, sed inquantum mutatur in principalem conditionem obiecti, secundum hoc dat speciem.

###### ad 3
Ad tertium dicendum quod non omnis circumstantia constituit actum moralem in aliqua specie boni vel mali, cum non quaelibet circumstantia importet aliquam consonantiam vel dissonantiam ad rationem. Unde non oportet, licet sint multae circumstantiae unius actus, quod unus actus sit in pluribus speciebus. Licet etiam non sit inconveniens quod unus actus moralis sit in pluribus speciebus moris etiam disparatis, ut dictum est.

