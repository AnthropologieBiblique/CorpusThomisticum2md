### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod actio non habeat bonitatem vel malitiam ex obiecto. Obiectum enim actionis est res. In rebus autem non est malum, sed in usu peccantium, ut Augustinus dicit in libro III de Doct. Christ. Ergo actio humana non habet bonitatem vel malitiam ex obiecto.

###### arg. 2
Praeterea, obiectum comparatur ad actionem ut materia. Bonitas autem rei non est ex materia, sed magis ex forma, quae est actus. Ergo bonum et malum non est in actibus ex obiecto.

###### arg. 3
Praeterea, obiectum potentiae activae comparatur ad actionem sicut effectus ad causam. Sed bonitas causae non dependet ex effectu, sed magis e converso. Ergo actio humana non habet bonitatem vel malitiam ex obiecto.

###### s. c.
Sed contra est quod dicitur [[Os 9]], *facti sunt abominabiles, sicut ea quae dilexerunt*. Fit autem homo Deo abominabilis propter malitiam suae operationis. Ergo malitia operationis est secundum obiecta mala quae homo diligit. Et eadem ratio est de bonitate actionis.

###### co.
Respondeo dicendum quod, sicut dictum est, bonum et malum actionis, sicut et ceterarum rerum, attenditur ex plenitudine essendi vel defectu ipsius. Primum autem quod ad plenitudinem essendi pertinere videtur, est id quod dat rei speciem. Sicut autem res naturalis habet speciem ex sua forma, ita actio habet speciem ex obiecto; sicut et motus ex termino. Et ideo sicut prima bonitas rei naturalis attenditur ex sua forma, quae dat speciem ei, ita et prima bonitas actus moralis attenditur ex obiecto convenienti; unde et a quibusdam vocatur bonum ex genere; puta, uti re sua. Et sicut in rebus naturalibus primum malum est, si res generata non consequitur formam specificam, puta si non generetur homo, sed aliquid loco hominis; ita primum malum in actionibus moralibus est quod est ex obiecto, sicut accipere aliena. Et dicitur malum ex genere, genere pro specie accepto, eo modo loquendi quo dicimus humanum genus totam humanam speciem.

###### ad 1
Ad primum ergo dicendum quod, licet res exteriores sint in seipsis bonae, tamen non semper habent debitam proportionem ad hanc vel illam actionem. Et ideo inquantum considerantur ut obiecta talium actionum, non habent rationem boni.

###### ad 2
Ad secundum dicendum quod obiectum non est materia ex qua, sed materia circa quam, et habet quodammodo rationem formae, inquantum dat speciem.

###### ad 3
Ad tertium dicendum quod non semper obiectum actionis humanae est obiectum activae potentiae. Nam appetitiva potentia est quodammodo passiva, inquantum movetur ab appetibili, et tamen est principium humanorum actuum. Neque etiam potentiarum activarum obiecta semper habent rationem effectus, sed quando iam sunt transmutata, sicut alimentum transmutatum est effectus nutritivae potentiae, sed alimentum nondum transmutatum comparatur ad potentiam nutritivam sicut materia circa quam operatur. Ex hoc autem quod obiectum est aliquo modo effectus potentiae activae, sequitur quod sit terminus actionis eius, et per consequens quod det ei formam et speciem, motus enim habet speciem a terminis. Et quamvis etiam bonitas actionis non causetur ex bonitate effectus, tamen ex hoc dicitur actio bona, quod bonum effectum inducere potest. Et ita ipsa proportio actionis ad effectum, est ratio bonitatis ipsius.

