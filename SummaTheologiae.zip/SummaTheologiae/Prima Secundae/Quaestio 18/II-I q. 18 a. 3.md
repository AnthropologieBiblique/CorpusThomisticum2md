### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod actio non sit bona vel mala ex circumstantia. Circumstantiae enim circumstant actum sicut extra ipsum existentes, ut dictum est. Sed bonum et malum sunt in ipsis rebus, ut dicitur in VI Metaphys. Ergo actio non habet bonitatem vel malitiam ex circumstantia.

###### arg. 2
Praeterea, bonitas vel malitia actus maxime consideratur in doctrina morum. Sed circumstantiae, cum sint quaedam accidentia actuum, videntur esse praeter considerationem artis, quia nulla ars considerat id quod est per accidens, ut dicitur in VI Metaphys. Ergo bonitas vel malitia actionis non est ex circumstantia.

###### arg. 3
Praeterea, id quod convenit alicui secundum suam substantiam, non attribuitur ei per aliquod accidens. Sed bonum et malum convenit actioni secundum suam substantiam, quia actio ex suo genere potest esse bona vel mala, ut dictum est. Ergo non convenit actioni ex circumstantia quod sit bona vel mala.

###### s. c.
Sed contra est quod philosophus dicit, in libro Ethic., quod *virtuosus operatur secundum quod oportet, et quando oportet, et secundum alias circumstantias*. Ergo ex contrario vitiosus, secundum unumquodque vitium, operatur quando non oportet, ubi non oportet, et sic de aliis circumstantiis. Ergo actiones humanae secundum circumstantias sunt bonae vel malae.

###### co.
Respondeo dicendum quod in rebus naturalibus non invenitur tota plenitudo perfectionis quae debetur rei, ex forma substantiali, quae dat speciem; sed multum superadditur ex supervenientibus accidentibus, sicut in homine ex figura, ex colore, et huiusmodi; quorum si aliquod desit ad decentem habitudinem, consequitur malum. Ita etiam est in actione. Nam plenitudo bonitatis eius non tota consistit in sua specie, sed aliquid additur ex his quae adveniunt tanquam accidentia quaedam. Et huiusmodi sunt circumstantiae debitae. Unde si aliquid desit quod requiratur ad debitas circumstantias, erit actio mala.

###### ad 1
Ad primum ergo dicendum quod circumstantiae sunt extra actionem, inquantum non sunt de essentia actionis, sunt tamen in ipsa actione velut quaedam accidentia eius. Sicut et accidentia quae sunt in substantiis naturalibus, sunt extra essentias earum.

###### ad 2
Ad secundum dicendum quod non omnia accidentia per accidens se habent ad sua subiecta, sed quaedam sunt per se accidentia; quae in unaquaque arte considerantur. Et per hunc modum considerantur circumstantiae actuum in doctrina morali.

###### ad 3
Ad tertium dicendum quod, cum bonum convertatur cum ente, sicut ens dicitur secundum substantiam et secundum accidens, ita et bonum attribuitur alicui et secundum esse suum essentiale, et secundum esse accidentale, tam in rebus naturalibus, quam in actionibus moralibus.

