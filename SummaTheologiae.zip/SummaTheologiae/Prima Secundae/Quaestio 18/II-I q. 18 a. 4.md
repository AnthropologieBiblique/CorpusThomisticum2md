### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod bonum et malum in actibus humanis non sint ex fine. Dicit enim Dionysius, IV cap. de Div. Nom., quod *nihil respiciens ad malum operatur*. Si igitur ex fine derivaretur operatio bona vel mala, nulla actio esset mala. Quod patet esse falsum.

###### arg. 2
Praeterea, bonitas actus est aliquid in ipso existens. Finis autem est causa extrinseca. Non ergo secundum finem dicitur actio bona vel mala.

###### arg. 3
Praeterea, contingit aliquam bonam operationem ad malum finem ordinari, sicut cum aliquis dat eleemosynam propter inanem gloriam, et e converso aliquam malam operationem ordinari ad bonum finem, sicut cum quis furatur ut det pauperi. Non ergo est ex fine actio bona vel mala.

###### s. c.
Sed contra est quod Boetius dicit, in Topic., quod *cuius finis bonus est, ipsum quoque bonum est, et cuius finis malus est, ipsum quoque malum est*.

###### co.
Respondeo dicendum quod eadem est dispositio rerum in bonitate, et in esse. Sunt enim quaedam quorum esse ex alio non dependet, et in his sufficit considerare ipsum eorum esse absolute. Quaedam vero sunt quorum esse dependet ab alio, unde oportet quod consideretur per considerationem ad causam a qua dependet. Sicut autem esse rei dependet ab agente et forma, ita bonitas rei dependet a fine. Unde in personis divinis, quae non habent bonitatem dependentem ab alio, non consideratur aliqua ratio bonitatis ex fine. Actiones autem humanae, et alia quorum bonitas dependet ab alio, habent rationem bonitatis ex fine a quo dependent, praeter bonitatem absolutam quae in eis existit. Sic igitur in actione humana bonitas quadruplex considerari potest. Una quidem secundum genus, prout scilicet est actio, quia quantum habet de actione et entitate, tantum habet de bonitate, ut dictum est. Alia vero secundum speciem, quae accipitur secundum obiectum conveniens. Tertia secundum circumstantias, quasi secundum accidentia quaedam. Quarta autem secundum finem, quasi secundum habitudinem ad causam bonitatis.

###### ad 1
Ad primum ergo dicendum quod bonum ad quod aliquis respiciens operatur, non semper est verum bonum; sed quandoque verum bonum, et quandoque apparens. Et secundum hoc, ex fine sequitur actio mala.

###### ad 2
Ad secundum dicendum quod, quamvis finis sit causa extrinseca, tamen debita proportio ad finem et relatio in ipsum, inhaeret actioni.

###### ad 3
Ad tertium dicendum quod nihil prohibet actioni habenti unam praedictarum bonitatum, deesse aliam. Et secundum hoc, contingit actionem quae est bona secundum speciem suam vel secundum circumstantias, ordinari ad finem malum, et e converso. Non tamen est actio bona simpliciter, nisi omnes bonitates concurrant, quia *quilibet singularis defectus causat malum, bonum autem causatur ex integra causa*, ut Dionysius dicit, IV cap. de Div. Nom.

