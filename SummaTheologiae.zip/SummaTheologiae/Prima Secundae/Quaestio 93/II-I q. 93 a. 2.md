### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod lex aeterna non sit omnibus nota. Quia ut dicit apostolus, I ad Cor., *quae sunt Dei, nemo novit nisi spiritus Dei*. Sed lex aeterna est quaedam ratio in mente divina existens. Ergo omnibus est ignota nisi soli Deo.

###### arg. 2
Praeterea, sicut Augustinus dicit, in libro de Lib. Arb., *lex aeterna est qua iustum est ut omnia sint ordinatissima*. Sed non omnes cognoscunt qualiter omnia sint ordinatissima. Non ergo omnes cognoscunt legem aeternam.

###### arg. 3
Praeterea, Augustinus dicit, in libro de vera Relig., quod *lex aeterna est de qua homines iudicare non possunt*. Sed sicut in I Ethic. dicitur, *unusquisque bene iudicat quae cognoscit*. Ergo lex aeterna non est nobis nota.

###### s. c.
Sed contra est quod Augustinus dicit, in libro de Lib. Arb., quod *aeternae legis notio nobis impressa est*.

###### co.
Respondeo dicendum quod dupliciter aliquid cognosci potest, uno modo, in seipso; alio modo, in suo effectu, in quo aliqua similitudo eius invenitur; sicut aliquis non videns solem in sua substantia, cognoscit ipsum in sua irradiatione. Sic igitur dicendum est quod legem aeternam nullus potest cognoscere secundum quod in seipsa est, nisi solum beati, qui Deum per essentiam vident. Sed omnis creatura rationalis ipsam cognoscit secundum aliquam eius irradiationem, vel maiorem vel minorem. Omnis enim cognitio veritatis est quaedam irradiatio et participatio legis aeternae, quae est veritas incommutabilis, ut Augustinus dicit, in libro de vera Relig. Veritatem autem omnes aliqualiter cognoscunt, ad minus quantum ad principia communia legis naturalis. In aliis vero quidam plus et quidam minus participant de cognitione veritatis; et secundum hoc etiam plus vel minus cognoscunt legem aeternam.

###### ad 1
Ad primum ergo dicendum quod ea quae sunt Dei, in seipsis quidem cognosci a nobis non possunt, sed tamen in effectibus suis nobis manifestantur, secundum illud [[Rm 1]], *invisibilia Dei per ea quae facta sunt, intellecta, conspiciuntur*.

###### ad 2
Ad secundum dicendum quod legem aeternam etsi unusquisque cognoscat pro sua capacitate, secundum modum praedictum, nullus tamen eam comprehendere potest, non enim totaliter manifestari potest per suos effectus. Et ideo non oportet quod quicumque cognoscit legem aeternam secundum modum praedictum, cognoscat totum ordinem rerum, quo omnia sunt ordinatissima.

###### ad 3
Ad tertium dicendum quod iudicare de aliquo potest intelligi dupliciter. Uno modo, sicut vis cognitiva diiudicat de proprio obiecto; secundum illud [[Jb 12]], *nonne auris verba diiudicat, et fauces comedentis saporem?* Et secundum istum modum iudicii, philosophus dicit quod unusquisque bene iudicat quae cognoscit, iudicando scilicet an sit verum quod proponitur. Alio modo, secundum quod superior iudicat de inferiori quodam practico iudicio, an scilicet ita debeat esse vel non ita. Et sic nullus potest iudicare de lege aeterna.

