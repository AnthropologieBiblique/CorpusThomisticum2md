## Quaestio 93

### Prooemium

Deinde considerandum est de singulis legibus. Et primo, de lege aeterna; secundo, de lege naturali; tertio, de lege humana; quarto, de lege veteri; quinto, de lege nova, quae est lex Evangelii. De sexta autem lege, quae est lex fomitis, sufficiat quod dictum est cum de peccato originali ageretur. Circa primum quaeruntur sex. Primo, quid sit lex aeterna. Secundo, utrum sit omnibus nota. Tertio, utrum omnis lex ab ea derivetur. Quarto, utrum necessaria subiiciantur legi aeternae. Quinto, utrum contingentia naturalia subiiciantur legi aeternae. Sexto, utrum omnes res humanae ei subiiciantur.

![[II-I q. 93 a. 1#Articulus 1]]

![[II-I q. 93 a. 2#Articulus 2]]

![[II-I q. 93 a. 3#Articulus 3]]

![[II-I q. 93 a. 4#Articulus 4]]

![[II-I q. 93 a. 5#Articulus 5]]

