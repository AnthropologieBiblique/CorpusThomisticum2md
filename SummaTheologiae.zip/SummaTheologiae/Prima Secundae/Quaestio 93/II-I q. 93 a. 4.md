### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod necessaria et aeterna subiiciantur legi aeternae. Omne enim quod rationabile est, rationi subditur. Sed voluntas divina est rationabilis, cum sit iusta. Ergo rationi subditur. Sed lex aeterna est ratio divina. Ergo voluntas Dei subditur legi aeternae. Voluntas autem Dei est aliquod aeternum. Ergo etiam aeterna et necessaria legi aeternae subduntur.

###### arg. 2
Praeterea, quidquid subiicitur regi, subiicitur legi regis. *Filius autem*, ut dicitur I ad Cor. XV, *subiectus erit Deo et patri, cum tradiderit ei regnum*. Ergo filius, qui est aeternus, subiicitur legi aeternae.

###### arg. 3
Praeterea, lex aeterna est ratio divinae providentiae. Sed multa necessaria subduntur divinae providentiae, sicut permanentia substantiarum incorporalium et corporum caelestium. Ergo legi aeternae subduntur etiam necessaria.

###### s. c.
Sed contra, ea quae sunt necessaria, impossibile est aliter se habere, unde cohibitione non indigent. Sed imponitur hominibus lex ut cohibeantur a malis, ut ex supradictis patet. Ergo ea quae sunt necessaria, legi non subduntur.

###### co.
Respondeo dicendum quod, sicut supra dictum est, lex aeterna est ratio divinae gubernationis. Quaecumque ergo divinae gubernationi subduntur, subiiciuntur etiam legi aeternae, quae vero gubernationi aeternae non subduntur, neque legi aeternae subduntur. Horum autem distinctio attendi potest ex his quae circa nos sunt. Humanae enim gubernationi subduntur ea quae per homines fieri possunt, quae vero ad naturam hominis pertinent, non subduntur gubernationi humanae, scilicet quod homo habeat animam, vel manus aut pedes. Sic igitur legi aeternae subduntur omnia quae sunt in rebus a Deo creatis, sive sint contingentia sive sint necessaria, ea vero quae pertinent ad naturam vel essentiam divinam, legi aeternae non subduntur, sed sunt realiter ipsa lex aeterna.

###### ad 1
Ad primum ergo dicendum quod de voluntate Dei dupliciter possumus loqui. Uno modo, quantum ad ipsam voluntatem, et sic, cum voluntas Dei sit ipsa eius essentia, non subditur gubernationi divinae neque legi aeternae, sed est idem quod lex aeterna. Alio modo possumus loqui de voluntate divina quantum ad ipsa quae Deus vult circa creaturas, quae quidem subiecta sunt legi aeternae, inquantum horum ratio est in divina sapientia. Et ratione horum, voluntas Dei dicitur rationabilis. Alioquin, ratione sui ipsius, magis est dicenda ipsa ratio.

###### ad 2
Ad secundum dicendum quod filius Dei non est a Deo factus, sed naturaliter ab ipso genitus. Et ideo non subditur divinae providentiae aut legi aeternae, sed magis ipse est lex aeterna per quandam appropriationem, ut patet per Augustinum, in libro de vera Relig. Dicitur autem esse subiectus patri ratione humanae naturae, secundum quam etiam pater dicitur esse maior eo.

###### ad 3
Tertium concedimus, quia procedit de necessariis creatis.

###### ad 4
Ad quartum dicendum quod, sicut philosophus dicit, in V Metaphys., quaedam necessaria habent causam suae necessitatis, et sic hoc ipsum quod impossibile est ea aliter esse, habent ab alio. Et hoc ipsum est cohibitio quaedam efficacissima, nam quaecumque cohibentur, intantum cohiberi dicuntur, inquantum non possunt aliter facere quam de eis disponatur.

