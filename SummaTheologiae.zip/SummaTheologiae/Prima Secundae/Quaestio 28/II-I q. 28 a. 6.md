### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod amans non agat omnia ex amore. Amor enim quaedam passio est, ut supra dictum est. Sed non omnia quae agit homo, agit ex passione, sed quaedam agit ex electione, et quaedam ex ignorantia, ut dicitur in V Ethic. Ergo non omnia quae homo agit, agit ex amore.

###### arg. 2
Praeterea, appetitus est principium motus et actionis in omnibus animalibus, ut patet in III de anima. Si igitur omnia quae quis agit, agit ex amore, aliae passiones appetitivae partis erunt superfluae.

###### arg. 3
Praeterea, nihil causatur simul a contrariis causis. Sed quaedam fiunt ex odio. Non ergo omnia sunt ex amore.

###### s. c.
Sed contra est quod Dionysius dicit, IV cap. de Div. Nom., quod *propter amorem boni omnia agunt quaecumque agunt*.

###### co.
Respondeo dicendum quod omne agens agit propter finem aliquem, ut supra dictum est. Finis autem est bonum desideratum et amatum unicuique. Unde manifestum est quod omne agens, quodcumque sit, agit quamcumque actionem ex aliquo amore.

###### ad 1
Ad primum ergo dicendum quod obiectio illa procedit de amore qui est passio in appetitu sensitivo existens. Nos autem loquimur nunc de amore communiter accepto, prout comprehendit sub se amorem intellectualem, rationalem, animalem, naturalem, sic enim Dionysius loquitur de amore in IV cap. de Div. Nom.

###### ad 2
Ad secundum dicendum quod ex amore, sicut iam dictum est, causantur et desiderium et tristitia et delectatio, et per consequens omnes aliae passiones. Unde omnis actio quae procedit ex quacumque passione, procedit etiam ex amore, sicut ex prima causa. Unde non superfluunt aliae passiones, quae sunt causae proximae.

###### ad 3
Ad tertium dicendum quod odium etiam ex amore causatur, sicut infra dicetur.

