## Quaestio 28

### Prooemium

Deinde considerandum est de effectibus amoris. Et circa hoc quaeruntur sex. Primo, utrum unio sit effectus amoris. Secundo, utrum mutua inhaesio. Tertio, utrum extasis sit effectus amoris. Quarto, utrum zelus. Quinto, utrum amor sit passio laesiva amantis. Sexto, utrum amor sit causa omnium quae amans agit.

![[II-I q. 28 a. 1#Articulus 1]]

![[II-I q. 28 a. 2#Articulus 2]]

![[II-I q. 28 a. 3#Articulus 3]]

![[II-I q. 28 a. 4#Articulus 4]]

![[II-I q. 28 a. 5#Articulus 5]]

![[II-I q. 28 a. 6#Articulus 6]]

