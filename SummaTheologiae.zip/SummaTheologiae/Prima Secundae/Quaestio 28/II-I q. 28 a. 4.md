### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod zelus non sit effectus amoris. Zelus enim est contentionis principium, unde dicitur I ad Cor. III, *cum sit inter vos zelus et contentio,* et cetera. Sed contentio repugnat amori. Ergo zelus non est effectus amoris.

###### arg. 2
Praeterea obiectum amoris est bonum, quod est communicativum sui. Sed zelus repugnat communicationi, ad zelum enim pertinere videtur quod aliquis non patiatur consortium in amato; sicut viri dicuntur zelare uxores, quas nolunt habere communes cum ceteris. Ergo zelus non est effectus amoris.

###### arg. 3
Praeterea, zelus non est sine odio, sicut nec sine amore, dicitur enim in Psalmo LXXII, *zelavi super iniquos*. Non ergo debet dici magis effectus amoris quam odii.

###### s. c.
Sed contra est quod Dionysius dicit, IV cap. de Div. Nom., quod *Deus appellatur Zelotes propter multum amorem quem habet ad existentia*.

###### co.
Respondeo dicendum quod zelus, quocumque modo sumatur, ex intensione amoris provenit. Manifestum est enim quod quanto aliqua virtus intensius tendit in aliquid, fortius etiam repellit omne contrarium vel repugnans. Cum igitur amor sit quidam motus in amatum, ut Augustinus dicit in libro octoginta trium quaest., intensus amor quaerit excludere omne quod sibi repugnat. Aliter tamen hoc contingit in amore concupiscentiae, et aliter in amore amicitiae. Nam in amore concupiscentiae, qui intense aliquid concupiscit, movetur contra omne illud quod repugnat consecutioni vel fruitioni quietae eius quod amatur. Et hoc modo viri dicuntur zelare uxores, ne per consortium aliorum impediatur singularitas quam in uxore quaerunt. Similiter etiam qui quaerunt excellentiam, moventur contra eos qui excellere videntur, quasi impedientes excellentiam eorum. Et iste est zelus invidiae, de quo dicitur in Psalmo XXXVI, *noli aemulari in malignantibus, neque zelaveris facientes iniquitatem*. Amor autem amicitiae quaerit bonum amici, unde quando est intensus, facit hominem moveri contra omne illud quod repugnat bono amici. Et secundum hoc, aliquis dicitur zelare pro amico, quando, si qua dicuntur vel fiunt contra bonum amici, homo repellere studet. Et per hunc etiam modum aliquis dicitur zelare pro Deo, quando ea quae sunt contra honorem vel voluntatem Dei, repellere secundum posse conatur; secundum illud [[1R 19]], *zelo zelatus sum pro domino exercituum*. Et [[Jn 2]], super illud, *zelus domus tuae comedit me*, dicit Glossa quod *bono zelo comeditur, qui quaelibet prava quae viderit, corrigere satagit; si nequit, tolerat et gemit*.

###### ad 1
Ad primum ergo dicendum quod apostolus ibi loquitur de zelo invidiae; qui quidem est causa contentionis, non contra rem amatam, sed pro re amata contra impedimenta ipsius.

###### ad 2
Ad secundum dicendum quod bonum amatur inquantum est communicabile amanti. Unde omne illud quod perfectionem huius communicationis impedit, efficitur odiosum. Et sic ex amore boni zelus causatur. Ex defectu autem bonitatis contingit quod quaedam parva bona non possunt integre simul possideri a multis. Et ex amore talium causatur zelus invidiae. Non autem proprie ex his quae integre possunt a multis possideri, nullus enim invidet alteri de cognitione veritatis, quae a multis integre cognosci potest; sed forte de excellentia circa cognitionem huius.

###### ad 3
Ad tertium dicendum quod hoc ipsum quod aliquis odio habet ea quae repugnant amato, ex amore procedit. Unde zelus proprie ponitur effectus amoris magis quam odii.

