### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod extasis non sit effectus amoris. Extasis enim quandam alienationem importare videtur. Sed amor non semper facit alienationem, sunt enim amantes interdum sui compotes. Ergo amor non facit extasim.

###### arg. 2
Praeterea, amans desiderat amatum sibi uniri. Magis ergo amatum trahit ad se, quam etiam pergat in amatum, extra se exiens.

###### arg. 3
Praeterea, amor unit amatum amanti, sicut dictum est. Si ergo amans extra se tendit, ut in amatum pergat, sequitur quod semper plus diligat amatum quam seipsum. Quod patet esse falsum. Non ergo extasis est effectus amoris.

###### s. c.
Sed contra est quod Dionysius dicit, IV cap. de Div. Nom., quod *divinus amor extasim facit, et quod ipse Deus propter amorem est extasim passus*. Cum ergo quilibet amor sit quaedam similitudo participata divini amoris, ut ibidem dicitur, videtur quod quilibet amor causet extasim.

###### co.
Respondeo dicendum quod extasim pati aliquis dicitur, cum extra se ponitur. Quod quidem contingit et secundum vim apprehensivam, et secundum vim appetitivam. Secundum quidem vim apprehensivam aliquis dicitur extra se poni, quando ponitur extra cognitionem sibi propriam, vel quia ad superiorem sublimatur, sicut homo, dum elevatur ad comprehendenda aliqua quae sunt supra sensum et rationem, dicitur extasim pati, inquantum ponitur extra connaturalem apprehensionem rationis et sensus; vel quia ad inferiora deprimitur; puta, cum aliquis in furiam vel amentiam cadit, dicitur extasim passus. Secundum appetitivam vero partem dicitur aliquis extasim pati, quando appetitus alicuius in alterum fertur, exiens quodammodo extra seipsum. Primam quidem extasim facit amor dispositive, inquantum scilicet facit meditari de amato, ut dictum est, intensa autem meditatio unius abstrahit ab aliis. Sed secundam extasim facit amor directe, simpliciter quidem amor amicitiae; amor autem concupiscentiae non simpliciter, sed secundum quid. Nam in amore concupiscentiae, quodammodo fertur amans extra seipsum, inquantum scilicet, non contentus gaudere de bono quod habet, quaerit frui aliquo extra se. Sed quia illud extrinsecum bonum quaerit sibi habere, non exit simpliciter extra se, sed talis affectio in fine infra ipsum concluditur. Sed in amore amicitiae, affectus alicuius simpliciter exit extra se, quia vult amico bonum, et operatur, quasi gerens curam et providentiam ipsius, propter ipsum amicum.

###### ad 1
Ad primum ergo dicendum quod illa ratio procedit de prima extasi.

###### ad 2
Ad secundum dicendum quod illa ratio procedit de amore concupiscentiae, qui non facit simpliciter extasim, ut dictum est.

###### ad 3
Ad tertium dicendum quod ille qui amat, intantum extra se exit, inquantum vult bona amici et operatur. Non tamen vult bona amici magis quam sua. Unde non sequitur quod alterum plus quam se diligat.

