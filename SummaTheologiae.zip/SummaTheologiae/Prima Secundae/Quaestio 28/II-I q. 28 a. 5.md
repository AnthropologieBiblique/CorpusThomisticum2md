### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod amor sit passio laesiva. Languor enim significat laesionem quandam languentis. Sed amor causat languorem, dicitur enim [[Ct 2]], *fulcite me floribus, stipate me malis, quia amore langueo*. Ergo amor est passio laesiva.

###### arg. 2
Praeterea, liquefactio est quaedam resolutio. Sed amor est liquefactivus, dicitur enim [[Ct 5]], *anima mea liquefacta est, ut dilectus meus locutus est*. Ergo amor est resolutivus. Est ergo corruptivus et laesivus.

###### arg. 3
Praeterea, fervor designat quendam excessum in caliditate, qui quidem excessus corruptivus est. Sed fervor causatur ex amore, Dionysius enim, VII cap. Cael. Hier., inter ceteras proprietates ad amorem Seraphim pertinentes, ponit calidum et acutum et superfervens. Et [[Ct 8]], dicitur de amore quod *lampades eius sunt lampades ignis atque flammarum*. Ergo amor est passio laesiva et corruptiva.

###### s. c.
Sed contra est quod dicit Dionysius, IV cap. de Div. Nom., quod singula seipsa amant contentive, idest conservative. Ergo amor non est passio laesiva, sed magis conservativa et perfectiva.

###### co.
Respondeo dicendum quod, sicut supra dictum est, amor significat coaptationem quandam appetitivae virtutis ad aliquod bonum. Nihil autem quod coaptatur ad aliquid quod est sibi conveniens, ex hoc ipso laeditur, sed magis, si sit possibile, proficit et melioratur. Quod vero coaptatur ad aliquid quod non est sibi conveniens, ex hoc ipso laeditur et deterioratur. Amor ergo boni convenientis est perfectivus et meliorativus amantis, amor autem boni quod non est conveniens amanti, est laesivus et deteriorativus amantis. Unde maxime homo perficitur et melioratur per amorem Dei, laeditur autem et deterioratur per amorem peccati, secundum illud [[Os 9]], *facti sunt abominabiles, sicut ea quae dilexerunt*. Et hoc quidem dictum sit de amore, quantum ad id quod est formale in ipso, quod est scilicet ex parte appetitus. Quantum vero ad id quod est materiale in passione amoris, quod est immutatio aliqua corporalis, accidit quod amor sit laesivus propter excessum immutationis, sicut accidit in sensu, et in omni actu virtutis animae qui exercetur per aliquam immutationem organi corporalis.

###### ad 1
Ad ea vero quae in contrarium obiiciuntur, dicendum quod amori attribui possunt quatuor effectus proximi, scilicet liquefactio, fruitio, languor et fervor. Inter quae primum est liquefactio, quae opponitur congelationi. Ea enim quae sunt congelata, in seipsis constricta sunt, ut non possint de facili subintrationem alterius pati. Ad amorem autem pertinet quod appetitus coaptetur ad quandam receptionem boni amati, prout amatum est in amante, sicut iam supra dictum est. Unde cordis congelatio vel duritia est dispositio repugnans amori. Sed liquefactio importat quandam mollificationem cordis, qua exhibet se cor habile ut amatum in ipsum subintret. Si ergo amatum fuerit praesens et habitum, causatur delectatio sive fruitio. Si autem fuerit absens, consequuntur duae passiones, scilicet tristitia de absentia, quae significatur per languorem (unde et Tullius, in III de Tusculanis quaest., maxime tristitiam aegritudinem nominat); et intensum desiderium de consecutione amati, quod significatur per fervorem. Et isti quidem sunt effectus amoris formaliter accepti, secundum habitudinem appetitivae virtutis ad obiectum. Sed in passione amoris, consequuntur aliqui effectus his proportionati, secundum immutationem organi.

