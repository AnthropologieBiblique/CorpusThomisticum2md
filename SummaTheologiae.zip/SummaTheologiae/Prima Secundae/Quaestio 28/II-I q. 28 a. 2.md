### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod amor non causet mutuam inhaesionem, ut scilicet amans sit in amato, et e converso. Quod enim est in altero, continetur in eo. Sed non potest idem esse continens et contentum. Ergo per amorem non potest causari mutua inhaesio, ut amatum sit in amante et e converso.

###### arg. 2
Praeterea, nihil potest penetrare in interiora alicuius integri, nisi per aliquam divisionem. Sed dividere quae sunt secundum rem coniuncta, non pertinet ad appetitum, in quo est amor, sed ad rationem. Ergo mutua inhaesio non est effectus amoris.

###### arg. 3
Praeterea, si per amorem amans est in amato et e converso, sequetur quod hoc modo amatum uniatur amanti, sicut amans amato. Sed ipsa unio est amor, ut dictum est. Ergo sequitur quod semper amans ametur ab amato, quod patet esse falsum. Non ergo mutua inhaesio est effectus amoris.

###### s. c.
Sed contra est quod dicitur [[1 Jn 4]], *qui manet in caritate, in Deo manet, et Deus in eo*. Caritas autem est amor Dei. Ergo, eadem ratione, quilibet amor facit amatum esse in amante, et e converso.

###### co.
Respondeo dicendum quod iste effectus mutuae inhaesionis potest intelligi et quantum ad vim apprehensivam, et quantum ad vim appetitivam. Nam quantum ad vim apprehensivam amatum dicitur esse in amante, inquantum amatum immoratur in apprehensione amantis; secundum illud [[Ph 1]], *eo quod habeam vos in corde*. Amans vero dicitur esse in amato secundum apprehensionem inquantum amans non est contentus superficiali apprehensione amati, sed nititur singula quae ad amatum pertinent intrinsecus disquirere, et sic ad interiora eius ingreditur. Sicut de spiritu sancto, qui est amor Dei, dicitur, I ad Cor. II, quod *scrutatur etiam profunda Dei*. Sed quantum ad vim appetitivam, amatum dicitur esse in amante, prout est per quandam complacentiam in eius affectu, ut vel delectetur in eo, aut in bonis eius, apud praesentiam; vel in absentia, per desiderium tendat in ipsum amatum per amorem concupiscentiae; vel in bona quae vult amato, per amorem amicitiae; non quidem ex aliqua extrinseca causa, sicut cum aliquis desiderat aliquid propter alterum, vel cum aliquis vult bonum alteri propter aliquid aliud; sed propter complacentiam amati interius radicatam. Unde et amor dicitur intimus; et dicuntur viscera caritatis. E converso autem amans est in amato aliter quidem per amorem concupiscentiae, aliter per amorem amicitiae. Amor namque concupiscentiae non requiescit in quacumque extrinseca aut superficiali adeptione vel fruitione amati, sed quaerit amatum perfecte habere, quasi ad intima illius perveniens. In amore vero amicitiae, amans est in amato, inquantum reputat bona vel mala amici sicut sua, et voluntatem amici sicut suam, ut quasi ipse in suo amico videatur bona vel mala pati, et affici. Et propter hoc, proprium est amicorum eadem velle, et in eodem tristari et gaudere secundum philosophum, in IX Ethic. et in II Rhetoric. Ut sic, inquantum quae sunt amici aestimat sua, amans videatur esse in amato, quasi idem factus amato. Inquantum autem e converso vult et agit propter amicum sicut propter seipsum, quasi reputans amicum idem sibi, sic amatum est in amante. Potest autem et tertio modo mutua inhaesio intelligi in amore amicitiae, secundum viam redamationis, inquantum mutuo se amant amici, et sibi invicem bona volunt et operantur.

###### ad 1
Ad primum ergo dicendum quod amatum continetur in amante, inquantum est impressum in affectu eius per quandam complacentiam. E converso vero amans continetur in amato, inquantum amans sequitur aliquo modo illud quod est intimum amati. Nihil enim prohibet diverso modo esse aliquid continens et contentum, sicut genus continetur in specie et e converso.

###### ad 2
Ad secundum dicendum quod rationis apprehensio praecedit affectum amoris. Et ideo, sicut ratio disquirit, ita affectus amoris subintrat in amatum, ut ex dictis patet.

###### ad 3
Ad tertium dicendum quod illa ratio procedit de tertio modo mutuae inhaesionis, qui non invenitur in quolibet amore.

