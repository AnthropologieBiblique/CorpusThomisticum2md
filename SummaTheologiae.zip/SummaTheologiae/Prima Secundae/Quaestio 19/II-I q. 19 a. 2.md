### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod bonitas voluntatis non dependeat solum ex obiecto. Finis enim affinior est voluntati quam alteri potentiae. Sed actus aliarum potentiarum recipiunt bonitatem non solum ex obiecto, sed etiam ex fine, ut ex supradictis patet. Ergo etiam actus voluntatis recipit bonitatem non solum ex obiecto, sed etiam ex fine.

###### arg. 2
Praeterea, bonitas actus non solum est ex obiecto, sed etiam ex circumstantiis, ut supra dictum est. Sed secundum diversitatem circumstantiarum contingit esse diversitatem bonitatis et malitiae in actu voluntatis, puta quod aliquis velit quando debet et ubi debet, et quantum debet, et quomodo debet, vel prout non debet. Ergo bonitas voluntatis non solum dependet ex obiecto, sed etiam ex circumstantiis.

###### arg. 3
Praeterea, ignorantia circumstantiarum excusat malitiam voluntatis, ut supra habitum est. Sed hoc non esset, nisi bonitas et malitia voluntatis a circumstantiis dependeret. Ergo bonitas et malitia voluntatis dependet ex circumstantiis, et non a solo obiecto.

###### s. c.
Sed contra, ex circumstantiis, inquantum huiusmodi, actus non habet speciem, ut supra dictum est. Sed bonum et malum sunt specificae differentiae actus voluntatis, ut dictum est. Ergo bonitas et malitia voluntatis non dependet ex circumstantiis, sed ex solo obiecto.

###### co.
Respondeo dicendum quod in quolibet genere, quanto aliquid est prius, tanto est simplicius et in paucioribus consistens, sicut prima corpora sunt simplicia. Et ideo invenimus quod ea quae sunt prima in quolibet genere, sunt aliquo modo simplicia, et in uno consistunt. Principium autem bonitatis et malitiae humanorum actuum est ex actu voluntatis. Et ideo bonitas et malitia voluntatis secundum aliquid unum attenditur, aliorum vero actuum bonitas et malitia potest secundum diversa attendi. Illud autem unum quod est principium in quolibet genere, non est per accidens, sed per se, quia omne quod est per accidens, reducitur ad id quod est per se, sicut ad principium. Et ideo bonitas voluntatis ex solo uno illo dependet, quod per se facit bonitatem in actu, scilicet ex obiecto, et non ex circumstantiis, quae sunt quaedam accidentia actus.

###### ad 1
Ad primum ergo dicendum quod finis est obiectum voluntatis, non autem aliarum virium. Unde quantum ad actum voluntatis, non differt bonitas quae est ex obiecto, a bonitate quae est ex fine, sicut in actibus aliarum virium, nisi forte per accidens, prout finis dependet ex fine, et voluntas ex voluntate.

###### ad 2
Ad secundum dicendum quod, supposito quod voluntas sit boni, nulla circumstantia potest eam facere malam. Quod ergo dicitur quod aliquis vult aliquod bonum quando non debet vel ubi non debet, potest intelligi dupliciter. Uno modo, ita quod ista circumstantia referatur ad volitum. Et sic voluntas non est boni, quia velle facere aliquid quando non debet fieri, non est velle bonum. Alio modo, ita quod referatur ad actum volendi. Et sic impossibile est quod aliquis velit bonum quando non debet, quia semper homo debet velle bonum, nisi forte per accidens, inquantum aliquis, volendo hoc bonum, impeditur ne tunc velit aliquod bonum debitum. Et tunc non incidit malum ex eo quod aliquis vult illud bonum; sed ex eo quod non vult aliud bonum. Et similiter dicendum est de aliis circumstantiis.

###### ad 3
Ad tertium dicendum quod circumstantiarum ignorantia excusat malitiam voluntatis, secundum quod circumstantiae se tenent ex parte voliti, inquantum scilicet ignorat circumstantias actus quem vult.

