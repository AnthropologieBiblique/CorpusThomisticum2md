### Articulus 9

###### arg. 1
Ad nonum sic proceditur. Videtur quod bonitas voluntatis humanae non dependeat ex conformitate voluntatis divinae. Impossibile est enim voluntatem hominis conformari voluntati divinae, ut patet per id quod dicitur [[Is 55]], *sicut exaltantur caeli a terra, ita exaltatae sunt viae meae a viis vestris, et cogitationes meae a cogitationibus vestris*. Si ergo ad bonitatem voluntatis requireretur conformitas ad divinam voluntatem, sequeretur quod impossibile esset hominis voluntatem esse bonam. Quod est inconveniens.

###### arg. 2
Praeterea, sicut voluntas nostra derivatur a voluntate divina, ita scientia nostra derivatur a scientia divina. Sed non requiritur ad scientiam nostram quod sit conformis scientiae divinae, multa enim Deus scit quae nos ignoramus. Ergo non requiritur quod voluntas nostra sit conformis voluntati divinae.

###### arg. 3
Praeterea, voluntas est actionis principium. Sed actio nostra non potest conformari actioni divinae. Ergo nec voluntas voluntati.

###### s. c.
Sed contra est quod dicitur [[Mt 26]], *non sicut ego volo, sed sicut tu vis*, quod dicit quia rectum vult esse hominem, et ad Deum dirigi, ut Augustinus exponit in Enchirid. Rectitudo autem voluntatis est bonitas eius. Ergo bonitas voluntatis dependet ex conformitate ad voluntatem divinam.

###### co.
Respondeo dicendum quod, sicut dictum est, bonitas voluntatis dependet ex intentione finis. Finis autem ultimus voluntatis humanae est summum bonum, quod est Deus, ut supra dictum est. Requiritur ergo ad bonitatem humanae voluntatis, quod ordinetur ad summum bonum, quod est Deus. Hoc autem bonum primo quidem et per se comparatur ad voluntatem divinam ut obiectum proprium eius. Illud autem quod est primum in quolibet genere, est mensura et ratio omnium quae sunt illius generis. Unumquodque autem rectum et bonum est, inquantum attingit ad propriam mensuram. Ergo ad hoc quod voluntas hominis sit bona, requiritur quod conformetur voluntati divinae.

###### ad 1
Ad primum ergo dicendum quod voluntas hominis non potest conformari voluntati divinae per aequiparantiam, sed per imitationem. Et similiter conformatur scientia hominis scientiae divinae, inquantum cognoscit verum. Et actio hominis actioni divinae, inquantum est agenti conveniens. Et hoc per imitationem, non autem per aequiparantiam.

###### ad 2
Unde patet solutio ad secundum, et ad tertium argumentum.

