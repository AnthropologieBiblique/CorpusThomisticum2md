## Quaestio 19

### Prooemium

Deinde considerandum est de bonitate actus interioris voluntatis. Et circa hoc quaeruntur decem. Primo, utrum bonitas voluntatis dependeat ex obiecto. Secundo, utrum ex solo obiecto dependeat. Tertio, utrum dependeat ex ratione. Quarto, utrum dependeat ex lege aeterna. Quinto, utrum ratio errans obliget. Sexto, utrum voluntas contra legem Dei sequens rationem errantem, sit mala. Septimo, utrum bonitas voluntatis in his quae sunt ad finem, dependeat ex intentione finis. Octavo, utrum quantitas bonitatis vel malitiae in voluntate, sequatur quantitatem boni vel mali in intentione. Nono, utrum bonitas voluntatis dependeat ex conformitate ad voluntatem divinam. Decimo, utrum necesse sit voluntatem humanam conformari divinae voluntati in volito, ad hoc quod sit bona.

![[II-I q. 19 a. 1#Articulus 1]]

![[II-I q. 19 a. 2#Articulus 2]]

![[II-I q. 19 a. 3#Articulus 3]]

![[II-I q. 19 a. 4#Articulus 4]]

![[II-I q. 19 a. 5#Articulus 5]]

![[II-I q. 19 a. 6#Articulus 6]]

![[II-I q. 19 a. 7#Articulus 7]]

![[II-I q. 19 a. 8#Articulus 8]]

![[II-I q. 19 a. 9#Articulus 9]]

![[II-I q. 19 a. 10#Articulus 10]]

