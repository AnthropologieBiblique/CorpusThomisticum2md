### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod bonitas voluntatis humanae non dependeat a lege aeterna. Unius enim una est regula et mensura. Sed regula humanae voluntatis, ex qua eius bonitas dependet, est ratio recta. Ergo non dependet bonitas voluntatis a lege aeterna.

###### arg. 2
Praeterea, mensura est homogenea mensurato, ut dicitur X Metaphys. Sed lex aeterna non est homogenea voluntati humanae. Ergo lex aeterna non potest esse mensura voluntatis humanae, ut ab ea bonitas eius dependeat.

###### arg. 3
Praeterea, mensura debet esse certissima. Sed lex aeterna est nobis ignota. Ergo non potest esse nostrae voluntatis mensura, ut ab ea bonitas voluntatis nostrae dependeat.

###### s. c.
Sed contra est quod Augustinus dicit, XXII libro contra Faustum, quod *peccatum est factum, dictum vel concupitum aliquid contra aeternam legem*. Sed malitia voluntatis est radix peccati. Ergo, cum malitia bonitati opponatur, bonitas voluntatis dependet a lege aeterna.

###### co.
Respondeo dicendum quod in omnibus causis ordinatis, effectus plus dependet a causa prima quam a causa secunda, quia causa secunda non agit nisi in virtute primae causae. Quod autem ratio humana sit regula voluntatis humanae, ex qua eius bonitas mensuretur, habet ex lege aeterna, quae est ratio divina. Unde in Psalmo IV, dicitur, *multi dicunt, quis ostendit nobis bona? Signatum est super nos lumen vultus tui, domine*, quasi diceret, lumen rationis quod in nobis est, intantum potest nobis ostendere bona, et nostram voluntatem regulare, inquantum est lumen vultus tui, idest a vultu tuo derivatum. Unde manifestum est quod multo magis dependet bonitas voluntatis humanae a lege aeterna, quam a ratione humana, et ubi deficit humana ratio, oportet ad rationem aeternam recurrere.

###### ad 1
Ad primum ergo dicendum quod unius rei non sunt plures mensurae proximae, possunt tamen esse plures mensurae, quarum una sub alia ordinetur.

###### ad 2
Ad secundum dicendum quod mensura proxima est homogenea mensurato, non autem mensura remota.

###### ad 3
Ad tertium dicendum quod, licet lex aeterna sit nobis ignota secundum quod est in mente divina; innotescit tamen nobis aliqualiter vel per rationem naturalem, quae ab ea derivatur ut propria eius imago; vel per aliqualem revelationem superadditam.

