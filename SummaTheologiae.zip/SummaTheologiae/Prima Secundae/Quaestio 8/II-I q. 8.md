## Quaestio 8

### Prooemium

Deinde considerandum est de ipsis actibus voluntariis in speciali. Et primo, de actibus qui sunt immediate ipsius voluntatis velut ab ipsa voluntate eliciti; secundo de actibus imperatis a voluntate. Voluntas autem movetur et in finem, et in ea quae sunt ad finem. Primo igitur considerandum est de actibus voluntatis quibus movetur in finem; et deinde de actibus eius quibus movetur in ea quae sunt ad finem. Actus autem voluntatis in finem videntur esse tres, scilicet velle, frui et intendere. Primo ergo considerabimus de voluntate; secundo, de fruitione; tertio, de intentione. Circa primum consideranda sunt tria, primo quidem, quorum voluntas sit; secundo, a quo moveatur; tertio, quomodo moveatur. Circa primum quaeruntur tria. Primo, utrum voluntas sit tantum boni. Secundum, utrum sit tantum finis, an etiam eorum quae sunt ad finem. Tertio, si est aliquo modo eorum quae sunt ad finem, utrum uno motu moveatur in finem et in ea quae sunt ad finem.

![[II-I q. 8 a. 1#Articulus 1]]

![[II-I q. 8 a. 2#Articulus 2]]

![[II-I q. 8 a. 3#Articulus 3]]

