## Quaestio 95

### Prooemium

Deinde considerandum est de lege humana. Et primo quidem, de ipsa lege secundum se; secundo, de potestate eius; tertio, de eius mutabilitate. Circa primum quaeruntur quatuor. Primo, de utilitate ipsius. Secundo, de origine eius. Tertio, de qualitate ipsius. Quarto, de divisione eiusdem.

![[II-I q. 95 a. 1#Articulus 1]]

![[II-I q. 95 a. 2#Articulus 2]]

![[II-I q. 95 a. 3#Articulus 3]]

![[II-I q. 95 a. 4#Articulus 4]]

