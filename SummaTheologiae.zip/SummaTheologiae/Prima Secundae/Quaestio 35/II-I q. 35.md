## Quaestio 35

### Prooemium

Deinde considerandum est de dolore et tristitia. Et circa hoc, primo considerandum est de tristitia, seu dolore, secundum se; secundo, de causis eius; tertio, de effectibus ipsius; quarto, de remediis eius; quinto, de bonitate vel malitia eius. Circa primum quaeruntur octo. Primo, utrum dolor sit passio animae. Secundo, utrum tristitia sit idem quod dolor. Tertio, utrum tristitia, seu dolor, sit contraria delectationi. Quarto, utrum omnis tristitia omni delectationi contrarietur. Quinto, utrum delectationi contemplationis sit aliqua tristitia contraria. Sexto, utrum magis fugienda sit tristitia, quam delectatio appetenda. Septimo, utrum dolor exterior sit maior quam dolor interior. Octavo, de speciebus tristitiae.

![[II-I q. 35 a. 1#Articulus 1]]

![[II-I q. 35 a. 2#Articulus 2]]

![[II-I q. 35 a. 3#Articulus 3]]

![[II-I q. 35 a. 4#Articulus 4]]

![[II-I q. 35 a. 5#Articulus 5]]

![[II-I q. 35 a. 6#Articulus 6]]

![[II-I q. 35 a. 7#Articulus 7]]

![[II-I q. 35 a. 8#Articulus 8]]

