## Quaestio 79

### Prooemium

Deinde considerandum est de causis exterioribus peccati. Et primo, ex parte Dei; secundo, ex parte Diaboli; tertio, ex parte hominis. Circa primum quaeruntur quatuor. Primo, utrum Deus sit causa peccati. Secundo, utrum actus peccati sit a Deo. Tertio, utrum Deus sit causa excaecationis et obdurationis. Quarto, utrum haec ordinentur ad salutem eorum qui excaecantur vel obdurantur.

![[II-I q. 79 a. 1#Articulus 1]]

![[II-I q. 79 a. 2#Articulus 2]]

![[II-I q. 79 a. 3#Articulus 3]]

![[II-I q. 79 a. 4#Articulus 4]]

