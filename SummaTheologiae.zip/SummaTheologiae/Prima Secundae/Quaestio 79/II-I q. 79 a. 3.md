### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod Deus non sit causa excaecationis et indurationis. Dicit enim Augustinus, in libro octoginta trium quaest., quod *Deus non est causa eius quod homo sit deterior*. Sed per excaecationem et obdurationem fit homo deterior. Ergo Deus non est causa excaecationis et obdurationis.

###### arg. 2
Praeterea, Fulgentius dicit quod *Deus non est ultor illius rei cuius est auctor*. Sed Deus est ultor cordis obdurati, secundum illud [[Si 3]], *cor durum male habebit in novissimo*. Ergo Deus non est causa obdurationis.

###### arg. 3
Praeterea, idem effectus non attribuitur causis contrariis. Sed causa excaecationis dicitur esse malitia hominis, secundum illud [[Sg 2]], *excaecavit enim eos malitia eorum*; et etiam Diabolus, secundum illud II ad Cor. IV, *Deus huius saeculi excaecavit mentes infidelium*; quae quidem causae videntur esse contrariae Deo. Deus ergo non est causa excaecationis et obdurationis.

###### s. c.
Sed contra est quod dicitur [[Is 6]], *excaeca cor populi huius, et aures eius aggrava*. Et [[Rm 9]] dicitur, *cuius vult, miseretur; et quem vult, indurat*.

###### co.
Respondeo dicendum quod excaecatio et obduratio duo important. Quorum unum est motus animi humani inhaerentis malo, et aversi a divino lumine. Et quantum ad hoc Deus non est causa excaecationis et obdurationis, sicut non est causa peccati. Aliud autem est subtractio gratiae, ex qua sequitur quod mens divinitus non illuminetur ad recte videndum, et cor hominis non emolliatur ad recte vivendum. Et quantum ad hoc Deus est causa excaecationis et obdurationis. Est autem considerandum quod Deus est causa universalis illuminationis animarum, secundum illud [[Jn 1]], *erat lux vera quae illuminat omnem hominem venientem in hunc mundum*, sicut sol est universalis causa illuminationis corporum. Aliter tamen et aliter, nam sol agit illuminando per necessitatem naturae; Deus autem agit voluntarie, per ordinem suae sapientiae. Sol autem, licet quantum est de se omnia corpora illuminet, si quod tamen impedimentum inveniat in aliquo corpore, relinquit illud tenebrosum, sicut patet de domo cuius fenestrae sunt clausae. Sed tamen illius obscurationis nullo modo causa est sol, non enim suo iudicio agit ut lumen interius non immittat, sed causa eius est solum ille qui claudit fenestram. Deus autem proprio iudicio lumen gratiae non immittit illis in quibus obstaculum invenit. Unde causa subtractionis gratiae est non solum ille qui ponit obstaculum gratiae, sed etiam Deus, qui suo iudicio gratiam non apponit. Et per hunc modum Deus est causa excaecationis, et aggravationis aurium, et obdurationis cordis. Quae quidem distinguuntur secundum effectus gratiae, quae et perficit intellectum dono sapientiae, et affectum emollit igne caritatis. Et quia ad cognitionem intellectus maxime deserviunt duo sensus, scilicet visus et auditus, quorum unus deservit inventioni, scilicet visus, alius disciplinae, scilicet auditus, ideo quantum ad visum, ponitur excaecatio; quantum ad auditum, aurium aggravatio; quantum ad affectum, obduratio.

###### ad 1
Ad primum ergo dicendum quod, cum excaecatio et induratio, ex parte subtractionis gratiae, sint quaedam poenae, ex hac parte eis homo non fit deterior, sed deterior factus per culpam, haec incurrit, sicut et ceteras poenas.

###### ad 2
Ad secundum dicendum quod obiectio illa procedit de obduratione secundum quod est culpa.

###### ad 3
Ad tertium dicendum quod malitia est causa excaecationis meritoria, sicut culpa est causa poenae. Et hoc etiam modo Diabolus excaecare dicitur, inquantum inducit ad culpam.

