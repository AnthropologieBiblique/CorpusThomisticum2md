### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod actus peccati non sit a Deo. Dicit enim Augustinus, in libro de perfectione iustitiae, quod *actus peccati non est res aliqua*. Omne autem quod est a Deo, est res aliqua. Ergo actus peccati non est a Deo.

###### arg. 2
Praeterea, homo non dicitur esse causa peccati nisi quia homo est causa actus peccati, nullus enim intendens ad malum operatur, ut Dionysius dicit, IV cap. de Div. Nom. Sed Deus non est causa peccati, ut dictum est. Ergo Deus non est causa actus peccati.

###### arg. 3
Praeterea, aliqui actus secundum suam speciem sunt mali et peccata, ut ex supradictis patet. Sed quidquid est causa alicuius, est causa eius quod convenit ei secundum suam speciem. Si ergo Deus esset causa actus peccati, sequeretur quod esset causa peccati. Sed hoc non est verum, ut ostensum est. Ergo Deus non est causa actus peccati.

###### s. c.
Sed contra, actus peccati est quidam motus liberi arbitrii. Sed voluntas Dei est causa omnium motionum, ut Augustinus dicit, III de Trin. Ergo voluntas Dei est causa actus peccati.

###### co.
Respondeo dicendum quod actus peccati et est ens, et est actus; et ex utroque habet quod sit a Deo. Omne enim ens, quocumque modo sit, oportet quod derivetur a primo ente; ut patet per Dionysium, V cap. de Div. Nom. Omnis autem actio causatur ab aliquo existente in actu, quia nihil agit nisi secundum quod est actu, omne autem ens actu reducitur in primum actum, scilicet Deum, sicut in causam, qui est per suam essentiam actus. Unde relinquitur quod Deus sit causa omnis actionis, inquantum est actio. Sed peccatum nominat ens et actionem cum quodam defectu. Defectus autem ille est ex causa creata, scilicet libero arbitrio, inquantum deficit ab ordine primi agentis, scilicet Dei. Unde defectus iste non reducitur in Deum sicut in causam, sed in liberum arbitrium, sicut defectus claudicationis reducitur in tibiam curvam sicut in causam, non autem in virtutem motivam, a qua tamen causatur quidquid est motionis in claudicatione. Et secundum hoc, Deus est causa actus peccati, non tamen est causa peccati, quia non est causa huius, quod actus sit cum defectu.

###### ad 1
Ad primum ergo dicendum quod Augustinus nominat ibi rem id quod est res simpliciter, scilicet substantiam. Sic enim actus peccati non est res.

###### ad 2
Ad secundum dicendum quod in hominem sicut in causam reducitur non solum actus, sed etiam ipse defectus, quia scilicet non subditur ei cui debet subdi, licet hoc ipse non intendat principaliter. Et ideo homo est causa peccati. Sed Deus sic est causa actus, quod nullo modo est causa defectus concomitantis actum. Et ideo non est causa peccati.

###### ad 3
Ad tertium dicendum quod, sicut dictum est supra, actus et habitus non recipiunt speciem ex ipsa privatione, in qua consistit ratio mali; sed ex aliquo obiecto cui coniungitur talis privatio. Et sic ipse defectus, qui dicitur non esse a Deo, pertinet ad speciem actus consequenter, et non quasi differentia specifica.

