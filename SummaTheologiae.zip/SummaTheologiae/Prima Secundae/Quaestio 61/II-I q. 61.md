## Quaestio 61

### Prooemium

Deinde considerandum est de virtutibus cardinalibus. Et circa hoc quaeruntur quinque. Primo, utrum virtutes morales debeant dici cardinales, vel principales. Secundo, de numero earum. Tertio, quae sint. Quarto, utrum differant ab invicem. Quinto, utrum dividantur convenienter in virtutes politicas, et purgatorias, et purgati animi, et exemplares.

![[II-I q. 61 a. 1#Articulus 1]]

![[II-I q. 61 a. 2#Articulus 2]]

![[II-I q. 61 a. 3#Articulus 3]]

![[II-I q. 61 a. 4#Articulus 4]]

![[II-I q. 61 a. 5#Articulus 5]]

