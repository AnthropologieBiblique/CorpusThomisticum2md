## Quaestio 11

### Prooemium

Deinde considerandum est de fruitione. Et circa hoc quaeruntur quatuor. Primo, utrum frui sit actus appetitivae potentiae. Secundo, utrum soli rationali creaturae conveniat, an etiam animalibus brutis. Tertio, utrum fruitio sit tantum ultimi finis. Quarto, utrum sit solum finis habiti.

![[II-I q. 11 a. 1#Articulus 1]]

![[II-I q. 11 a. 2#Articulus 2]]

![[II-I q. 11 a. 3#Articulus 3]]

![[II-I q. 11 a. 4#Articulus 4]]

