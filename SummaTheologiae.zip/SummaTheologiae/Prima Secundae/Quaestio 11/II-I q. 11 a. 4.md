### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod fruitio non sit nisi finis habiti. Dicit enim Augustinus, X de Trin., quod *frui est cum gaudio uti, non adhuc spei, sed iam rei*. Sed quandiu non habetur, non est gaudium rei, sed spei. Ergo fruitio non est nisi finis habiti.

###### arg. 2
Praeterea, sicut dictum est, fruitio non est proprie nisi ultimi finis, quia solus ultimus finis quietat appetitum. Sed appetitus non quietatur nisi in fine iam habito. Ergo fruitio, proprie loquendo, non est nisi finis habiti.

###### arg. 3
Praeterea, frui est capere fructum. Sed non capitur fructus, nisi quando iam finis habetur. Ergo fruitio non est nisi finis habiti.

###### s. c.
Sed contra, *frui est amore inhaerere alicui rei propter seipsam*, ut Augustinus dicit. Sed hoc potest fieri etiam de re non habita. Ergo frui potest esse etiam finis non habiti.

###### co.
Respondeo dicendum quod frui importat comparationem quandam voluntatis ad ultimum finem, secundum quod voluntas habet aliquid pro ultimo fine. Habetur autem finis dupliciter, uno modo, perfecte; et alio modo, imperfecte. Perfecte quidem, quando habetur non solum in intentione, sed etiam in re, imperfecte autem, quando habetur in intentione tantum. Est ergo perfecta fruitio finis iam habiti realiter. Sed imperfecta est etiam finis non habiti realiter, sed in intentione tantum.

###### ad 1
Ad primum ergo dicendum quod Augustinus loquitur de fruitione perfecta.

###### ad 2
Ad secundum dicendum quod quies voluntatis dupliciter impeditur, uno modo, ex parte obiecti, quia scilicet non est ultimus finis, sed ad aliud ordinatur; alio modo, ex parte appetentis finem qui nondum adipiscitur finem. Obiectum autem est quod dat speciem actui, sed ab agente dependet modus agendi, ut sit perfectus vel imperfectus, secundum conditionem agentis. Et ideo eius quod non est ultimus finis, fruitio est impropria, quasi deficiens a specie fruitionis. Finis autem ultimi non habiti, est fruitio propria quidem, sed imperfecta, propter imperfectum modum habendi ultimum finem.

###### ad 3
Ad tertium dicendum quod finem accipere vel habere dicitur aliquis, non solum secundum rem, sed etiam secundum intentionem, ut dictum est.

