### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod fruitio non sit tantum ultimi finis. Dicit enim apostolus, ad Philem., *ita, frater, ego te fruar in domino*. Sed manifestum est quod Paulus non posuerat ultimum suum finem in homine. Ergo frui non tantum est ultimi finis.

###### arg. 2
Praeterea, fructus est quo aliquis fruitur. Sed apostolus dicit, ad Galat. V, fructus spiritus est caritas, gaudium, pax, et cetera huiusmodi; quae non habent rationem ultimi finis. Non ergo fruitio est tantum ultimi finis.

###### arg. 3
Praeterea, actus voluntatis supra seipsos reflectuntur, volo enim me velle, et amo me amare. Sed frui est actus voluntatis, voluntas enim est per quam fruimur, ut Augustinus dicit X de Trin. Ergo aliquis fruitur sua fruitione. Sed fruitio non est ultimus finis hominis, sed solum bonum increatum, quod est Deus. Non ergo fruitio est solum ultimi finis.

###### s. c.
Sed contra est quod Augustinus dicit, X de Trin., *non fruitur si quis id quod in facultatem voluntatis assumit, propter aliud appetit*. Sed solum ultimus finis est qui non propter aliud appetitur. Ergo solius ultimi finis est fruitio.

###### co.
Respondeo dicendum quod, sicut dictum est, ad rationem fructus duo pertinent, scilicet quod sit ultimum; et quod appetitum quietet quadam dulcedine vel delectatione. Ultimum autem est simpliciter, et secundum quid, simpliciter quidem, quod ad aliud non refertur; sed secundum quid, quod est aliquorum ultimum. Quod ergo est simpliciter ultimum, in quo aliquid delectatur sicut in ultimo fine, hoc proprie dicitur fructus, et eo proprie dicitur aliquis frui. Quod autem in seipso non est delectabile, sed tantum appetitur in ordine ad aliud, sicut potio amara ad sanitatem; nullo modo fructus dici potest. Quod autem in se habet quandam delectationem, ad quam quaedam praecedentia referuntur, potest quidem aliquo modo dici fructus, sed non proprie, et secundum completam rationem fructus, eo dicimur frui. Unde Augustinus, in X de Trin., dicit quod *fruimur cognitis in quibus voluntas delectata conquiescit*. Non autem quiescit simpliciter nisi in ultimo, quia quandiu aliquid expectatur, motus voluntatis remanet in suspenso, licet iam ad aliquid pervenerit. Sicut in motu locali, licet illud quod est medium in magnitudine, sit principium et finis; non tamen accipitur ut finis in actu, nisi quando in eo quiescitur.

###### ad 1
Ad primum ergo dicendum quod, sicut Augustinus dicit in I de Doctr. Christ., *si dixisset te fruar, et non addidisset in domino, videretur finem dilectionis in eo posuisse. Sed quia illud addidit, in domino se posuisse finem, atque eo se frui significavit*. Ut sic fratre se frui dixerit non tanquam termino, sed tanquam medio.

###### ad 2
Ad secundum dicendum quod fructus aliter comparatur ad arborem producentem, et aliter ad hominem fruentem. Ad arborem quidem producentem comparatur ut effectus ad causam, ad fruentem autem, sicut ultimum expectatum et delectans. Dicuntur igitur ea quae enumerat ibi apostolus, fructus, quia sunt effectus quidam spiritus sancti in nobis, unde et fructus spiritus dicuntur, non autem ita quod eis fruamur tanquam ultimo fine. Vel aliter dicendum quod dicuntur fructus, secundum Ambrosium, quia propter se petenda sunt, non quidem ita quod ad beatitudinem non referantur; sed quia in seipsis habent unde nobis placere debeant.

###### ad 3
Ad tertium dicendum quod, sicut supra dictum est finis dicitur dupliciter, uno modo, ipsa res; alio modo, adeptio rei. Quae quidem non sunt duo fines, sed unus finis, in se consideratus, et alteri applicatus. Deus igitur est ultimus finis sicut res quae ultimo quaeritur, fruitio autem sicut adeptio huius ultimi finis. Sicut igitur non est alius finis Deus, et fruitio Dei; ita eadem ratio fruitionis est qua fruimur Deo, et qua fruimur divina fruitione. Et eadem ratio est de beatitudine creata, quae in fruitione consistit.

