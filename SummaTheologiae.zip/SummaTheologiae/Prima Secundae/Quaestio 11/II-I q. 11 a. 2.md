### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod frui solummodo sit hominum. Dicit enim Augustinus, in I de Doct. Christ., quod *nos homines sumus qui fruimur et utimur*. Non ergo alia animalia frui possunt.

###### arg. 2
Praeterea, frui est ultimi finis. Sed ad ultimum finem non possunt pertingere bruta animalia. Ergo eorum non est frui.

###### arg. 3
Praeterea, sicut appetitus sensitivus est sub intellectivo, ita appetitus naturalis est sub sensitivo. Si igitur frui pertinet ad appetitum sensitivum, videtur quod pari ratione possit ad naturalem pertinere. Quod patet esse falsum, quia eius non est delectari. Ergo appetitus sensitivi non est frui. Et ita non convenit brutis animalibus.

###### s. c.
Sed contra est quod Augustinus dicit, in libro octoginta trium quaest., *frui quidem cibo et qualibet corporali voluptate, non absurde existimantur et bestiae*.

###### co.
Respondeo dicendum quod, sicut ex praedictis habetur, frui non est actus potentiae pervenientis ad finem sicut exequentis, sed potentiae imperantis executionem, dictum est enim quod est appetitivae potentiae. In rebus autem cognitione carentibus invenitur quidem potentia pertingens ad finem per modum exequentis, sicut qua grave tendit deorsum et leve sursum. Sed potentia ad quam pertineat finis per modum imperantis, non invenitur in eis; sed in aliqua superiori natura, quae sic movet totam naturam per imperium, sicut in habentibus cognitionem appetitus movet alias potentias ad suos actus. Unde manifestum est quod in his quae cognitione carent, quamvis pertingant ad finem, non invenitur fruitio finis; sed solum in his quae cognitionem habent. Sed cognitio finis est duplex, perfecta, et imperfecta. Perfecta quidem, qua non solum cognoscitur id quod est finis et bonum, sed universalis ratio finis et boni, et talis cognitio est solius rationalis naturae. Imperfecta autem cognitio est qua cognoscitur particulariter finis et bonum, et talis cognitio est in brutis animalibus. Quorum etiam virtutes appetitivae non sunt imperantes libere; sed secundum naturalem instinctum ad ea quae apprehenduntur, moventur. Unde rationali naturae convenit fruitio secundum rationem perfectam, brutis autem animalibus secundum rationem imperfectam, aliis autem creaturis nullo modo.

###### ad 1
Ad primum ergo dicendum quod Augustinus loquitur de fruitione perfecta.

###### ad 2
Ad secundum dicendum quod non oportet quod fruitio sit ultimi finis simpliciter, sed eius quod habetur ab unoquoque pro ultimo fine.

###### ad 3
Ad tertium dicendum quod appetitus sensitivus consequitur aliquam cognitionem, non autem appetitus naturalis, praecipue prout est in his quae cognitione carent.

###### ad 4
Ad quartum dicendum, quod Augustinus ibi loquitur de fruitione imperfecta. Quod ex ipso modo loquendi apparet, dicit enim quod frui non adeo absurde existimantur et bestiae, scilicet sicut uti absurdissime dicerentur.

