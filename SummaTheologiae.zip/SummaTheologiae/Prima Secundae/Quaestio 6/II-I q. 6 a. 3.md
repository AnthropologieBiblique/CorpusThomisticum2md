### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod voluntarium non possit esse sine actu. Voluntarium enim dicitur quod est a voluntate. Sed nihil potest esse a voluntate nisi per aliquem actum, ad minus ipsius voluntatis. Ergo voluntarium non potest esse sine actu.

###### arg. 2
Praeterea, sicut per actum voluntatis dicitur aliquis velle, ita cessante actu voluntatis dicitur non velle. Sed non velle involuntarium causat, quod opponitur voluntario. Ergo voluntarium non potest esse, actu voluntatis cessante.

###### arg. 3
Praeterea, de ratione voluntarii est cognitio, ut dictum est. Sed cognitio est per aliquem actum. Ergo voluntarium non potest esse absque aliquo actu.

###### s. c.
Sed contra, illud cuius domini sumus, dicitur esse voluntarium. Sed nos domini sumus eius quod est agere et non agere, velle et non velle. Ergo sicut agere et velle est voluntarium, ita et non agere et non velle.

###### co.
Respondeo dicendum quod voluntarium dicitur quod est a voluntate. Ab aliquo autem dicitur esse aliquid dupliciter. Uno modo, directe, quod scilicet procedit ab aliquo inquantum est agens, sicut calefactio a calore. Alio modo, indirecte, ex hoc ipso quod non agit, sicut submersio navis dicitur esse a gubernatore, inquantum desistit a gubernando. Sed sciendum quod non semper id quod sequitur ad defectum actionis, reducitur sicut in causam in agens, ex eo quod non agit, sed solum tunc cum potest et debet agere. Si enim gubernator non posset navem dirigere, vel non esset ei commissa gubernatio navis, non imputaretur ei navis submersio, quae per absentiam gubernatoris contingeret. Quia igitur voluntas, volendo et agendo, potest impedire hoc quod est non velle et non agere, et aliquando debet; hoc quod est non velle et non agere, imputatur ei, quasi ab ipsa existens. Et sic voluntarium potest esse absque actu, quandoque quidem absque actu exteriori, cum actu interiori, sicut cum vult non agere; aliquando autem et absque actu interiori, sicut cum non vult.

###### ad 1
Ad primum ergo dicendum quod voluntarium dicitur non solum quod procedit a voluntate directe, sicut ab agente; sed etiam quod est ab ea indirecte, sicut a non agente.

###### ad 2
Ad secundum dicendum quod non velle dicitur dupliciter. Uno modo, prout sumitur in vi unius dictionis, secundum quod est infinitivum huius verbi nolo. Unde sicut cum dico nolo legere, sensus est, volo non legere; ita hoc quod est non velle legere, significat velle non legere. Et sic non velle causat involuntarium. Alio modo sumitur in vi orationis. Et tunc non affirmatur actus voluntatis. Et huiusmodi non velle non causat involuntarium.

###### ad 3
Ad tertium dicendum quod eo modo requiritur ad voluntarium actus cognitionis, sicut et actus voluntatis; ut scilicet sit in potestate alicuius considerare et velle et agere. Et tunc sicut non velle et non agere, cum tempus fuerit, est voluntarium, ita etiam non considerare.

