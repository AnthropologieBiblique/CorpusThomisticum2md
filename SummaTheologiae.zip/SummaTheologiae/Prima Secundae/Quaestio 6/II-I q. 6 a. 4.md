### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod voluntati possit violentia inferri. Unumquodque enim potest cogi a potentiori. Sed aliquid est humana voluntate potentius, scilicet Deus. Ergo saltem ab eo cogi potest.

###### arg. 2
Praeterea, omne passivum cogitur a suo activo, quando immutatur ab eo. Sed voluntas est vis passiva, est enim movens motum, ut dicitur in III de anima. Cum ergo aliquando moveatur a suo activo, videtur quod aliquando cogatur.

###### arg. 3
Praeterea, motus violentus est qui est contra naturam. Sed motus voluntatis aliquando est contra naturam; ut patet de motu voluntatis ad peccandum, qui est contra naturam, ut Damascenus dicit. Ergo motus voluntatis potest esse coactus.

###### s. c.
Sed contra est quod Augustinus dicit, in V de Civ. Dei, quod si aliquid fit voluntate, non fit ex necessitate. Omne autem coactum fit ex necessitate. Ergo quod fit ex voluntate, non potest esse coactum. Ergo voluntas non potest cogi ad agendum.

###### co.
Respondeo dicendum quod duplex est actus voluntatis, unus quidem qui est eius immediate, velut ab ipsa elicitus, scilicet velle; alius autem est actus voluntatis a voluntate imperatus, et mediante alia potentia exercitus, ut ambulare et loqui, qui a voluntate imperantur mediante potentia motiva. Quantum igitur ad actus a voluntate imperatos, voluntas violentiam pati potest, inquantum per violentiam exteriora membra impediri possunt ne imperium voluntatis exequantur. Sed quantum ad ipsum proprium actum voluntatis, non potest ei violentia inferri. Et huius ratio est quia actus voluntatis nihil est aliud quam inclinatio quaedam procedens ab interiori principio cognoscente, sicut appetitus naturalis est quaedam inclinatio ab interiori principio et sine cognitione. Quod autem est coactum vel violentum, est ab exteriori principio. Unde contra rationem ipsius actus voluntatis est quod sit coactus vel violentus, sicut etiam est contra rationem naturalis inclinationis vel motus. Potest enim lapis per violentiam sursum ferri, sed quod iste motus violentus sit ex eius naturali inclinatione, esse non potest. Similiter etiam potest homo per violentiam trahi, sed quod hoc sit ex eius voluntate, repugnat rationi violentiae.

###### ad 1
Ad primum ergo dicendum quod Deus, qui est potentior quam voluntas humana, potest voluntatem humanam movere; secundum illud [[Pr 21]], *cor regis in manu Dei est, et quocumque voluerit, vertet illud*. Sed si hoc esset per violentiam, iam non esset cum actu voluntatis nec ipsa voluntas moveretur, sed aliquid contra voluntatem.

###### ad 2
Ad secundum dicendum quod non semper est motus violentus, quando passivum immutatur a suo activo, sed quando hoc fit contra interiorem inclinationem passivi. Alioquin omnes alterationes et generationes simplicium corporum essent innaturales et violentae. Sunt autem naturales, propter naturalem aptitudinem interiorem materiae vel subiecti ad talem dispositionem. Et similiter quando voluntas movetur ab appetibili secundum propriam inclinationem, non est motus violentus, sed voluntarius.

###### ad 3
Ad tertium dicendum quod id in quod voluntas tendit peccando, etsi sit malum et contra rationalem naturam secundum rei veritatem, apprehenditur tamen ut bonum et conveniens naturae, inquantum est conveniens homini secundum aliquam passionem sensus, vel secundum aliquem habitum corruptum.

