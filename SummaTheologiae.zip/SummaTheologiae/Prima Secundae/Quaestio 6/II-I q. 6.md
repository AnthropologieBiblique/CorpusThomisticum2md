## Quaestio 6

### Prooemium

Quia igitur ad beatitudinem per actus aliquos necesse est pervenire, oportet consequenter de humanis actibus considerare, ut sciamus quibus actibus perveniatur ad beatitudinem, vel impediatur beatitudinis via. Sed quia operationes et actus circa singularia sunt, ideo omnis operativa scientia in particulari consideratione perficitur. Moralis igitur consideratio quia est humanorum actuum, primo quidem tradenda est in universali secundo vero, in particulari. Circa universalem autem considerationem humanorum actuum, primo quidem considerandum occurrit de ipsis actibus humanis; secundo, de principiis eorum. Humanorum autem actuum quidam sunt hominis proprii; quidam autem sunt homini et aliis animalibus communes. Et quia beatitudo est proprium hominis bonum, propinquius se habent ad beatitudinem actus qui sunt proprie humani, quam actus qui sunt homini aliisque animalibus communes. Primo ergo considerandum est de actibus qui sunt proprii hominis; secundo, de actibus qui sunt homini aliisque animalibus communes, qui dicuntur animae passiones. Circa primum duo consideranda occurrunt, primo, de conditione humanorum actuum; secundo, de distinctione eorum. Cum autem actus humani proprie dicantur qui sunt voluntarii, eo quod voluntas est rationalis appetitus, qui est proprius hominis; oportet considerare de actibus inquantum sunt voluntarii. Primo ergo considerandum est de voluntario et involuntario in communi; secundo, de actibus qui sunt voluntarii quasi ab ipsa voluntate eliciti, ut immediate ipsius voluntatis existentes; tertio, de actibus qui sunt voluntarii quasi a voluntate imperati, qui sunt ipsius voluntatis mediantibus aliis potentiis. Et quia actus voluntarii habent quasdam circumstantias, secundum quas diiudicantur, primo considerandum est de voluntario et involuntario; et consequenter de circumstantiis ipsorum actuum in quibus voluntarium et involuntarium invenitur. Circa primum quaeruntur octo. Primo, utrum in humanis actibus inveniatur voluntarium. Secundo, utrum inveniatur in animalibus brutis. Tertio, utrum voluntarium esse possit absque omni actu. Quarto, utrum violentia voluntati possit inferri. Quinto, utrum violentia causet involuntarium. Sexto, utrum metus causet involuntarium. Septimo, utrum concupiscentia involuntarium causet. Octavo, utrum ignorantia.

![[II-I q. 6 a. 1#Articulus 1]]

![[II-I q. 6 a. 2#Articulus 2]]

![[II-I q. 6 a. 3#Articulus 3]]

![[II-I q. 6 a. 4#Articulus 4]]

![[II-I q. 6 a. 5#Articulus 5]]

![[II-I q. 6 a. 6#Articulus 6]]

![[II-I q. 6 a. 7#Articulus 7]]

![[II-I q. 6 a. 8#Articulus 8]]

