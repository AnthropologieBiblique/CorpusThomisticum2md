## Quaestio 89

### Prooemium

Deinde considerandum est de peccato veniali secundum se. Et circa hoc quaeruntur sex. Primo, utrum peccatum veniale causet maculam in anima. Secundo, de distinctione peccati venialis, prout figuratur per lignum, faenum et stipulam, I Cor. III. Tertio, utrum homo in statu innocentiae potuerit peccare venialiter. Quarto, utrum Angelus bonus vel malus possit peccare venialiter. Quinto, utrum primi motus infidelium sint peccata venialia. Sexto, utrum peccatum veniale possit esse in aliquo simul cum solo peccato originali.

![[II-I q. 89 a. 1#Articulus 1]]

![[II-I q. 89 a. 2#Articulus 2]]

![[II-I q. 89 a. 3#Articulus 3]]

![[II-I q. 89 a. 4#Articulus 4]]

![[II-I q. 89 a. 5#Articulus 5]]

