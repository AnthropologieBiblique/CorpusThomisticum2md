### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod primi motus sensualitatis in infidelibus sint peccata mortalia. Dicit enim apostolus, ad [[Rm 8]], quod *nihil est damnationis his qui sunt in Christo Iesu, qui non secundum carnem ambulant*, et loquitur ibi de concupiscentia sensualitatis, ut ex praemissis apparet. Haec ergo causa est quare concupiscere non sit damnabile his qui non secundum carnem ambulant, consentiendo scilicet concupiscentiae, quia sunt in Christo Iesu. Sed infideles non sunt in Christo Iesu. Ergo in infidelibus est damnabile. Primi igitur motus infidelium sunt peccata mortalia.

###### arg. 2
Praeterea, Anselmus dicit, in libro de gratia et Lib. Arb., *qui non sunt in Christo, sentientes carnem, sequuntur damnationem, etiam si non secundum carnem ambulant*. Sed damnatio non debetur nisi peccato mortali. Ergo, cum homo sentiat carnem secundum primum motum concupiscentiae, videtur quod primus motus concupiscentiae in infidelibus sit peccatum mortale.

###### arg. 3
Praeterea, Anselmus dicit, in eodem libro, *sic factus est homo, ut concupiscentiam sentire non deberet*. Hoc autem debitum videtur homini remissum per gratiam baptismalem, quam infideles non habent. Ergo quandocumque infidelis concupiscit, etiam si non consentiat, peccat mortaliter, contra debitum faciens.

###### s. c.
Sed contra est quod dicitur [[Ac 10]], *non est personarum acceptor Deus*. Quod ergo uni non imputat ad damnationem, nec alteri. Sed primos motus fidelibus non imputat ad damnationem. Ergo etiam nec infidelibus.

###### co.
Respondeo dicendum quod irrationabiliter dicitur quod primi motus infidelium sint peccata mortalia, si eis non consentiatur. Et hoc patet dupliciter. Primo quidem, quia ipsa sensualitas non potest esse subiectum peccati mortalis, ut supra habitum est. Est autem eadem natura sensualitatis in infidelibus et fidelibus. Unde non potest esse quod solus motus sensualitatis in infidelibus sit peccatum mortale. Alio modo, ex statu ipsius peccantis. Nunquam enim dignitas personae diminuit peccatum, sed magis auget, ut ex supra dictis patet. Unde nec peccatum est minus in fideli quam in infideli, sed multo maius. Nam et infidelium peccata magis merentur veniam, propter ignorantiam, secundum illud [[1 Tm 1]], *misericordiam Dei consecutus sum, quia ignorans feci in incredulitate mea*; et peccata fidelium aggravantur propter gratiae sacramenta, secundum illud Heb. X, *quanto magis putatis deteriora mereri supplicia, qui sanguinem testamenti, in quo sanctificatus est, pollutum duxerit?*

###### ad 1
Ad primum ergo dicendum quod apostolus loquitur de damnatione debita peccato originali, quae aufertur per gratiam Iesu Christi, quamvis maneat concupiscentiae fomes. Unde hoc quod fideles concupiscunt, non est in eis signum damnationis originalis peccati, sicut est in infidelibus.

###### ad 2
Et hoc etiam modo intelligendum est dictum Anselmi. Unde patet solutio ad secundum.

###### ad 3
Ad tertium dicendum quod illud debitum non concupiscendi erat per originalem iustitiam. Unde id quod opponitur tali debito, non pertinet ad peccatum actuale, sed ad peccatum originale.

