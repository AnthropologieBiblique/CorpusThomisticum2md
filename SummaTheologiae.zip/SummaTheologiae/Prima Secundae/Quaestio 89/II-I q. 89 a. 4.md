### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod Angelus bonus vel malus possit peccare venialiter. Homo enim cum Angelis convenit in superiori animae parte, quae mens vocatur; secundum illud Gregorii, in Homil., *homo intelligit cum Angelis*. Sed homo secundum superiorem partem animae potest peccare venialiter. Ergo et Angelus.

###### arg. 2
Praeterea, quicumque potest quod est plus, potest etiam quod est minus. Sed Angelus potuit diligere bonum creatum plus quam Deum, quod fecit peccando mortaliter. Ergo etiam potuit bonum creatum diligere infra Deum inordinate, venialiter peccando.

###### arg. 3
Praeterea, Angeli mali videntur aliqua facere quae sunt ex genere suo venialia peccata, provocando homines ad risum, et ad alias huiusmodi levitates. Sed circumstantia personae non facit de veniali mortale, ut dictum est, nisi speciali prohibitione superveniente, quod non est in proposito. Ergo Angelus potest peccare venialiter.

###### s. c.
Sed contra est quod maior est perfectio Angeli quam perfectio hominis in primo statu. Sed homo in primo statu non potuit peccare venialiter. Ergo multo minus Angelus.

###### co.
Respondeo dicendum quod intellectus Angeli, sicut in primo dictum est, non est discursivus, ut scilicet procedat a principiis in conclusiones, seorsum utrumque intelligens, sicut in nobis contingit. Unde oportet quod quandocumque considerat conclusiones, consideret eas prout sunt in principiis. In appetibilibus autem, sicut multoties dictum est, fines sunt sicut principia; ea vero quae sunt ad finem, sunt sicut conclusiones. Unde mens Angeli non fertur in ea quae sunt ad finem, nisi secundum quod constant sub ordine finis. Propter hoc ex natura sua habent quod non possit in eis esse deordinatio circa ea quae sunt ad finem, nisi simul sit deordinatio circa finem ipsum, quod est per peccatum mortale. Sed Angeli boni non moventur in ea quae sunt ad finem, nisi in ordine ad finem debitum, qui est Deus. Et propter hoc omnes eorum actus sunt actus caritatis. Et sic in eis non potest esse peccatum veniale. Angeli vero mali in nihil moventur nisi in ordine ad finem peccati superbiae ipsorum. Et ideo in omnibus peccant mortaliter, quaecumque propria voluntate agunt. Secus autem est de appetitu naturalis boni qui est in eis, ut in primo dictum est.

###### ad 1
Ad primum ergo dicendum quod homo convenit quidem cum Angelis in mente, sive in intellectu; sed differt in modo intelligendi, ut dictum est.

###### ad 2
Ad secundum dicendum quod Angelus non potuit minus diligere creaturam quam Deum, nisi simul referens eam in Deum, sicut in ultimum finem, vel aliquem finem inordinatum, ratione iam dicta.

###### ad 3
Ad tertium dicendum quod omnia illa quae videntur esse venialia, Daemones procurant ut homines ad sui familiaritatem attrahant, et sic deducant eos in peccatum mortale. Unde in omnibus talibus mortaliter peccant, propter intentionem finis.

