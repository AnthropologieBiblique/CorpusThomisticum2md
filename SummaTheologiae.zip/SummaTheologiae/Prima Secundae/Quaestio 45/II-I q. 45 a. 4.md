### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod audaces non sint promptiores in principio quam in ipsis periculis. Tremor enim ex timore causatur, qui contrariatur audaciae, ut ex dictis patet. Sed audaces quandoque in principio tremunt, ut philosophus dicit, in libro de problematibus. Ergo non sunt promptiores in principio quam in ipsis periculis existentes.

###### arg. 2
Praeterea, per augmentum obiecti augetur passio, sicut si bonum est amabile, et magis bonum est magis amabile. Sed arduum est obiectum audaciae. Augmentato ergo arduo, augmentatur audacia. Sed magis fit arduum et difficile periculum, quando est praesens. Ergo debet tunc magis crescere audacia.

###### arg. 3
Praeterea, ex vulneribus inflictis provocatur ira. Sed ira causat audaciam, dicit enim philosophus, in II Rhetoric., quod ira est ausivum. Ergo quando iam sunt in ipsis periculis, et percutiuntur, videtur quod magis audaces reddantur.

###### s. c.
Sed contra est quod dicitur in III Ethic., quod *audaces praevolantes sunt et volentes ante pericula, in ipsis autem discedunt*.

###### co.
Respondeo dicendum quod audacia, cum sit quidam motus appetitus sensitivi, sequitur apprehensionem sensitivae virtutis. Virtus autem sensitiva non est collativa nec inquisitiva singulorum quae circumstant rem, sed subitum habet iudicium. Contingit autem quandoque quod secundum subitam apprehensionem non possunt cognosci omnia quae difficultatem in aliquo negotio afferunt, unde surgit audaciae motus ad aggrediendum periculum. Unde quando iam experiuntur ipsum periculum, sentiunt maiorem difficultatem quam aestimaverunt. Et ideo deficiunt. Sed ratio est discussiva omnium quae afferunt difficultatem negotio. Et ideo fortes, qui ex iudicio rationis aggrediuntur pericula, in principio videntur remissi, quia non passi, sed cum deliberatione debita aggrediuntur. Quando autem sunt in ipsis periculis, non experiuntur aliquid improvisum; sed quandoque minora illis quae praecogitaverunt. Et ideo magis persistunt. Vel etiam quia propter bonum virtutis pericula aggrediuntur, cuius boni voluntas in eis perseverat, quantacumque sint pericula. Audaces autem, propter solam aestimationem facientem spem et excludentem timorem, sicut dictum est.

###### ad 1
Ad primum ergo dicendum quod etiam in audacibus accidit tremor, propter revocationem caloris ab exterioribus ad interiora, sicut etiam in timentibus. Sed in audacibus revocatur calor ad cor, in timentibus autem, ad inferiora.

###### ad 2
Ad secundum dicendum quod obiectum amoris est simpliciter bonum, unde augmentatum simpliciter augmentat amorem. Sed obiectum audaciae est compositum ex bono et malo; et motus audaciae in malum, praesupponit motum spei in bonum. Et ideo si tantum addatur de arduitate ad periculum quod excedat spem, non sequetur motus audaciae, sed diminuetur. Si tamen sit motus audaciae, quanto maius est periculum, tanto maior audacia reputatur.

###### ad 3
Ad tertium dicendum quod ex laesione non causatur ira, nisi supposita aliqua spe, ut infra dicetur. Et ideo si fuerit tantum periculum quod excedat spem victoriae, non sequetur ira. Sed verum est quod, si ira sequatur, audacia augebitur.

