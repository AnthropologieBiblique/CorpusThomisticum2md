### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod audacia non contrarietur timori. Dicit enim Augustinus, in libro octoginta trium quaest., quod audacia vitium est. Vitium autem virtuti contrariatur. Cum ergo timor non sit virtus, sed passio, videtur quod timori non contrarietur audacia.

###### arg. 2
Praeterea, uni unum est contrarium. Sed timori contrariatur spes. Non ergo contrariatur ei audacia.

###### arg. 3
Praeterea, unaquaeque passio excludit passionem oppositam. Sed id quod excluditur per timorem, est securitas, dicit enim Augustinus, II Confess., quod timor securitati praecavet ergo securitas contrariatur timori. Non ergo audacia.

###### s. c.
Sed contra est quod philosophus dicit, in II Rhetoric., quod *audacia est timori contraria*.

###### co.
Respondeo dicendum quod de ratione contrariorum est quod maxime a se distent, ut dicitur in X Metaphys. Illud autem quod maxime distat a timore, est audacia, timor enim refugit nocumentum futurum, propter eius victoriam super ipsum timentem; sed audacia aggreditur periculum imminens, propter victoriam sui supra ipsum periculum. Unde manifeste timori contrariatur audacia.

###### ad 1
Ad primum ergo dicendum quod ira et audacia, et omnium passionum nomina, dupliciter accipi possunt. Uno modo, secundum quod important absolute motus appetitus sensitivi in aliquod obiectum bonum vel malum, et sic sunt nomina passionum. Alio modo, secundum quod simul cum huiusmodi motu important recessum ab ordine rationis, et sic sunt nomina vitiorum. Et hoc modo loquitur Augustinus de audacia, sed nos loquimur nunc de audacia secundum primum modum.

###### ad 2
Ad secundum dicendum quod uni secundum idem, non sunt plura contraria, sed secundum diversa, nihil prohibet uni plura contrariari. Et sic dictum est supra quod passiones irascibilis habent duplicem contrarietatem, unam secundum oppositionem boni et mali, et sic timor contrariatur spei; aliam secundum oppositionem accessus et recessus, et sic timori contrariatur audacia, spei vero desperatio.

###### ad 3
Ad tertium dicendum quod securitas non significat aliquid contrarium timori, sed solam timoris exclusionem, ille enim dicitur esse securus, qui non timet. Unde securitas opponitur timori sicut privatio, audacia autem sicut contrarium. Et sicut contrarium includit in se privationem, ita audacia securitatem.

