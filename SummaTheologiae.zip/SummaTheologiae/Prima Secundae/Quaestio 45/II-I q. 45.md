## Quaestio 45

### Prooemium

Deinde considerandum est de audacia. Et circa hoc quaeruntur quatuor. Primo, utrum audacia sit contraria timori. Secundo, quomodo audacia se habeat ad spem. Tertio, de causa audaciae. Quarto, de effectus ipsius.

![[II-I q. 45 a. 1#Articulus 1]]

![[II-I q. 45 a. 2#Articulus 2]]

![[II-I q. 45 a. 3#Articulus 3]]

![[II-I q. 45 a. 4#Articulus 4]]

