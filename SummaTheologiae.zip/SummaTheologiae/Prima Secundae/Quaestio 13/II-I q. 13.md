## Quaestio 13

### Prooemium

Consequenter considerandum est de actibus voluntatis qui sunt in comparatione ad ea quae sunt ad finem. Et sunt tres, eligere, consentire, et uti. Electionem autem praecedit consilium. Primo ergo considerandum est de electione; secundo, de consilio; tertio, de consensu; quarto, de usu. Circa electionem quaeruntur sex. Primo, cuius potentiae sit actus, utrum voluntatis vel rationis. Secundo, utrum electio conveniat brutis animalibus. Tertio, utrum electio sit solum eorum quae sunt ad finem, vel etiam quandoque finis. Quarto, utrum electio sit tantum eorum quae per nos aguntur. Quinto, utrum electio sit solum possibilium. Sexto, utrum homo ex necessitate eligat, vel libere.

![[II-I q. 13 a. 1#Articulus 1]]

![[II-I q. 13 a. 2#Articulus 2]]

![[II-I q. 13 a. 3#Articulus 3]]

![[II-I q. 13 a. 4#Articulus 4]]

![[II-I q. 13 a. 5#Articulus 5]]

![[II-I q. 13 a. 6#Articulus 6]]

