### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod electio non sit tantum eorum quae sunt ad finem. Dicit enim philosophus, in VI Ethic., quod *electionem rectam facit virtus, quaecumque autem illius gratia nata sunt fieri, non sunt virtutis, sed alterius potentiae*. Illud autem cuius gratia fit aliquid, est finis. Ergo electio est finis.

###### arg. 2
Praeterea, electio importat praeacceptionem unius respectu alterius. Sed sicut eorum quae sunt ad finem unum potest praeaccipi alteri, ita etiam et diversorum finium. Ergo electio potest esse finis, sicut et eorum quae sunt ad finem.

###### s. c.
Sed contra est quod philosophus dicit, in III Ethic., quod *voluntas est finis, electio autem eorum quae sunt ad finem*.

###### co.
Respondeo dicendum quod, sicut iam dictum est, electio consequitur sententiam vel iudicium, quod est sicut conclusio syllogismi operativi. Unde illud cadit sub electione, quod se habet ut conclusio in syllogismo operabilium. Finis autem in operabilibus se habet ut principium, et non ut conclusio, ut philosophus dicit in II Physic. Unde finis, inquantum est huiusmodi, non cadit sub electione. Sed sicut in speculativis nihil prohibet id quod est unius demonstrationis vel scientiae principium, esse conclusionem alterius demonstrationis vel scientiae; primum tamen principium indemonstrabile non potest esse conclusio alicuius demonstrationis vel scientiae; ita etiam contingit id quod est in una operatione ut finis, ordinari ad aliquid ut ad finem. Et hoc modo sub electione cadit. Sicut in operatione medici, sanitas se habet ut finis, unde hoc non cadit sub electione medici, sed hoc supponit tanquam principium. Sed sanitas corporis ordinatur ad bonum animae, unde apud eum qui habet curam de animae salute, potest sub electione cadere esse sanum vel esse infirmum; nam apostolus dicit, II ad Cor. XII, *cum enim infirmor, tunc potens sum*. Sed ultimus finis nullo modo sub electione cadit.

###### ad 1
Ad primum ergo dicendum quod fines proprii virtutum ordinantur ad beatitudinem sicut ad ultimum finem. Et hoc modo potest esse eorum electio.

###### ad 2
Ad secundum dicendum quod, sicut supra habitum est, ultimus finis est unus tantum. Unde ubicumque occurrunt plures fines, inter eos potest esse electio, secundum quod ordinantur ad ulteriorem finem.

