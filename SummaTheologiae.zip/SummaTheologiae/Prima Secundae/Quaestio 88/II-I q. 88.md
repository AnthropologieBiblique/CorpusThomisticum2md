## Quaestio 88

### Prooemium

Deinde, quia peccatum veniale et mortale distinguuntur secundum reatum, considerandum est de eis. Et primo, considerandum est de veniali per comparationem ad mortale; secundo, de veniali secundum se. Circa primum quaeruntur sex. Primo, utrum veniale peccatum convenienter dividatur contra mortale. Secundo, utrum distinguantur genere. Tertio, utrum veniale peccatum sit dispositio ad mortale. Quarto, utrum veniale peccatum possit fieri mortale. Quinto, utrum circumstantia aggravans possit de veniali peccato facere mortale. Sexto, utrum peccatum mortale possit fieri veniale.

![[II-I q. 88 a. 1#Articulus 1]]

![[II-I q. 88 a. 2#Articulus 2]]

![[II-I q. 88 a. 3#Articulus 3]]

![[II-I q. 88 a. 4#Articulus 4]]

![[II-I q. 88 a. 5#Articulus 5]]

![[II-I q. 88 a. 6#Articulus 6]]

