### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod peccatum mortale possit fieri veniale. Aequaliter enim distat peccatum veniale a mortali, et e contrario. Sed peccatum veniale fit mortale, ut dictum est. Ergo etiam peccatum mortale potest fieri veniale.

###### arg. 2
Praeterea, peccatum veniale et mortale ponuntur differre secundum hoc, quod peccans mortaliter diligit creaturam plus quam Deum, peccans autem venialiter diligit creaturam infra Deum. Contingit autem quod aliquis committens id quod est ex genere suo peccatum mortale, diligat creaturam infra Deum, puta si aliquis, nesciens fornicationem simplicem esse peccatum mortale et contrariam divino amori, fornicetur, ita tamen quod propter divinum amorem paratus esset fornicationem praetermittere, si sciret fornicando se contra divinum amorem agere. Ergo peccabit venialiter. Et sic peccatum mortale potest fieri veniale.

###### arg. 3
Praeterea, sicut dictum est, plus differt bonum a malo quam veniale a mortali. Sed actus qui est de se malus, potest fieri bonus, sicut homicidium potest fieri actus iustitiae, sicut patet in iudice qui occidit latronem. Ergo multo magis peccatum mortale potest fieri veniale.

###### s. c.
Sed contra est quod aeternum nunquam potest fieri temporale. Sed peccatum mortale meretur poenam aeternam, peccatum autem veniale poenam temporalem. Ergo peccatum mortale nunquam potest fieri veniale.

###### co.
Respondeo dicendum quod veniale et mortale differunt sicut perfectum et imperfectum in genere peccati, ut dictum est. Imperfectum autem per aliquam additionem potest ad perfectionem venire. Unde et veniale, per hoc quod additur ei deformitas pertinens ad genus peccati mortalis, efficitur mortale, sicut cum quis dicit verbum otiosum ut fornicetur. Sed id quod est perfectum, non potest fieri imperfectum per additionem. Et ideo peccatum mortale non fit veniale per hoc quod additur ei aliqua deformitas pertinens ad genus peccati venialis, non enim diminuitur peccatum eius qui fornicatur ut dicat verbum otiosum, sed magis aggravatur propter deformitatem adiunctam. Potest tamen id quod est ex genere mortale, esse veniale propter imperfectionem actus, quia non perfecte pertingit ad rationem actus moralis, cum non sit deliberatus sed subitus, ut ex dictis patet. Et hoc fit per subtractionem quandam, scilicet deliberatae rationis. Et quia a ratione deliberata habet speciem moralis actus, inde est quod per talem subtractionem solvitur species.

###### ad 1
Ad primum ergo dicendum quod veniale differt a mortali sicut imperfectum a perfecto, ut puer a viro. Fit autem ex puero vir, sed non convertitur. Unde ratio non cogit.

###### ad 2
Ad secundum dicendum quod, si sit talis ignorantia quae peccatum omnino excuset, sicut est furiosi vel amentis, tunc ex tali ignorantia fornicationem committens nec mortaliter nec venialiter peccat. Si vero sit ignorantia non invincibilis, tunc ignorantia ipsa est peccatum, et continet in se defectum divini amoris, inquantum negligit homo addiscere ea per quae potest se in divino amore conservare.

###### ad 3
Ad tertium dicendum quod, sicut Augustinus dicit, in libro contra mendacium, *ea quae sunt secundum se mala, nullo fine bene fieri possunt*. Homicidium autem est occisio innocentis, et hoc nullo modo bene fieri potest. Sed iudex qui occidit latronem, vel miles qui occidit hostem reipublicae, non appellantur homicidae, ut Augustinus dicit, in libro de libero arbitrio.

