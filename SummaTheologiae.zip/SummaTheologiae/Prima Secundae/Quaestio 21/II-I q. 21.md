## Quaestio 21

### Prooemium

Deinde considerandum est de his quae consequuntur actus humanos ratione bonitatis vel malitiae. Et circa hoc quaeruntur quatuor. Primo, utrum actus humanus, inquantum est bonus vel malus, habeat rationem rectitudinis vel peccati. Secundo, utrum habeat rationem laudabilis vel culpabilis. Tertio, utrum habeat rationem meriti vel demeriti. Quarto, utrum habeat rationem meriti vel demeriti apud Deum.

![[II-I q. 21 a. 1#Articulus 1]]

![[II-I q. 21 a. 2#Articulus 2]]

![[II-I q. 21 a. 3#Articulus 3]]

