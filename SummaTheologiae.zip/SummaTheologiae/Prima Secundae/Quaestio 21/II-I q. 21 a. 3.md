### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod actus humanus non habeat rationem meriti et demeriti, propter suam bonitatem vel malitiam. Meritum enim et demeritum dicitur per ordinem ad retributionem, quae locum solum habet in his quae ad alterum sunt. Sed non omnes actus humani boni vel mali sunt ad alterum, sed quidam sunt ad seipsum. Ergo non omnis actus humanus bonus vel malus habet rationem meriti vel demeriti.

###### arg. 2
Praeterea, nullus meretur poenam vel praemium ex hoc quod disponit ut vult de eo cuius est dominus, sicut si homo destruat rem suam, non punitur, sicut si destrueret rem alterius. Sed homo est dominus suorum actuum. Ergo ex hoc quod bene vel male disponit de suo actu, non meretur poenam vel praemium.

###### arg. 3
Praeterea, ex hoc quod aliquis sibi ipsi acquirit bonum, non meretur ut ei bene fiat ab alio, et eadem ratio est de malis. Sed ipse actus bonus est quoddam bonum et perfectio agentis, actus autem inordinatus est quoddam malum ipsius. Non ergo ex hoc quod homo facit malum actum vel bonum, meretur vel demeretur.

###### s. c.
Sed contra est quod dicitur [[Is 3]], *dicite iusto quoniam bene, quoniam fructum adinventionum suarum comedet. Vae impio in malum, retributio enim manuum eius fiet ei*.

###### co.
Respondeo dicendum quod meritum et demeritum dicuntur in ordine ad retributionem quae fit secundum iustitiam. Retributio autem secundum iustitiam fit alicui ex eo quod agit in profectum vel nocumentum alterius. Est autem considerandum quod unusquisque in aliqua societate vivens, est aliquo modo pars et membrum totius societatis. Quicumque ergo agit aliquid in bonum vel malum alicuius in societate existentis, hoc redundat in totam societatem sicut qui laedit manum, per consequens laedit hominem. Cum ergo aliquis agit in bonum vel malum alterius singularis personae, cadit ibi dupliciter ratio meriti vel demeriti. Uno modo, secundum quod debetur ei retributio a singulari persona quam iuvat vel offendit. Alio modo, secundum quod debetur ei retributio a toto collegio. Quando vero aliquis ordinat actum suum directe in bonum vel malum totius collegii, debetur ei retributio primo quidem et principaliter a toto collegio, secundario vero, ab omnibus collegii partibus. Cum vero aliquis agit quod in bonum proprium vel malum vergit, etiam debetur ei retributio, inquantum etiam hoc vergit in commune secundum quod ipse est pars collegii, licet non debeatur ei retributio inquantum est bonum vel malum singularis personae, quae est eadem agenti, nisi forte a seipso secundum quandam similitudinem, prout est iustitia hominis ad seipsum. Sic igitur patet quod actus bonus vel malus habet rationem laudabilis vel culpabilis, secundum quod est in potestate voluntatis; rationem vero rectitudinis et peccati, secundum ordinem ad finem; rationem vero meriti et demeriti, secundum retributionem iustitiae ad alterum.

###### ad 1
Ad primum ergo dicendum quod quandoque actus hominis boni vel mali, etsi non ordinantur ad bonum vel malum alterius singularis personae, tamen ordinantur ad bonum vel ad malum alterius quod est ipsa communitas.

###### ad 2
Ad secundum dicendum quod homo, qui habet dominium sui actus, ipse etiam, inquantum est alterius, scilicet communitatis, cuius est pars meretur aliquid vel demeretur, inquantum actus suos bene vel male disponit, sicut etiam si alia sua, de quibus communitati servire debet, bene vel male dispenset.

###### ad 3
Ad tertium dicendum quod hoc ipsum bonum vel malum quod aliquis sibi facit per suum actum, redundat in communitatem, ut dictum est.

