### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod aliqua alia passio possit esse causa amoris. Dicit enim philosophus, in VIII Ethic., quod aliqui amantur propter delectationem. Sed delectatio est passio quaedam. Ergo aliqua alia passio est causa amoris.

###### arg. 2
Praeterea, desiderium quaedam passio est. Sed aliquos amamus propter desiderium alicuius quod ab eis expectamus, sicut apparet in omni amicitia quae est propter utilitatem. Ergo aliqua alia passio est causa amoris.

###### arg. 3
Praeterea, Augustinus dicit, in X de Trin., *cuius rei adipiscendae spem quisque non gerit, aut tepide amat, aut omnino non amat, quamvis quam pulchra sit videat*. Ergo spes etiam est causa amoris.

###### s. c.
Sed contra est quod omnes aliae affectiones animi ex amore causantur, ut Augustinus dicit, XIV de Civ. Dei.

###### co.
Respondeo dicendum quod nulla alia passio animae est quae non praesupponat aliquem amorem. Cuius ratio est quia omnis alia passio animae vel importat motum ad aliquid, vel quietem in aliquo. Omnis autem motus in aliquid, vel quies in aliquo, ex aliqua connaturalitate vel coaptatione procedit, quae pertinet ad rationem amoris. Unde impossibile est quod aliqua alia passio animae sit causa universaliter omnis amoris. Contingit tamen aliquam aliam passionem esse causam amoris alicuius, sicut etiam unum bonum est causa alterius.

###### ad 1
Ad primum ergo dicendum quod, cum aliquis amat aliquid propter delectationem, amor quidem ille causatur ex delectatione, sed delectatio illa iterum causatur ex alio amore praecedente; nullus enim delectatur nisi in re aliquo modo amata.

###### ad 2
Ad secundum dicendum quod desiderium rei alicuius semper praesupponit amorem illius rei. Sed desiderium alicuius rei potest esse causa ut res alia ametur, sicut qui desiderat pecuniam, amat propter hoc eum a quo pecuniam recipit.

###### ad 3
Ad tertium dicendum quod spes causat vel auget amorem, et ratione delectationis, quia delectationem causat, et etiam ratione desiderii, quia spes desiderium fortificat, non enim ita intense desideramus quae non speramus. Sed tamen et ipsa spes est alicuius boni amati.

