### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod non solum bonum sit causa amoris. Bonum enim non est causa amoris, nisi quia amatur. Sed contingit etiam malum amari, secundum illud [[Ps 10]], *qui diligit iniquitatem, odit animam suam*, alioquin omnis amor esset bonus. Ergo non solum bonum est causa amoris.

###### arg. 2
Praeterea, philosophus dicit, in II Rhetoric., quod *eos qui mala sua dicunt, amamus*. Ergo videtur quod malum sit causa amoris.

###### arg. 3
Praeterea, Dionysius dicit, IV cap. de Div. Nom., quod non solum bonum, sed etiam pulchrum est omnibus amabile.

###### s. c.
Sed contra est quod Augustinus dicit, VIII de Trin., *non amatur certe nisi bonum*. Solum igitur bonum est causa amoris.

###### co.
Respondeo dicendum quod, sicut supra dictum est, amor ad appetitivam potentiam pertinet, quae est vis passiva. Unde obiectum eius comparatur ad ipsam sicut causa motus vel actus ipsius. Oportet igitur ut illud sit proprie causa amoris quod est amoris obiectum. Amoris autem proprium obiectum est bonum, quia, ut dictum est, amor importat quandam connaturalitatem vel complacentiam amantis ad amatum; unicuique autem est bonum id quod est sibi connaturale et proportionatum. Unde relinquitur quod bonum sit propria causa amoris.

###### ad 1
Ad primum ergo dicendum quod malum nunquam amatur nisi sub ratione boni, scilicet inquantum est secundum quid bonum, et apprehenditur ut simpliciter bonum. Et sic aliquis amor est malus, inquantum tendit in id quod non est simpliciter verum bonum. Et per hunc modum homo diligit iniquitatem, inquantum per iniquitatem adipiscitur aliquod bonum, puta delectationem vel pecuniam vel aliquid huiusmodi.

###### ad 2
Ad secundum dicendum quod illi qui mala sua dicunt, non propter mala amantur, sed propter hoc quod dicunt mala, hoc enim quod est dicere mala sua, habet rationem boni, inquantum excludit fictionem seu simulationem.

###### ad 3
Ad tertium dicendum quod pulchrum est idem bono, sola ratione differens. Cum enim bonum sit quod omnia appetunt, de ratione boni est quod in eo quietetur appetitus, sed ad rationem pulchri pertinet quod in eius aspectu seu cognitione quietetur appetitus. Unde et illi sensus praecipue respiciunt pulchrum, qui maxime cognoscitivi sunt, scilicet visus et auditus rationi deservientes, dicimus enim pulchra visibilia et pulchros sonos. In sensibilibus autem aliorum sensuum, non utimur nomine pulchritudinis, non enim dicimus pulchros sapores aut odores. Et sic patet quod pulchrum addit supra bonum, quendam ordinem ad vim cognoscitivam, ita quod bonum dicatur id quod simpliciter complacet appetitui; pulchrum autem dicatur id cuius ipsa apprehensio placet.

