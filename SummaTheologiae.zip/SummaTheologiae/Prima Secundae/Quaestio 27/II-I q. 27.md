## Quaestio 27

### Prooemium

Deinde considerandum est de causa amoris. Et circa hoc quaeruntur quatuor. Primo, utrum bonum sit sola causa amoris. Secundo, utrum cognitio sit causa amoris. Tertio, utrum similitudo. Quarto, utrum aliqua alia animae passionum.

![[II-I q. 27 a. 1#Articulus 1]]

![[II-I q. 27 a. 2#Articulus 2]]

![[II-I q. 27 a. 3#Articulus 3]]

![[II-I q. 27 a. 4#Articulus 4]]

