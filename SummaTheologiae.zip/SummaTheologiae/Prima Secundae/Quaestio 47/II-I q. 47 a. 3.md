### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod excellentia alicuius non sit causa quod facilius irascatur. Dicit enim philosophus, in II Rhetoric., quod *maxime aliqui irascuntur cum tristantur, ut infirmi, et egentes, et qui non habent id quod concupiscunt*. Sed omnia ista ad defectum pertinere videntur. Ergo magis facit pronum ad iram defectus quam excellentia.

###### arg. 2
Praeterea, philosophus dicit ibidem quod *tunc aliqui maxime irascuntur, quando in eis despicitur id de quo potest esse suspicio quod vel non insit eis, vel quod insit eis debiliter, sed cum putant se multum excellere in illis in quibus despiciuntur, non curant*. Sed praedicta suspicio ex defectu provenit. Ergo defectus est magis causa quod aliquis irascatur, quam excellentia.

###### arg. 3
Praeterea, ea quae ad excellentiam pertinent, maxime faciunt homines iucundos et bonae spei esse. Sed philosophus dicit, in II Rhetoric., quod *in ludo, in risu, in festo, in prosperitate, in consummatione operum, in delectatione non turpi, et in spe optima, homines non irascuntur*. Ergo excellentia non est causa irae.

###### s. c.
Sed contra est quod philosophus, in eodem libro, dicit quod homines propter excellentiam indignantur.

###### co.
Respondeo dicendum quod causa irae in eo qui irascitur, dupliciter accipi potest. Uno modo, secundum habitudinem ad motivum irae. Et sic excellentia est causa ut aliquis de facili irascatur. Est enim motivum irae iniusta parvipensio, ut dictum est. Constat autem quod quanto aliquis est excellentior, iniustius parvipenditur in hoc in quo excellit. Et ideo illi qui sunt in aliqua excellentia, maxime irascuntur, si parvipendantur, puta si dives parvipenditur in pecunia, et rhetor in loquendo, et sic de aliis. Alio modo potest considerari causa irae in eo qui irascitur, ex parte dispositionis quae in eo relinquitur ex tali motivo. Manifestum est autem quod nihil movet ad iram, nisi nocumentum quod contristat. Ea autem quae ad defectum pertinent, maxime sunt contristantia, quia homines defectibus subiacentes facilius laeduntur. Et ista est causa quare homines qui sunt infirmi, vel in aliis defectibus, facilius irascuntur, quia facilius contristantur.

###### ad 1
Et per hoc patet responsio ad primum.

###### ad 2
Ad secundum dicendum quod ille qui despicitur in eo in quo manifeste multum excellit, non reputat se aliquam iacturam pati, et ideo non contristatur, et ex hac parte minus irascitur. Sed ex alia parte, inquantum indignius despicitur, habet maiorem rationem irascendi. Nisi forte reputet se non invideri vel subsannari propter despectum; sed propter ignorantiam, vel propter aliud huiusmodi.

###### ad 3
Ad tertium dicendum quod omnia illa impediunt iram, inquantum impediunt tristitiam. Sed ex alia parte, nata sunt provocare iram, secundum quod faciunt hominem inconvenientius despici.

