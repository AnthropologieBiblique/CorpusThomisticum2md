## Quaestio 47

### Prooemium

Deinde considerandum est de causa effectiva irae, et de remediis eius. Et circa hoc quaeruntur quatuor. Primo, utrum semper motivum irae sit aliquid factum contra eum qui irascitur. Secundo, utrum sola parvipensio vel despectio sit motivum irae. Tertio, de causa irae ex parte irascentis. Quarto, de causa irae ex parte eius contra quem aliquis irascitur.

![[II-I q. 47 a. 1#Articulus 1]]

![[II-I q. 47 a. 2#Articulus 2]]

![[II-I q. 47 a. 3#Articulus 3]]

![[II-I q. 47 a. 4#Articulus 4]]

