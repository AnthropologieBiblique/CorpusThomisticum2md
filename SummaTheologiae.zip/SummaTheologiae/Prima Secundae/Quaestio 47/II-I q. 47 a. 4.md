### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod defectus alicuius non sit causa ut contra ipsum facilius irascamur. Dicit enim philosophus, in II Rhetoric., quod *his qui confitentur et poenitent et humiliantur, non irascimur, sed magis ad eos mitescimus. Unde et canes non mordent eos qui resident*. Sed haec pertinent ad parvitatem et defectum. Ergo parvitas alicuius est causa ut ei minus irascamur.

###### arg. 2
Praeterea, nullus est maior defectus quam mortis. Sed ad mortuos desinit ira. Ergo defectus alicuius non est causa provocativa irae contra ipsum.

###### arg. 3
Praeterea, nullus aestimat aliquem parvum ex hoc quod est sibi amicus. Sed ad amicos, si nos offenderint, vel si non iuverint, magis offendimur, unde dicitur in Psalmo LIV, *si inimicus meus maledixisset mihi, sustinuissem utique*. Ergo defectus alicuius non est causa ut contra ipsum facilius irascamur.

###### s. c.
Sed contra est quod philosophus dicit, in II Rhetoric., quod *dives irascitur contra pauperem, si eum despiciat; et principans contra subiectum*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, indigna despectio est maxime provocativa irae. Defectus igitur vel parvitas eius contra quem irascimur, facit ad augmentum irae, inquantum auget indignam despectionem. Sicut enim quanto aliquis est maior, tanto indignius despicitur; ita quanto aliquis est minor, tanto indignius despicit. Et ideo nobiles irascuntur si despiciantur a rusticis, vel sapientes ab insipientibus, vel domini a servis. Si vero parvitas vel defectus diminuat despectionem indignam, talis parvitas non auget, sed diminuit iram. Et hoc modo illi qui poenitent de iniuriis factis, et confitentur se male fecisse, et humiliantur et veniam petunt, mitigant iram, secundum illud [[Pr 15]], *responsio mollis frangit iram*, inquantum scilicet tales videntur non despicere, sed magis magnipendere eos quibus se humiliant.

###### ad 1
Et per hoc patet responsio ad primum.

###### ad 2
Ad secundum dicendum quod duplex est causa quare ad mortuos cessat ira. Una, quia non possunt dolere et sentire, quod maxime quaerunt irati in his quibus irascuntur. Alio modo, quia iam videntur ad ultimum malorum pervenisse. Unde etiam ad quoscumque graviter laesos cessat ira, inquantum eorum malum excedit mensuram iustae retributionis.

###### ad 3
Ad tertium dicendum quod etiam despectio quae est ab amicis, videtur esse magis indigna. Et ideo ex simili causa magis irascimur contra eos, si despiciant, vel nocendo vel non iuvando, sicut et contra minores.

