### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod non semper aliquis irascatur propter aliquid contra se factum. Homo enim, peccando, nihil contra Deum facere potest, dicitur enim [[Jb 35]], *si multiplicatae fuerint iniquitates tuae, quid facies contra illum?* Dicitur tamen Deus irasci contra homines propter peccata; secundum illud [[Ps 105]], *iratus est furore dominus in populum suum*. Ergo non semper aliquis irascitur propter aliquid contra se factum.

###### arg. 2
Praeterea, ira est appetitus vindictae. Sed aliquis appetit vindictam facere etiam de his quae contra alios fiunt. Ergo non semper motivum irae est aliquid contra nos factum.

###### arg. 3
Praeterea, sicut philosophus dicit, in II Rhetoric., homines irascuntur praecipue contra eos qui despiciunt *ea circa quae ipsi maxime student, sicut qui student in philosophia, irascuntur contra eos qui philosophiam despiciunt*, et simile est in aliis. Sed despicere philosophiam non est nocere ipsi studenti. Non ergo semper irascimur propter id quod contra nos fit.

###### arg. 4
Praeterea, ille qui tacet contra contumeliantem, magis ipsum ad iram provocat, ut dicit Chrysostomus. Sed in hoc contra ipsum nihil agit, quod tacet. Ergo non semper ira alicuius provocatur propter aliquid quod contra ipsum fit.

###### s. c.
Sed contra est quod philosophus dicit, in II Rhetoric., quod *ira fit semper ex his quae ad seipsum. Inimicitia autem et sine his quae ad ipsum, si enim putemus talem esse odimus*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, ira est appetitus nocendi alteri sub ratione iusti vindicativi. Vindicta autem locum non habet nisi ubi praecessit iniuria. Nec iniuria omnis ad vindictam provocat, sed illa sola quae ad eum pertinet qui appetit vindictam, sicut enim unumquodque naturaliter appetit proprium bonum, ita etiam naturaliter repellit proprium malum. Iniuria autem ab aliquo facta non pertinet ad aliquem, nisi aliquid fecerit quod aliquo modo sit contra ipsum. Unde sequitur quod motivum irae alicuius semper sit aliquid contra ipsum factum.

###### ad 1
Ad primum ergo dicendum quod ira non dicitur in Deo secundum passionem animi, sed secundum iudicium iustitiae, prout vult vindictam facere de peccato. Peccator enim, peccando, Deo nihil nocere effective potest, tamen ex parte sua dupliciter contra Deum agit. Primo quidem, inquantum eum in suis mandatis contemnit. Secundo, inquantum nocumentum aliquod infert alicui, vel sibi vel alteri, quod ad Deum pertinet, prout ille cui nocumentum infertur, sub Dei providentia et tutela continetur.

###### ad 2
Ad secundum dicendum quod irascimur contra illos qui aliis nocent et vindictam appetimus, inquantum illi quibus nocetur, aliquo modo ad nos pertinent, vel per aliquam affinitatem, vel per amicitiam, vel saltem per communionem naturae.

###### ad 3
Ad tertium dicendum quod id in quo maxime studemus, reputamus esse bonum nostrum. Et ideo, cum illud despicitur, reputamus nos quoque despici, et arbitramur nos laesos.

###### ad 4
Ad quartum dicendum quod tunc aliquis tacens ad iram provocat iniuriantem, quando videtur ex contemptu tacere, quasi parvipendat alterius iram. Ipsa autem parvipensio quidam actus est.

