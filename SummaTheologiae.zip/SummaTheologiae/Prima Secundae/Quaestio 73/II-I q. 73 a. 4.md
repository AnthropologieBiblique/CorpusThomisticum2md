### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod gravitas peccatorum non differat secundum dignitatem virtutum quibus peccata opponuntur, ut scilicet maiori virtuti gravius peccatum opponatur. Quia ut dicitur [[Pr 15]], *in abundanti iustitia virtus maxima est*. Sed sicut dicit dominus, [[Mt 5]], abundans iustitia cohibet iram; quae est minus peccatum quam homicidium, quod cohibet minor iustitia. Ergo maximae virtuti opponitur minimum peccatum.

###### arg. 2
Praeterea, in II Ethic. dicitur quod virtus est circa difficile et bonum, ex quo videtur quod maior virtus sit circa magis difficile. Sed minus est peccatum si homo deficiat in magis difficili, quam si deficiat in minus difficili. Ergo maiori virtuti minus peccatum opponitur.

###### arg. 3
Praeterea, caritas est maior virtus quam fides et spes, ut dicitur I ad Cor. XIII. Odium autem, quod opponitur caritati, est minus peccatum quam infidelitas vel desperatio, quae opponuntur fidei et spei. Ergo maiori virtuti opponitur minus peccatum.

###### s. c.
Sed contra est quod philosophus dicit, in VIII Ethic., quod *pessimum optimo contrarium est*. Optimum autem in moralibus est maxima virtus; pessimum autem, gravissimum peccatum. Ergo maximae virtuti opponitur gravissimum peccatum.

###### co.
Respondeo dicendum quod virtuti opponitur aliquod peccatum, uno quidem modo principaliter et directe, quod scilicet est circa idem obiectum, nam contraria circa idem sunt. Et hoc modo oportet quod maiori virtuti opponatur gravius peccatum. Sicut enim ex parte obiecti attenditur maior gravitas peccati, ita etiam maior dignitas virtutis, utrumque enim ex obiecto speciem sortitur, ut ex supradictis patet. Unde oportet quod maximae virtuti directe contrarietur maximum peccatum, quasi maxime ab eo distans in eodem genere. Alio modo potest considerari oppositio virtutis ad peccatum, secundum quandam extensionem virtutis cohibentis peccatum, quanto enim fuerit virtus maior, tanto magis elongat hominem a peccato sibi contrario, ita quod non solum ipsum peccatum, sed etiam inducentia ad peccatum cohibet. Et sic manifestum est quod quanto aliqua virtus fuerit maior, tanto etiam minora peccata cohibet, sicut etiam sanitas, quanto fuerit maior, tanto etiam minores distemperantias excludit. Et per hunc modum maiori virtuti minus peccatum opponitur ex parte effectus.

###### ad 1
Ad primum ergo dicendum quod ratio illa procedit de oppositione quae attenditur secundum cohibitionem peccati, sic enim abundans iustitia etiam minora peccata cohibet.

###### ad 2
Ad secundum dicendum quod maiori virtuti, quae est circa bonum magis difficile, contrariatur directe peccatum quod est circa malum magis difficile. Utrobique enim invenitur quaedam eminentia, ex hoc quod ostenditur voluntas proclivior in bonum vel in malum, ex hoc quod difficultate non vincitur.

###### ad 3
Ad tertium dicendum quod caritas non est quicumque amor, sed amor Dei. Unde non opponitur ei quodcumque odium directe, sed odium Dei, quod est gravissimum peccatorum.

