## Quaestio 73

### Prooemium

Deinde considerandum est de comparatione peccatorum ad invicem. Et circa hoc quaeruntur decem. Primo, utrum omnia peccata et vitia sint connexa. Secundo, utrum omnia sint paria. Tertio, utrum gravitas peccatorum attendatur secundum obiecta. Quarto, utrum secundum dignitatem virtutum quibus peccata opponuntur. Quinto, utrum peccata carnalia sint graviora quam spiritualia. Sexto, utrum secundum causas peccatorum attendatur gravitas peccatorum. Septimo, utrum secundum circumstantias. Octavo, utrum secundum quantitatem nocumenti. Nono, utrum secundum conditionem personae in quam peccatur. Decimo, utrum propter magnitudinem personae peccantis aggravetur peccatum.

![[II-I q. 73 a. 1#Articulus 1]]

![[II-I q. 73 a. 2#Articulus 2]]

![[II-I q. 73 a. 3#Articulus 3]]

![[II-I q. 73 a. 4#Articulus 4]]

![[II-I q. 73 a. 5#Articulus 5]]

![[II-I q. 73 a. 6#Articulus 6]]

![[II-I q. 73 a. 7#Articulus 7]]

![[II-I q. 73 a. 8#Articulus 8]]

![[II-I q. 73 a. 9#Articulus 9]]

