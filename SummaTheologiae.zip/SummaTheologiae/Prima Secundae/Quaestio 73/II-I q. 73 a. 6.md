### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod gravitas peccatorum non attendatur secundum causam peccati. Quanto enim peccati causa fuerit maior, tanto vehementius movet ad peccandum, et ita difficilius potest ei resisti. Sed peccatum diminuitur ex hoc quod ei difficilius resistitur, hoc enim pertinet ad infirmitatem peccantis, ut non facile resistat peccato; peccatum autem quod est ex infirmitate, levius iudicatur. Non ergo peccatum habet gravitatem ex parte suae causae.

###### arg. 2
Praeterea, concupiscentia est generalis quaedam causa peccati, unde dicit Glossa, super illud [[Rm 7]], *nam concupiscentiam nesciebam etc., bona est lex, quae, dum concupiscentiam prohibet, omne malum prohibet*. Sed quanto homo fuerit victus maiori concupiscentia, tanto est minus peccatum. Gravitas ergo peccati diminuitur ex magnitudine causae.

###### arg. 3
Praeterea, sicut rectitudo rationis est causa virtuosi actus, ita defectus rationis videtur esse causa peccati. Sed defectus rationis, quanto fuerit maior, tanto est minus peccatum, intantum quod qui carent usu rationis, omnino excusentur a peccato; et qui ex ignorantia peccat, levius peccat. Ergo gravitas peccati non augetur ex magnitudine causae.

###### s. c.
Sed contra, multiplicata causa, multiplicatur effectus. Ergo, si causa peccati maior fuerit, peccatum erit gravius.

###### co.
Respondeo dicendum quod in genere peccati, sicut et in quolibet alio genere, potest accipi duplex causa. Una quae est propria et per se causa peccati, quae est ipsa voluntas peccandi, comparatur enim ad actum peccati sicut arbor ad fructum, ut dicitur in Glossa, super illud [[Mt 7]], *non potest arbor bona fructus malos facere*. Et huiusmodi causa quanto fuerit maior, tanto peccatum erit gravius, quanto enim voluntas fuerit maior ad peccandum, tanto homo gravius peccat. Aliae vero causae peccati accipiuntur quasi extrinsecae et remotae, ex quibus scilicet voluntas inclinatur ad peccandum. Et in his causis est distinguendum. Quaedam enim harum inducunt voluntatem ad peccandum, secundum ipsam naturam voluntatis, sicut finis, quod est proprium obiectum voluntatis. Et ex tali causa augetur peccatum, gravius enim peccat cuius voluntas ex intentione peioris finis inclinatur ad peccandum. Aliae vero causae sunt quae inclinant voluntatem ad peccandum, praeter naturam et ordinem ipsius voluntatis, quae nata est moveri libere ex seipsa secundum iudicium rationis. Unde causae quae diminuunt iudicium rationis, sicut ignorantia; vel quae diminuunt liberum motum voluntatis, sicut infirmitas vel violentia aut metus, aut aliquid huiusmodi, diminuunt peccatum, sicut et diminuunt voluntarium, intantum quod si actus sit omnino involuntarius, non habet rationem peccati.

###### ad 1
Ad primum ergo dicendum quod obiectio illa procedit de causa movente extrinseca, quae diminuit voluntarium, cuius quidem causae augmentum diminuit peccatum, ut dictum est.

###### ad 2
Ad secundum dicendum quod si sub concupiscentia includatur etiam ipse motus voluntatis, sic ubi est maior concupiscentia, est maius peccatum. Si vero concupiscentia dicatur passio quaedam, quae est motus vis concupiscibilis, sic maior concupiscentia praecedens iudicium rationis et motum voluntatis, diminuit peccatum, quia qui maiori concupiscentia stimulatus peccat, cadit ex graviori tentatione; unde minus ei imputatur. Si vero concupiscentia sic sumpta sequatur iudicium rationis et motum voluntatis, sic ubi est maior concupiscentia, est maius peccatum, insurgit enim interdum maior concupiscentiae motus ex hoc quod voluntas ineffrenate tendit in suum obiectum.

###### ad 3
Ad tertium dicendum quod ratio illa procedit de causa quae causat involuntarium, et haec diminuit peccatum, ut dictum est.

