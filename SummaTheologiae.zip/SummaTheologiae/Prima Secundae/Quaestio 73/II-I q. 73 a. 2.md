### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod omnia peccata sint paria. Hoc enim est peccare, facere quod non licet. Sed facere quod non licet, uno et eodem modo in omnibus reprehenditur. Ergo peccare uno et eodem modo reprehenditur. Non ergo unum peccatum est alio gravius.

###### arg. 2
Praeterea, omne peccatum consistit in hoc quod homo transgreditur regulam rationis, quae ita se habet ad actus humanos, sicut regula linearis in corporalibus rebus. Ergo peccare simile est ei quod est lineas transilire. Sed lineas transilire est aequaliter et uno modo, etiam si aliquis longius recedat vel propinquius stet, quia privationes non recipiunt magis et minus. Ergo omnia peccata sunt aequalia.

###### arg. 3
Praeterea, peccata virtutibus opponuntur. Sed omnes virtutes aequales sunt, ut Tullius dicit, in paradoxis. Ergo omnia peccata sunt paria.

###### s. c.
Sed contra est quod dominus dicit ad Pilatum, [[Jn 19]], *qui tradidit me tibi, maius peccatum habet*. Et tamen constat quod Pilatus aliquod peccatum habuit. Ergo unum peccatum est maius alio.

###### co.
Respondeo dicendum quod opinio Stoicorum fuit, quam Tullius prosequitur in paradoxis, quod omnia peccata sunt paria. Et ex hoc etiam derivatus est quorundam haereticorum error, qui, ponentes omnia peccata esse paria, dicunt etiam omnes poenas Inferni esse pares. Et quantum ex verbis Tullii perspici potest, Stoici movebantur ex hoc quod considerabant peccatum ex parte privationis tantum, prout scilicet est recessus a ratione, unde simpliciter aestimantes quod nulla privatio susciperet magis et minus, posuerunt omnia peccata esse paria. Sed si quis diligenter consideret, inveniet duplex privationum genus. Est enim quaedam simplex et pura privatio, quae consistit quasi in corruptum esse, sicut mors est privatio vitae, et tenebra est privatio luminis. Et tales privationes non recipiunt magis et minus, quia nihil residuum est de habitu opposito. Unde non minus est mortuus aliquis primo die mortis, et tertio vel quarto, quam post annum, quando iam cadaver fuerit resolutum. Et similiter non est magis tenebrosa domus, si lucerna sit operta pluribus velaminibus, quam si sit operta uno solo velamine totum lumen intercludente. Est autem alia privatio non simplex, sed aliquid retinens de habitu opposito; quae quidem privatio magis consistit in corrumpi, quam in corruptum esse, sicut aegritudo, quae privat debitam commensurationem humorum, ita tamen quod aliquid eius remanet, alioquin non remaneret animal vivum; et simile est de turpitudine, et aliis huiusmodi. Huiusmodi autem privationes recipiunt magis et minus ex parte eius quod remanet de habitu contrario, multum enim refert ad aegritudinem vel turpitudinem, utrum plus vel minus a debita commensuratione humorum vel membrorum recedatur. Et similiter dicendum est de vitiis et peccatis, sic enim in eis privatur debita commensuratio rationis, ut non totaliter ordo rationis tollatur; alioquin malum, si sit integrum, destruit seipsum, ut dicitur in IV Ethic.; non enim posset remanere substantia actus, vel affectio agentis, nisi aliquid remaneret de ordine rationis. Et ideo multum interest ad gravitatem peccati, utrum plus vel minus recedatur a rectitudine rationis. Et secundum hoc dicendum est quod non omnia peccata sunt paria.

###### ad 1
Ad primum ergo dicendum quod peccata committere non licet, propter aliquam deordinationem quam habent. Unde illa quae maiorem deordinationem continent, sunt magis illicita; et per consequens graviora peccata.

###### ad 2
Ad secundum dicendum quod ratio illa procedit de peccato, ac si esset privatio pura.

###### ad 3
Ad tertium dicendum quod virtutes sunt aequales proportionaliter in uno et eodem, tamen una virtus praecedit aliam dignitate secundum suam speciem; et unus etiam homo est alio virtuosior in eadem specie virtutis, ut supra habitum est. Et tamen si virtutes essent pares, non sequeretur vitia esse paria, quia virtutes habent connexionem, non autem vitia seu peccata.

