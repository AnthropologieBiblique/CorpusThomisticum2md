## Quaestio 58

### Prooemium

Deinde considerandum est de virtutibus moralibus. Et primo, de distinctione earum a virtutibus intellectualibus; secundo, de distinctione earum ab invicem, secundum propriam materiam; tertio, de distinctione principalium, vel cardinalium, ab aliis. Circa primum quaeruntur quinque. Primo, utrum omnis virtus sit virtus moralis. Secundo, utrum virtus moralis distinguatur ab intellectuali. Tertio, utrum sufficienter dividatur virtus per intellectualem et moralem. Quarto, utrum moralis virtus possit esse sine intellectuali. Quinto, utrum e converso, intellectualis virtus possit esse sine morali.

![[II-I q. 58 a. 1#Articulus 1]]

![[II-I q. 58 a. 2#Articulus 2]]

![[II-I q. 58 a. 3#Articulus 3]]

![[II-I q. 58 a. 4#Articulus 4]]

![[II-I q. 58 a. 5#Articulus 5]]

