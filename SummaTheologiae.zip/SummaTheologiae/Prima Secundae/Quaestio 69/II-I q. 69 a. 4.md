### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod praemia beatitudinum inconvenienter enumerentur. In regno enim caelorum, quod est vita aeterna, bona omnia continentur. Posito ergo regno caelorum, non oportuit alia praemia ponere.

###### arg. 2
Praeterea, regnum caelorum ponitur pro praemio et in prima beatitudine et in octava. Ergo, eadem ratione, debuit poni in omnibus.

###### arg. 3
Praeterea, in beatitudinibus proceditur ascendendo, sicut Augustinus dicit. In praemiis autem videtur procedi descendendo, nam possessio terrae est minus quam regnum caelorum. Ergo inconvenienter huiusmodi praemia assignantur.

###### s. c.
Sed contra est auctoritas ipsius domini, praemia huiusmodi proponentis.

###### co.
Respondeo dicendum quod praemia ista convenientissime assignantur, considerata conditione beatitudinum secundum tres beatitudines supra assignatas. Tres enim primae beatitudines accipiuntur per retractionem ab his in quibus voluptuosa beatitudo consistit, quam homo desiderat quaerens id quod naturaliter desideratur, non ubi quaerere debet, scilicet in Deo, sed in rebus temporalibus et caducis. Et ideo praemia trium primarum beatitudinum accipiuntur secundum ea quae in beatitudine terrena aliqui quaerunt. Quaerunt enim homines in rebus exterioribus, scilicet divitiis et honoribus, excellentiam quandam et abundantiam, quorum utrumque importat regnum caelorum, per quod homo consequitur excellentiam et abundantiam bonorum in Deo. Et ideo regnum caelorum dominus pauperibus spiritu repromisit. Quaerunt autem homines feroces et immites per litigia et bella securitatem sibi acquirere, inimicos suos destruendo. Unde dominus repromisit mitibus securam et quietam possessionem terrae viventium, per quam significatur soliditas aeternorum bonorum. Quaerunt autem homines in concupiscentiis et delectationibus mundi, habere consolationem contra praesentis vitae labores. Et ideo dominus consolationem lugentibus repromittit. Aliae vero duae beatitudines pertinent ad opera activae beatitudinis, quae sunt opera virtutum ordinantium hominem ad proximum, a quibus operibus aliqui retrahuntur propter inordinatum amorem proprii boni. Et ideo dominus attribuit illa praemia his beatitudinibus, propter quae homines ab eis discedunt. Discedunt enim aliqui ab operibus iustitiae, non reddentes debitum, sed potius aliena rapientes ut bonis temporalibus repleantur. Et ideo dominus esurientibus iustitiam, saturitatem repromisit. Discedunt etiam aliqui ab operibus misericordiae, ne se immisceant miseriis alienis. Et ideo dominus misericordibus repromittit misericordiam, per quam ab omni miseria liberentur. Aliae vero duae ultimae beatitudines pertinent ad contemplativam felicitatem seu beatitudinem, et ideo secundum convenientiam dispositionum quae ponuntur in merito, praemia redduntur. Nam munditia oculi disponit ad clare videndum, unde mundis corde divina visio repromittitur. Constituere vero pacem vel in seipso vel inter alios, manifestat hominem esse Dei imitatorem, qui est Deus unitatis et pacis. Et ideo pro praemio redditur ei gloria divinae filiationis, quae est in perfecta coniunctione ad Deum per sapientiam consummatam.

###### ad 1
Ad primum ergo dicendum quod, sicut Chrysostomus dicit, omnia praemia ista unum sunt in re, scilicet beatitudo aeterna; quam intellectus humanus non capit. Et ideo oportuit quod per diversa bona nobis nota, describeretur, observata convenientia ad merita quibus praemia attribuuntur.

###### ad 2
Ad secundum dicendum quod, sicut octava beatitudo est firmitas quaedam omnium beatitudinum, ita debentur sibi omnium beatitudinum praemia. Et ideo redit ad caput, ut intelligantur sibi consequenter omnia praemia attribui. Vel, secundum Ambrosium, pauperibus spiritu repromittitur regnum caelorum, quantum ad gloriam animae, sed passis persecutionem in corpore, quantum ad gloriam corporis.

###### ad 3
Ad tertium dicendum quod etiam praemia secundum additionem se habent ad invicem. Nam plus est possidere terram regni caelorum, quam simpliciter habere, multa enim habemus quae non firmiter et pacifice possidemus. Plus est etiam consolari in regno, quam habere et possidere, multa enim cum dolore possidemus. Plus est etiam saturari quam simpliciter consolari, nam saturitas abundantiam consolationis importat. Misericordia vero excedit saturitatem, ut plus scilicet homo accipiat quam meruerit, vel desiderare potuerit. Adhuc autem maius est Deum videre, sicut maior est qui in curia regis non solum prandet, sed etiam faciem regis videt. Summam autem dignitatem in domo regia filius regis habet.

