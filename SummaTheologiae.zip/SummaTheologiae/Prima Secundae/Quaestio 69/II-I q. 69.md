## Quaestio 69

### Prooemium

Deinde considerandum est de beatitudinibus. Et circa hoc quaeruntur quatuor. Primo, utrum beatitudines a donis et virtutibus distinguantur. Secundo, de praemiis beatitudinum, utrum pertineant ad hanc vitam. Tertio, de numero beatitudinum. Quarto, de convenientia praemiorum quae eis attribuuntur.

![[II-I q. 69 a. 1#Articulus 1]]

![[II-I q. 69 a. 2#Articulus 2]]

![[II-I q. 69 a. 3#Articulus 3]]

![[II-I q. 69 a. 4#Articulus 4]]

