### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod dilatatio non sit effectus delectationis. Dilatatio enim videtur ad amorem magis pertinere, secundum quod dicit apostolus, II ad Cor. VI, *cor nostrum dilatatum est*. Unde et de praecepto caritatis in Psalmo CXVIII, dicitur, *latum mandatum tuum nimis*. Sed delectatio est alia passio ab amore. Ergo dilatatio non est effectus delectationis.

###### arg. 2
Praeterea, ex hoc quod aliquid dilatatur, efficitur capacius ad recipiendum. Sed receptio pertinet ad desiderium, quod est rei nondum habitae. Ergo dilatatio magis videtur pertinere ad desiderium quam ad delectationem.

###### arg. 3
Praeterea, constrictio dilatationi opponitur. Sed constrictio videtur ad delectationem pertinere, nam illud constringimus quod firmiter volumus retinere; et talis est affectio appetitus circa rem delectantem. Ergo dilatatio ad delectationem non pertinet.

###### s. c.
Sed contra est quod, ad expressionem gaudii, dicitur [[Is 60]], *videbis, et affluens, et mirabitur et dilatabitur cor tuum*. Ipsa etiam delectatio ex dilatatione nomen accepit ut laetitia nominetur sicut supra dictum est.

###### co.
Respondeo dicendum quod latitudo est quaedam dimensio magnitudinis corporalis, unde in affectionibus animae non nisi secundum metaphoram dicitur. Dilatatio autem dicitur quasi motus ad latitudinem. Et competit delectationi secundum duo quae ad delectationem requiruntur. Quorum unum est ex parte apprehensivae virtutis, quae apprehendit coniunctionem alicuius boni convenientis. Ex hac autem apprehensione apprehendit se homo perfectionem quandam adeptum, quae est spiritualis magnitudo, et secundum hoc, animus hominis dicitur per delectationem magnificari, seu dilatari. Aliud autem est ex parte appetitivae virtutis, quae assentit rei delectabili, et in ea quiescit, quodammodo se praebens ei ad eam interius capiendam. Et sic dilatatur affectus hominis per delectationem, quasi se tradens ad continendum interius rem delectantem.

###### ad 1
Ad primum ergo dicendum quod nihil prohibet in his quae dicuntur metaphorice, idem diversis attribui secundum diversas similitudines. Et secundum hoc, dilatatio pertinet ad amorem ratione cuiusdam extensionis, inquantum affectus amantis ad alios extenditur, ut curet non solum quae sua sunt, sed quae aliorum. Ad delectationem vero pertinet dilatatio, inquantum aliquid in seipso ampliatur, ut quasi capacius reddatur.

###### ad 2
Ad secundum dicendum quod desiderium habet quidem aliquam ampliationem ex imaginatione rei desideratae, sed multo magis ex praesentia rei iam delectantis. Quia magis praebet se animus rei iam delectanti, quam rei non habitae desideratae, cum delectatio sit finis desiderii.

###### ad 3
Ad tertium dicendum quod ille qui delectatur, constringit quidem rem delectantem, dum ei fortiter inhaeret, sed cor suum ampliat, ut perfecte delectabili fruatur.

