### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod delectatio non impediat usum rationis. Quies enim maxime confert ad debitum rationis usum, unde dicitur in VII Physic., quod in sedendo et quiescendo fit anima sciens et prudens; et [[Sg 8]], *intrans in domum meam, conquiescam cum illa*, scilicet sapientia. Sed delectatio est quaedam quies. Ergo non impedit, sed magis iuvat rationis usum.

###### arg. 2
Praeterea, ea quae non sunt in eodem, etiam si sint contraria, non se impediunt. Sed delectatio est in parte appetitiva, usus autem rationis in parte apprehensiva. Ergo delectatio non impedit rationis usum.

###### arg. 3
Praeterea, quod impeditur ab alio, videtur quodammodo transmutari ab ipso. Sed usus apprehensivae virtutis magis movet delectationem quam a delectatione moveatur, est enim causa delectationis. Ergo delectatio non impedit usum rationis.

###### s. c.
Sed contra est quod philosophus dicit, in VI Ethic., quod *delectatio corrumpit existimationem prudentiae*.

###### co.
Respondeo dicendum quod, sicut dicitur in X Ethic., delectationes propriae adaugent operationes, extraneae vero impediunt. Est ergo quaedam delectatio quae habetur de ipso actu rationis, sicut cum aliquis delectatur in contemplando vel ratiocinando. Et talis delectatio non impedit usum rationis, sed ipsum adiuvat, quia illud attentius operamur in quo delectamur; attentio autem adiuvat operationem. Sed delectationes corporales impediunt usum rationis triplici ratione. Primo quidem, ratione distractionis. Quia, sicut iam dictum est, ad ea in quibus delectamur, multum attendimus, cum autem attentio fortiter inhaeserit alicui rei, debilitatur circa alias res, vel totaliter ab eis revocatur. Et secundum hoc, si delectatio corporalis fuerit magna, vel totaliter impediet usum rationis, ad se intentionem animi attrahendo; vel multum impediet. Secundo, ratione contrarietatis. Quaedam enim delectationes, maxime superexcedentes, sunt contra ordinem rationis. Et per hunc modum philosophus dicit, in VI Ethic., quod *delectationes corporales corrumpunt existimationem prudentiae, non autem existimationem speculativam*, cui non contrariantur, *puta quod triangulus habet tres angulos aequales duobus rectis*. Secundum autem primum modum, utramque impedit. Tertio modo, secundum quandam ligationem, inquantum scilicet ad delectationem corporalem sequitur quaedam transmutatio corporalis, maior etiam quam in aliis passionibus, quanto vehementius afficitur appetitus ad rem praesentem quam ad rem absentem. Huiusmodi autem corporales perturbationes impediunt usum rationis, sicut patet in vinolentis, qui habent usum rationis ligatum vel impeditum.

###### ad 1
Ad primum ergo dicendum quod delectatio corporalis habet quidem quietem appetitus in delectabili, quae quies interdum contrariatur rationi; sed ex parte corporis, semper habet transmutationem. Et quantum ad utrumque, impedit rationis usum.

###### ad 2
Ad secundum dicendum quod vis appetitiva et apprehensiva sunt quidem diversae partes, sed unius animae. Et ideo cum intentio animae vehementer applicatur ad actum unius, impeditur ab actu contrario alterius.

###### ad 3
Ad tertium dicendum quod usus rationis requirit debitum usum imaginationis et aliarum virium sensitivarum, quae utuntur organo corporali. Et ideo ex transmutatione corporali usus rationis impeditur, impedito actu virtutis imaginativae et aliarum sensitivarum.

