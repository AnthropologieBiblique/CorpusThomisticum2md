## Quaestio 33

### Prooemium

Deinde considerandum est de effectibus delectationis. Et circa hoc quaeruntur quatuor. Primo, utrum delectationis sit dilatare. Secundo, utrum delectatio causet sui sitim, vel desiderium. Tertio, utrum delectatio impediat usum rationis. Quarto, utrum delectatio perficiat operationem.

![[II-I q. 33 a. 1#Articulus 1]]

![[II-I q. 33 a. 2#Articulus 2]]

![[II-I q. 33 a. 3#Articulus 3]]

![[II-I q. 33 a. 4#Articulus 4]]

