## Quaestio 104

### Prooemium

Consequenter considerandum est de praeceptis iudicialibus. Et primo, considerandum est de ipsis in communi; secundo, de rationibus eorum. Circa primum quaeruntur quatuor. Primo, quae sint iudicialia praecepta. Secundo, utrum sint figuralia. Tertio, de duratione eorum. Quarto, de distinctione eorum.

![[II-I q. 104 a. 1#Articulus 1]]

![[II-I q. 104 a. 2#Articulus 2]]

![[II-I q. 104 a. 3#Articulus 3]]

![[II-I q. 104 a. 4#Articulus 4]]

