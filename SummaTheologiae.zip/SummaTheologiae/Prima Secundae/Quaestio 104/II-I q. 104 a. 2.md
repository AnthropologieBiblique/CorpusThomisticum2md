### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod praecepta iudicialia non figurent aliquid. Hoc enim videtur esse proprium caeremonialium praeceptorum, quod sint in figuram alicuius rei instituta. Si igitur etiam praecepta iudicialia aliquid figurent, non erit differentia inter iudicialia et caeremonialia praecepta.

###### arg. 2
Praeterea, sicuti illi populo Iudaeorum data sunt quaedam iudicialia praecepta, ita etiam aliis populis gentilium. Sed iudicialia praecepta aliorum populorum non figurant aliquid, sed ordinant quid fieri debeat. Ergo videtur quod neque praecepta iudicialia veteris legis aliquid figurarent.

###### arg. 3
Praeterea, ea quae ad cultum divinum pertinent, figuris quibusdam tradi oportuit, quia ea quae Dei sunt, supra nostram rationem sunt, ut supra dictum est. Sed ea quae sunt proximorum, non excedunt nostram rationem. Ergo per iudicialia, quae ad proximum nos ordinant, non oportuit aliquid figurari.

###### s. c.
Sed contra est quod [[Ex 21]] iudicialia praecepta allegorice et moraliter exponuntur.

###### co.
Respondeo dicendum quod dupliciter contingit aliquod praeceptum esse figurale. Uno modo, primo et per se, quia scilicet principaliter est institutum ad aliquid figurandum. Et hoc modo praecepta caeremonialia sunt figuralia, ad hoc enim sunt instituta, ut aliquid figurent pertinens ad cultum Dei et ad mysterium Christi. Quaedam vero praecepta sunt figuralia non primo et per se, sed ex consequenti. Et hoc modo praecepta iudicialia veteris legis sunt figuralia. Non enim sunt instituta ad aliquid figurandum; sed ad ordinandum statum illius populi secundum iustitiam et aequitatem. Sed ex consequenti aliquid figurabant, inquantum scilicet totus status illius populi, qui per huiusmodi praecepta disponebatur, figuralis erat; secundum illud I ad Cor. X, *omnia in figuram contingebant illis*.

###### ad 1
Ad primum ergo dicendum quod praecepta caeremonialia alio modo sunt figuralia quam iudicialia, ut dictum est.

###### ad 2
Ad secundum dicendum quod populus Iudaeorum ad hoc electus erat a Deo, quod ex eo Christus nasceretur. Et ideo oportuit totum illius populi statum esse propheticum et figuralem, ut Augustinus dicit, contra Faustum. Et propter hoc etiam iudicialia illi populo tradita, magis sunt figuralia quam iudicialia aliis populis tradita. Sicut etiam bella et gesta illius populi exponuntur mystice; non autem bella vel gesta Assyriorum vel Romanorum, quamvis longe clariora secundum homines.

###### ad 3
Ad tertium dicendum quod ordo ad proximum in populo illo, secundum se consideratus, pervius erat rationi. Sed secundum quod referebatur ad cultum Dei, superabat rationem. Et ex hac parte erat figuralis.

