### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod praecepta iudicialia veteris legis perpetuam obligationem habeant. Praecepta enim iudicialia pertinent ad virtutem iustitiae, nam iudicium dicitur iustitiae executio. Iustitia autem est perpetua et immortalis, ut dicitur [[Sg 1]]. Ergo obligatio praeceptorum iudicialium est perpetua.

###### arg. 2
Praeterea, institutio divina est stabilior quam institutio humana. Sed praecepta iudicialia humanarum legum habent perpetuam obligationem. Ergo multo magis praecepta iudicialia legis divinae.

###### arg. 3
Praeterea, apostolus dicit, ad Heb. VII, quod *reprobatio fit praecedentis mandati propter infirmitatem ipsius et inutilitatem*. Quod quidem verum est de mandato caeremoniali quod *non poterat facere perfectum iuxta conscientiam servientem solummodo in cibis et in potibus et variis Baptismatibus et iustitiis carnis*, ut apostolus dicit, ad Heb. IX. Sed praecepta iudicialia utilia erant et efficacia ad id ad quod ordinabantur, scilicet ad iustitiam et aequitatem inter homines constituendam. Ergo praecepta iudicialia veteris legis non reprobantur, sed adhuc efficaciam habent.

###### s. c.
Sed contra est quod apostolus dicit, ad Heb. VII, quod *translato sacerdotio, necesse est ut legis translatio fiat*. Sed sacerdotium est translatum ab Aaron ad Christum. Ergo etiam et tota lex est translata. Non ergo iudicialia praecepta adhuc obligationem habent.

###### co.
Respondeo dicendum quod iudicialia praecepta non habuerunt perpetuam obligationem, sed sunt evacuata per adventum Christi, aliter tamen quam caeremonialia. Nam caeremonialia adeo sunt evacuata ut non solum sint mortua, sed etiam mortifera observantibus post Christum, maxime post Evangelium divulgatum. Praecepta autem iudicialia sunt quidem mortua, quia non habent vim obligandi, non tamen sunt mortifera. Quia si quis princeps ordinaret in regno suo illa iudicialia observari, non peccaret, nisi forte hoc modo observarentur, vel observari mandarentur, tanquam habentia vim obligandi ex veteris legis institutione. Talis enim intentio observandi esset mortifera. Et huius differentiae ratio potest accipi ex praemissis. Dictum est enim quod praecepta caeremonialia sunt figuralia primo et per se, tanquam instituta principaliter ad figurandum Christi mysteria ut futura. Et ideo ipsa observatio eorum praeiudicat fidei veritati, secundum quam confitemur illa mysteria iam esse completa. Praecepta autem iudicialia non sunt instituta ad figurandum, sed ad disponendum statum illius populi, qui ordinabatur ad Christum. Et ideo, mutato statu illius populi, Christo iam veniente, iudicialia praecepta obligationem amiserunt, lex enim fuit paedagogus ducens ad Christum, ut dicitur ad [[Ga 3]]. Quia tamen huiusmodi iudicialia praecepta non ordinantur ad figurandum, sed ad aliquid fiendum, ipsa eorum observatio absolute non praeiudicat fidei veritati. Sed intentio observandi tanquam ex obligatione legis, praeiudicat veritati fidei, quia per hoc haberetur quod status prioris populi adhuc duraret, et quod Christus nondum venisset.

###### ad 1
Ad primum ergo dicendum quod iustitia quidem perpetuo est observanda. Sed determinatio eorum quae sunt iusta secundum institutionem humanam vel divinam, oportet quod varietur secundum diversum hominum statum.

###### ad 2
Ad secundum dicendum quod praecepta iudicialia ab hominibus instituta habent perpetuam obligationem, manente illo statu regiminis. Sed si civitas vel gens ad aliud regimen deveniat, oportet leges mutari. Non enim eaedem leges conveniunt in democratia, quae est potestas populi, et in oligarchia, quae est potestas divitum; ut patet per philosophum, in sua politica. Et ideo etiam, mutato statu illius populi, oportuit praecepta iudicialia mutari.

###### ad 3
Ad tertium dicendum quod illa praecepta iudicialia disponebant populum ad iustitiam et aequitatem secundum quod conveniebat illi statui. Sed post Christum, statum illius populi oportuit mutari, ut iam in Christo non esset discretio gentilis et Iudaei, sicut antea erat. Et propter hoc oportuit etiam praecepta iudicialia mutari.

