### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod praecepta iudicialia non possint habere aliquam certam divisionem. Praecepta enim iudicialia ordinant homines ad invicem. Sed ea quae inter homines ordinari oportet, in usum eorum venientia, non cadunt sub certa distinctione, cum sint infinita. Ergo praecepta iudicialia non possunt habere certam distinctionem.

###### arg. 2
Praeterea, praecepta iudicialia sunt determinationes moralium. Sed moralia praecepta non videntur habere aliquam distinctionem, nisi secundum quod reducuntur ad praecepta Decalogi. Ergo praecepta iudicialia non habent aliquam certam distinctionem.

###### arg. 3
Praeterea, praecepta caeremonialia quia certam distinctionem habent, eorum distinctio in lege innuitur, dum quaedam vocantur sacrificia, quaedam observantiae. Sed nulla distinctio innuitur in lege praeceptorum iudicialium. Ergo videtur quod non habeant certam distinctionem.

###### s. c.
Sed contra, ubi est ordo, oportet quod sit distinctio. Sed ratio ordinis maxime pertinet ad praecepta iudicialia, per quae populus ille ordinabatur. Ergo maxime debent habere distinctionem certam.

###### co.
Respondeo dicendum quod, cum lex sit quasi quaedam ars humanae vitae instituendae vel ordinandae, sicut in unaquaque arte est certa distinctio regularum artis, ita oportet in qualibet lege esse certam distinctionem praeceptorum, aliter enim ipsa confusio utilitatem legis auferret. Et ideo dicendum est quod praecepta iudicialia veteris legis, per quae homines ad invicem ordinabantur, distinctionem habent secundum distinctionem ordinationis humanae. Quadruplex autem ordo in aliquo populo inveniri potest, unus quidem, principum populi ad subditos; alius autem, subditorum ad invicem; tertius autem, eorum qui sunt de populo ad extraneos; quartus autem, ad domesticos, sicut patris ad filium, uxoris ad virum, et domini ad servum. Et secundum istos quatuor ordines distingui possunt praecepta iudicialia veteris legis. Dantur enim quaedam praecepta de institutione principum et officio eorum, et de reverentia eis exhibenda, et haec est una pars iudicialium praeceptorum. Dantur etiam quaedam praecepta pertinentia ad concives ad invicem, puta circa emptiones et venditiones, et iudicia et poenas. Et haec est secunda pars iudicialium praeceptorum. Dantur etiam quaedam praecepta pertinentia ad extraneos, puta de bellis contra hostes, et de susceptione peregrinorum et advenarum. Et haec est tertia pars iudicialium praeceptorum. Dantur etiam in lege quaedam praecepta pertinentia ad domesticam conversationem, sicut de servis, et uxoribus, et filiis. Et haec est quarta pars iudicialium praeceptorum.

###### ad 1
Ad primum ergo dicendum quod ea quae pertinent ad ordinationem hominum ad invicem, sunt quidem numero infinita; sed tamen reduci possunt ad aliqua certa, secundum differentiam ordinationis humanae, ut dictum est.

###### ad 2
Ad secundum dicendum quod praecepta Decalogi sunt prima in genere moralium, ut supra dictum est, et ideo convenienter alia praecepta moralia secundum ea distinguuntur. Sed praecepta iudicialia et caeremonialia habent aliam rationem obligationis non quidem ex ratione naturali sed ex sola institutione. Et ideo distinctionis eorum est alia ratio.

###### ad 3
Ad tertium dicendum quod ex ipsis rebus quae per praecepta iudicialia ordinantur in lege, innuit lex distinctionem iudicialium praeceptorum.

