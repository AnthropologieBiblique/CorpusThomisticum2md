## Quaestio 60

### Prooemium

Deinde considerandum est de distinctione virtutum moralium ad invicem. Et circa hoc quaeruntur quinque. Primo, utrum sit tantum una virtus moralis. Secundo, utrum distinguantur virtutes morales quae sunt circa operationes, ab his quae sunt circa passiones. Tertio, utrum circa operationes sit una tantum moralis virtus. Quarto, utrum circa diversas passiones sint diversae morales virtutes. Quinto, utrum virtutes morales distinguantur secundum diversa obiecta passionum.

![[II-I q. 60 a. 1#Articulus 1]]

![[II-I q. 60 a. 2#Articulus 2]]

![[II-I q. 60 a. 3#Articulus 3]]

![[II-I q. 60 a. 4#Articulus 4]]

![[II-I q. 60 a. 5#Articulus 5]]

