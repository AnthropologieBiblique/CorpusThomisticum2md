## Quaestio 71

### Prooemium

Consequenter considerandum est de vitiis et peccatis. Circa quae sex consideranda occurrunt, primo quidem, de ipsis vitiis et peccatis secundum se; secundo, de distinctione eorum; tertio, de comparatione eorum ad invicem; quarto, de subiecto peccati; quinto, de causa eius; sexto, de effectu ipsius. Circa primum quaeruntur sex. Primo, utrum vitium contrarietur virtuti. Secundo, utrum vitium sit contra naturam. Tertio, quid sit peius, utrum vitium vel actus vitiosus. Quarto, utrum actus vitiosus possit esse simul cum virtute. Quinto, utrum in omni peccato sit aliquis actus. Sexto, de definitione peccati quam Augustinus ponit, XXII contra Faustum, *peccatum est dictum vel factum vel concupitum contra legem aeternam*.

![[II-I q. 71 a. 1#Articulus 1]]

![[II-I q. 71 a. 2#Articulus 2]]

![[II-I q. 71 a. 3#Articulus 3]]

![[II-I q. 71 a. 4#Articulus 4]]

![[II-I q. 71 a. 5#Articulus 5]]

