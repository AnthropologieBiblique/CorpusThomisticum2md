### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod vitium, idest habitus malus sit peius quam peccatum, idest actus malus. Sicut enim bonum quod est diuturnius, est melius; ita malum quod est diuturnius, est peius. Sed habitus vitiosus est diuturnior quam actus vitiosi, qui statim transeunt. Ergo habitus vitiosus est peior quam actus vitiosus.

###### arg. 2
Praeterea, plura mala sunt magis fugienda quam unum malum. Sed habitus malus virtualiter est causa multorum malorum actuum. Ergo habitus vitiosus est peior quam actus vitiosus.

###### arg. 3
Praeterea, causa est potior quam effectus. Sed habitus perficit actum tam in bonitate quam in malitia. Ergo habitus est potior actu et in bonitate et in malitia.

###### s. c.
Sed contra, pro actu vitioso aliquis iuste punitur, non autem pro habitu vitioso, si non procedat ad actum. Ergo actus vitiosus est peior quam habitus vitiosus.

###### co.
Respondeo dicendum quod habitus medio modo se habet inter potentiam et actum. Manifestum est autem quod actus in bono et in malo praeeminet potentiae, ut dicitur in IX Metaphys., melius est enim bene agere quam posse bene agere; et similiter vituperabilius est male agere quam posse male agere. Unde etiam sequitur quod habitus in bonitate et in malitia medium gradum obtineat inter potentiam et actum, ut scilicet, sicut habitus bonus vel malus praeeminet in bonitate vel malitia potentiae, ita etiam subdatur actui. Quod etiam ex hoc apparet, quod habitus non dicitur bonus vel malus nisi ex hoc quod inclinat ad actum bonum vel malum. Unde propter bonitatem vel malitiam actus, dicitur habitus bonus vel malus. Et sic potior est actus in bonitate vel malitia quam habitus, quia propter quod unumquodque tale, et illud magis est.

###### ad 1
Ad primum ergo dicendum quod nihil prohibet aliquid esse simpliciter altero potius, quod tamen secundum quid ab eo deficit. Simpliciter enim potius iudicatur quod praeeminet quantum ad id quod per se consideratur in utroque, secundum quid autem quod praeeminet secundum id quod per accidens se habet ad utrumque. Ostensum est autem ex ipsa ratione actus et habitus, quod actus est potior in bonitate et malitia quam habitus. Quod autem habitus sit diuturnior quam actus, accidit ex eo quod utrumque invenitur in tali natura quae non potest semper agere, et cuius actio est in motu transeunte. Unde simpliciter actus est potior tam in bonitate quam in malitia, sed habitus est potior secundum quid.

###### ad 2
Ad secundum dicendum quod habitus non est simpliciter plures actus, sed secundum quid, idest virtute. Unde ex hoc non potest concludi quod habitus sit simpliciter potior in bonitate vel malitia quam actus.

###### ad 3
Ad tertium dicendum quod habitus est causa actus in genere causae efficientis, sed actus est causa habitus in genere causae finalis, secundum quam consideratur ratio boni et mali. Et ideo in bonitate et malitia actus praeeminet habitui.

