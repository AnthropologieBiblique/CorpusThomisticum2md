### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod Diabolus possit necessitatem inferre ad peccandum. Potestas enim maior potest necessitatem inferre minori. Sed de Diabolo dicitur [[Jb 41]], *non est potestas super terram quae ei valeat comparari*. Ergo potest homini terreno necessitatem inferre ad peccandum.

###### arg. 2
Praeterea, ratio hominis non potest moveri nisi secundum ea quae exterius sensibus proponuntur et imaginationi repraesentantur, quia omnis nostra cognitio ortum habet a sensu, *et non est intelligere sine phantasmate*, ut dicitur in libro de anima. Sed Diabolus potest movere imaginationem hominis, ut dictum est, et etiam exteriores sensus, dicit enim Augustinus, in libro octoginta trium quaest., quod *serpit hoc malum*, scilicet quod est a Diabolo, *per omnes aditus sensuales; dat se figuris, accommodat coloribus, adhaeret sonis, infundit saporibus*. Ergo potest rationem hominis ex necessitate inclinare ad peccandum.

###### arg. 3
Praeterea, secundum Augustinum, *nonnullum peccatum est, cum caro concupiscit adversus spiritum*. Sed concupiscentiam carnis Diabolus potest causare, sicut et ceteras passiones, eo modo quo supra dictum est. Ergo ex necessitate potest inducere ad peccandum.

###### s. c.
Sed contra est quod dicitur I Petr. ult., *adversarius vester Diabolus tanquam leo rugiens circuit, quaerens quem devoret, cui resistite fortes in fide*. Frustra autem talis admonitio daretur, si homo ei ex necessitate succumberet. Non ergo potest homini necessitatem inducere ad peccandum.

###### co.
Respondeo dicendum quod Diabolus propria virtute, nisi refraenetur a Deo, potest aliquem inducere ex necessitate ad faciendum aliquem actum qui de suo genere peccatum est, non autem potest inducere necessitatem peccandi. Quod patet ex hoc quod homo motivo ad peccandum non resistit nisi per rationem, cuius usum totaliter impedire potest movendo imaginationem et appetitum sensitivum, sicut in arreptitiis patet. Sed tunc, ratione sic ligata, quidquid homo agat, non imputatur ei ad peccatum. Sed si ratio non sit totaliter ligata, ex ea parte qua est libera, potest resistere peccato, sicut supra dictum est. Unde manifestum est quod Diabolus nullo modo potest necessitatem inducere homini ad peccandum.

###### ad 1
Ad primum ergo dicendum quod non quaelibet potestas maior homine, potest movere voluntatem hominis, sed solus Deus, ut supra habitum est.

###### ad 2
Ad secundum dicendum quod illud quod est apprehensum per sensum vel imaginationem, non ex necessitate movet voluntatem, si homo habeat usum rationis. Nec semper huiusmodi apprehensio ligat rationem.

###### ad 3
Ad tertium dicendum quod concupiscentia carnis contra spiritum, quando ratio ei actualiter resistit, non est peccatum, sed materia exercendae virtutis. Quod autem ratio ei non resistat, non est in potestate Diaboli. Et ideo non potest inducere necessitatem peccati.

