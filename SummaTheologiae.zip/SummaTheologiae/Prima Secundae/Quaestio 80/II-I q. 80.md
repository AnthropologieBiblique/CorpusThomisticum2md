## Quaestio 80

### Prooemium

Deinde considerandum est de causa peccati ex parte Diaboli. Et circa hoc quaeruntur quatuor. Primo, utrum Diabolus sit directe causa peccati. Secundo, utrum Diabolus inducat ad peccandum interius persuadendo. Tertio, utrum possit necessitatem peccandi inducere. Quarto, utrum omnia peccata ex Diaboli suggestione proveniant.

![[II-I q. 80 a. 1#Articulus 1]]

![[II-I q. 80 a. 2#Articulus 2]]

![[II-I q. 80 a. 3#Articulus 3]]

![[II-I q. 80 a. 4#Articulus 4]]

