### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod omnia peccata hominum sint ex suggestione Diaboli. Dicit enim Dionysius, IV cap. de Div. Nom., quod *multitudo Daemonum causa est omnium malorum et sibi et aliis*.

###### arg. 2
Praeterea, quicumque peccat mortaliter, efficitur servus Diaboli; secundum illud [[Jn 8]], *qui facit peccatum, servus est peccati. Sed ei aliquis in servitutem addicitur, a quo superatus est*, ut dicitur [[2 P 2]]. Ergo quicumque facit peccatum, superatus est a Diabolo.

###### arg. 3
Praeterea, Gregorius dicit quod peccatum Diaboli est irreparabile, quia cecidit nullo suggerente. Si igitur aliqui homines peccarent per liberum arbitrium, nullo suggerente, eorum peccatum esset irremediabile, quod patet esse falsum. Ergo omnia peccata humana a Diabolo suggeruntur.

###### s. c.
Sed contra est quod dicitur in libro de ecclesiasticis dogmatibus, *non omnes cogitationes nostrae malae a Diabolo excitantur, sed aliquoties ex nostri arbitrii motu emergunt*.

###### co.
Respondeo dicendum quod occasionaliter quidem et indirecte Diabolus est causa omnium peccatorum nostrorum, inquantum induxit primum hominem ad peccandum, ex cuius peccato intantum vitiata est humana natura, ut omnes simus ad peccandum proclives, sicut diceretur esse causa combustionis lignorum qui ligna siccaret, ex quo sequeretur quod facile incenderentur. Directe autem non est causa omnium peccatorum humanorum, ita quod singula peccata persuadeat. Quod Origenes probat ex hoc, quia etiam si Diabolus non esset, homines haberent appetitum cibi et venereorum et similium, qui posset esse inordinatus nisi ratione ordinaretur, quod subiacet libero arbitrio.

###### ad 1
Ad primum ergo dicendum quod multitudo Daemonum est causa omnium malorum nostrorum secundum primam originem, ut dictum est.

###### ad 2
Ad secundum dicendum quod non solum fit servus alicuius qui ab eo superatur, sed etiam qui se ei voluntarie subiicit. Et hoc modo fit servus Diaboli qui motu proprio peccat.

###### ad 3
Ad tertium dicendum quod peccatum Diaboli fuit irremediabile, quia nec aliquo suggerente peccavit, nec habuit aliquam pronitatem ad peccandum ex praecedenti suggestione causatam. Quod de nullo hominis peccato dici potest.

