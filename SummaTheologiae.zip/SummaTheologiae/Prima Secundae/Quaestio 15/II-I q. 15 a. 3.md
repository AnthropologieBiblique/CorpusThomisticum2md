### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod consensus sit de fine. Quia propter quod unumquodque, illud magis. Sed his quae sunt ad finem consentimus propter finem. Ergo fini consentimus magis.

###### arg. 2
Praeterea, actio intemperati est finis eius, sicut et actio virtuosi est finis eius. Sed intemperatus consentit in proprium actum. Ergo consensus potest esse de fine.

###### arg. 3
Praeterea, appetitus eorum quae sunt ad finem, est electio, ut supra dictum est. Si igitur consensus esset solum de his quae sunt ad finem, in nullo ab electione differre videretur. Quod patet esse falsum per Damascenum, qui dicit quod post dispositionem, quam vocaverat sententiam, fit electio. Non ergo consensus est solum de his quae sunt ad finem.

###### s. c.
Sed contra est quod Damascenus ibidem dicit, quod *sententia, sive consensus, est quando homo disponit et amat quod ex consilio iudicatum est*. Sed consilium non est nisi de his quae sunt ad finem. Ergo nec consensus.

###### co.
Respondeo dicendum quod consensus nominat applicationem appetitivi motus ad aliquid praeexistens in potestate applicantis in ordine autem agibilium, primo quidem oportet sumere apprehensionem finis; deinde appetitum finis; deinde consilium de his quae sunt ad finem; deinde appetitum eorum quae sunt ad finem. Appetitus autem in ultimum finem tendit naturaliter, unde et applicatio motus appetitivi in finem apprehensum, non habet rationem consensus, sed simplicis voluntatis. De his autem quae sunt post ultimum finem, inquantum sunt ad finem, sub consilio cadunt, et sic potest esse de eis consensus, inquantum motus appetitivus applicatur ad id quod ex consilio iudicatum est. Motus vero appetitivus in finem, non applicatur consilio, sed magis consilium ipsi, quia consilium praesupponit appetitum finis. Sed appetitus eorum quae sunt ad finem, praesupponit determinationem consilii. Et ideo applicatio appetitivi motus ad determinationem consilii, proprie est consensus. Unde, cum consilium non sit nisi de his quae sunt ad finem, consensus, proprie loquendo, non est nisi de his quae sunt ad finem.

###### ad 1
Ad primum ergo dicendum quod, sicut conclusiones scimus per principia, horum tamen non est scientia, sed quod maius est, scilicet intellectus; ita consentimus his quae sunt ad finem propter finem, cuius tamen non est consensus, sed quod maius est, scilicet voluntas.

###### ad 2
Ad secundum dicendum quod intemperatus habet pro fine delectationem operis, propter quam consentit in opus, magis quam ipsam operationem.

###### ad 3
Ad tertium dicendum quod electio addit supra consensum quandam relationem respectu eius cui aliquid praeeligitur, et ideo post consensum, adhuc remanet electio. Potest enim contingere quod per consilium inveniantur plura ducentia ad finem, quorum dum quodlibet placet, in quodlibet eorum consentitur, sed ex multis quae placent, praeaccipimus unum eligendo. Sed si inveniatur unum solum quod placeat, non differunt re consensus et electio, sed ratione tantum, ut consensus dicatur secundum quod placet ad agendum; electio autem, secundum quod praefertur his quae non placent.

