### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod consensus conveniat brutis animalibus. Consensus enim importat determinationem appetitus ad unum. Sed appetitus brutorum animalium sunt determinati ad unum. Ergo consensus in brutis animalibus invenitur.

###### arg. 2
Praeterea, remoto priori, removetur posterius. Sed consensus praecedit operis executionem. Si ergo in brutis non esset consensus, non esset in eis operis executio. Quod patet esse falsum.

###### arg. 3
Praeterea, homines interdum consentire dicuntur in aliquid agendum ex aliqua passione, puta concupiscentia vel ira. Sed bruta animalia ex passione agunt. Ergo in eis est consensus.

###### s. c.
Sed contra est quod Damascenus dicit quod *post iudicium, homo disponit et amat quod ex consilio iudicatum est, quod vocatur sententia*, idest consensus. Sed consilium non est in brutis animalibus. Ergo nec consensus.

###### co.
Respondeo dicendum quod consensus, proprie loquendo, non est in brutis animalibus. Cuius ratio est quia consensus importat applicationem appetitivi motus ad aliquid agendum. Eius autem est applicare appetitivum motum ad aliquid agendum, in cuius potestate est appetitivus motus, sicut tangere lapidem convenit quidem baculo, sed applicare baculum ad tactum lapidis, est eius qui habet in potestate movere baculum. Bruta autem animalia non habent in sui potestate appetitivum motum, sed talis motus in eis est ex instinctu naturae. Unde brutum animal appetit quidem, sed non applicat appetitivum motum ad aliquid. Et propter hoc non proprie dicitur consentire, sed solum rationalis natura, quae habet in potestate sua appetitivum motum, et potest ipsum applicare vel non applicare ad hoc vel ad illud.

###### ad 1
Ad primum ergo dicendum quod in brutis animalibus invenitur determinatio appetitus ad aliquid passive tantum. Consensus vero importat determinationem appetitus non solum passivam, sed magis activam.

###### ad 2
Ad secundum dicendum quod, remoto priori, removetur posterius quod proprie ex eo tantum sequitur. Si autem aliquid ex pluribus sequi possit, non propter hoc posterius removetur, uno priorum remoto, sicut si induratio possit fieri et a calido et frigido (nam lateres indurantur ab igne, et aqua congelata induratur ex frigore), non oportet quod, remoto calore, removeatur induratio. Executio autem operis non solum sequitur ex consensu, sed etiam ex impetuoso appetitu, qualis est in brutis animalibus.

###### ad 3
Ad tertium dicendum quod homines qui ex passione agunt, possunt passionem non sequi. Non autem bruta animalia. Unde non est similis ratio.

