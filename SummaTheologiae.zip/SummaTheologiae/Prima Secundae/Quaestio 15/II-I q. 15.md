## Quaestio 15

### Prooemium

Deinde considerandum est de consensu. Et circa hoc quaeruntur quatuor. Primo, utrum consensus sit actus appetitivae, vel apprehensivae virtutis. Secundo, utrum conveniat brutis animalibus. Tertio, utrum sit de fine, vel de his quae sunt ad finem. Quarto, utrum consensus in actum pertineat solum ad superiorem animae partem.

![[II-I q. 15 a. 1#Articulus 1]]

![[II-I q. 15 a. 2#Articulus 2]]

![[II-I q. 15 a. 3#Articulus 3]]

![[II-I q. 15 a. 4#Articulus 4]]

