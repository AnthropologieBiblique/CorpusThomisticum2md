## Quaestio 76

### Prooemium

Deinde considerandum est de causis peccati in speciali. Et primo, de causis interioribus peccati; secundo, de exterioribus; tertio, de peccatis quae sunt causa aliorum peccatorum. Prima autem consideratio, secundum praemissa, erit tripartita, nam primo, agetur de ignorantia, quae est causa peccati ex parte rationis; secundo, de infirmitate seu passione, quae est causa peccati ex parte appetitus sensitivi; tertio, de malitia, quae est causa peccati ex parte voluntatis. Circa primum quaeruntur quatuor. Primo, utrum ignorantia sit causa peccati. Secundo, utrum ignorantia sit peccatum. Tertio, utrum totaliter a peccato excuset. Quarto, utrum diminuat peccatum.

![[II-I q. 76 a. 1#Articulus 1]]

![[II-I q. 76 a. 2#Articulus 2]]

![[II-I q. 76 a. 3#Articulus 3]]

![[II-I q. 76 a. 4#Articulus 4]]

