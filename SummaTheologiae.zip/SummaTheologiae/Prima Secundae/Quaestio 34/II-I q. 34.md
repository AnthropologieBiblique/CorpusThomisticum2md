## Quaestio 34

### Prooemium

Deinde considerandum est de bonitate et malitia delectationum. Et circa hoc quaeruntur quatuor. Primo, utrum omnis delectatio sit mala. Secundo, dato quod non, utrum omnis delectatio sit bona. Tertio, utrum aliqua delectatio sit optimum. Quarto, utrum delectatio sit mensura vel regula secundum quam iudicetur bonum vel malum in moralibus.

![[II-I q. 34 a. 1#Articulus 1]]

![[II-I q. 34 a. 2#Articulus 2]]

![[II-I q. 34 a. 3#Articulus 3]]

![[II-I q. 34 a. 4#Articulus 4]]

