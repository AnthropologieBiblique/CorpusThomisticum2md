### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod omnis delectatio sit bona. Sicut enim in primo dictum est, bonum in tria dividitur, scilicet honestum, utile et delectabile. Sed honestum omne est bonum; et similiter omne utile. Ergo et omnis delectatio est bona.

###### arg. 2
Praeterea, illud est per se bonum, quod non quaeritur propter aliud, ut dicitur in I Ethic. Sed delectatio non quaeritur propter aliud, ridiculum enim videtur ab aliquo quaerere quare vult delectari. Ergo delectatio est per se bonum. Sed quod per se praedicatur de aliquo, universaliter praedicatur de eo. Ergo omnis delectatio est bona.

###### arg. 3
Praeterea, id quod ab omnibus desideratur, videtur esse per se bonum, nam bonum est quod omnia appetunt, ut dicitur in I Ethic. Sed omnes appetunt aliquam delectationem, etiam pueri et bestiae. Ergo delectatio est secundum se bonum. Omnis ergo delectatio est bona.

###### s. c.
Sed contra est quod dicitur [[Pr 2]], *qui laetantur cum malefecerint, et exultant in rebus pessimis*.

###### co.
Respondeo dicendum quod, sicut aliqui Stoicorum posuerunt omnes delectationes esse malas, ita Epicurei posuerunt delectationem secundum se esse bonum, et per consequens delectationes omnes esse bonas. Qui ex hoc decepti esse videntur, quod non distinguebant inter id quod est bonum simpliciter, et id quod est bonum quoad hunc. Simpliciter quidem bonum est quod secundum se bonum est. Contingit autem quod non est secundum se bonum, esse huic bonum, dupliciter. Uno modo, quia est ei conveniens secundum dispositionem in qua nunc est, quae tamen non est naturalis, sicut leproso bonum est quandoque comedere aliqua venenosa, quae non sunt simpliciter convenientia complexioni humanae. Alio modo, quia id quod non est conveniens, aestimatur ut conveniens. Et quia delectatio est quies appetitus in bono, si sit bonum simpliciter illud in quo quiescit appetitus, erit simpliciter delectatio, et simpliciter bona. Si autem non sit bonum simpliciter, sed quoad hunc, tunc nec delectatio est simpliciter, sed huic, nec simpliciter est bona, sed bona secundum quid, vel apparens bona.

###### ad 1
Ad primum ergo dicendum quod honestum et utile dicuntur secundum rationem, et ideo nihil est honestum vel utile, quod non sit bonum. Delectabile autem dicitur secundum appetitum, qui quandoque in illud tendit quod non est conveniens rationi. Et ideo non omne delectabile est bonum bonitate morali, quae attenditur secundum rationem.

###### ad 2
Ad secundum dicendum quod ideo delectatio non quaeritur propter aliud, quia est quies in fine. Finem autem contingit esse bonum et malum quamvis nunquam sit finis nisi secundum quod est bonum quoad hunc. Ita etiam est de delectatione.

###### ad 3
Ad tertium dicendum quod hoc modo omnia appetunt delectationem, sicut et bonum, cum delectatio sit quies appetitus in bono. Sed sicut contingit non omne bonum quod appetitur, esse per se et vere bonum; ita non omnis delectatio est per se et vere bona.

