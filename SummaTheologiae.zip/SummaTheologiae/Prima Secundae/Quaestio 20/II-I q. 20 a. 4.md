### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod exterior actus non addat in bonitate vel malitia supra actum interiorem. Dicit enim Chrysostomus, super Matth., *voluntas est quae aut remuneratur pro bono, aut condemnatur pro malo*. Opera autem testimonia sunt voluntatis. Non ergo quaerit Deus opera propter se, ut sciat quomodo iudicet; sed propter alios, ut omnes intelligant quia iustus est Deus. Sed malum vel bonum magis est aestimandum secundum iudicium Dei, quam secundum iudicium hominum. Ergo actus exterior nihil addit ad bonitatem vel malitiam super actum interiorem.

###### arg. 2
Praeterea, una et eadem est bonitas interioris et exterioris actus, ut dictum est. Sed augmentum fit per additionem unius ad alterum. Ergo actus exterior non addit in bonitate vel malitia super actum interiorem.

###### arg. 3
Praeterea, tota bonitas creaturae nihil addit supra bonitatem divinam, quia tota derivatur a bonitate divina. Sed bonitas actus exterioris quandoque tota derivatur ex bonitate actus interioris, quandoque autem e converso, ut dictum est. Non ergo unum eorum addit in bonitate vel malitia super alterum.

###### s. c.
Sed contra, omne agens intendit consequi bonum et vitare malum. Si ergo per actum exteriorem nihil additur de bonitate vel malitia, frustra qui habet bonam voluntatem vel malam, facit opus bonum, aut desistit a malo opere. Quod est inconveniens.

###### co.
Respondeo dicendum quod, si loquamur de bonitate exterioris actus quam habet ex voluntate finis, tunc actus exterior nihil addit ad bonitatem, nisi contingat ipsam voluntatem secundum se fieri meliorem in bonis, vel peiorem in malis. Quod quidem videtur posse contingere tripliciter. Uno modo, secundum numerum. Puta, cum aliquis vult aliquid facere bono fine vel malo, et tunc quidem non facit, postmodum autem vult et facit; duplicatur actus voluntatis, et sic fit duplex bonum vel duplex malum. Alio modo, quantum ad extensionem. Puta, cum aliquis vult facere aliquid bono fine vel malo et propter aliquod impedimentum desistit; alius autem continuat motum voluntatis quousque opere perficiat; manifestum est quod huiusmodi voluntas est diuturnior in bono vel malo, et secundum hoc est peior vel melior. Tertio, secundum intensionem. Sunt enim quidam actus exteriores qui, inquantum sunt delectabiles vel poenosi, nati sunt intendere voluntatem vel remittere. Constat autem quod quanto voluntas intensius tendit in bonum vel malum, tanto est melior vel peior. Si autem loquamur de bonitate actus exterioris quam habet secundum materiam et debitas circumstantias, sic comparatur ad voluntatem ut terminus et finis. Et hoc modo addit ad bonitatem vel malitiam voluntatis, quia omnis inclinatio vel motus perficitur in hoc quod consequitur finem, vel attingit terminum. Unde non est perfecta voluntas, nisi sit talis quae, opportunitate data, operetur. Si vero possibilitas desit, voluntate existente perfecta, ut operaretur si posset; defectus perfectionis quae est ex actu exteriori, est simpliciter involuntarium. Involuntarium autem, sicut non meretur poenam vel praemium in operando bonum aut malum, ita non tollit aliquid de praemio vel de poena, si homo involuntarie simpliciter deficiat ad faciendum bonum vel malum.

###### ad 1
Ad primum ergo dicendum quod Chrysostomus loquitur, quando voluntas hominis est consummata, et non cessatur ab actu nisi propter impotentiam faciendi.

###### ad 2
Ad secundum dicendum quod ratio illa procedit de bonitate actus exterioris quam habet a voluntate finis. Sed bonitas actus exterioris quam habet ex materia et circumstantiis, est alia a bonitate voluntatis quae est ex fine, non autem alia a bonitate voluntatis quam habet ex ipso actu volito, sed comparatur ad ipsam ut ratio et causa eius, sicut supra dictum est.

###### ad 3
Et per hoc etiam patet solutio ad tertium.

