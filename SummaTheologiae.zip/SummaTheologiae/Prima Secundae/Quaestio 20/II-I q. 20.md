## Quaestio 20

### Prooemium

Deinde considerandum est de bonitate et malitia quantum ad exteriores actus. Et circa hoc quaeruntur sex. Primo, utrum bonitas et malitia per prius sit in actu voluntatis, vel in actu exteriori secundo, utrum tota bonitas vel malitia actus exterioris dependeat ex bonitate voluntatis. Tertio, utrum sit eadem bonitas et malitia interioris et exterioris actus. Quarto, utrum actus exterior aliquid addat de bonitate vel malitia supra actum interiorem. Quinto, utrum eventus sequens aliquid addat de bonitate vel malitia ad actum exteriorem. Sexto, utrum idem actus exterior possit esse bonus et malus.

![[II-I q. 20 a. 1#Articulus 1]]

![[II-I q. 20 a. 2#Articulus 2]]

![[II-I q. 20 a. 3#Articulus 3]]

![[II-I q. 20 a. 4#Articulus 4]]

![[II-I q. 20 a. 5#Articulus 5]]

![[II-I q. 20 a. 6#Articulus 6]]

