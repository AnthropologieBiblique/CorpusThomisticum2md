### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod unus actus possit esse bonus et malus. Motus enim est unus qui est continuus, ut dicitur in V Physic. Sed unus motus continuus potest esse bonus et malus, puta si aliquis, continue ad Ecclesiam vadens, primo quidem intendat inanem gloriam, postea intendat Deo servire. Ergo unus actus potest esse bonus et malus.

###### arg. 2
Praeterea, secundum philosophum, in III Physic., actio et passio sunt unus actus. Sed potest esse passio bona, sicut Christi; et actio mala, sicut Iudaeorum. Ergo unus actus potest esse bonus et malus.

###### arg. 3
Praeterea, cum servus sit quasi instrumentum domini, actio servi est actio domini, sicut actio instrumenti est actio artificis. Sed potest contingere quod actio servi procedat ex bona voluntate domini, et sic sit bona, et ex mala voluntate servi, et sic sit mala. Ergo idem actus potest esse bonus et malus.

###### s. c.
Sed contra, contraria non possunt esse in eodem. Sed bonum et malum sunt contraria. Ergo unus actus non potest esse bonus et malus.

###### co.
Respondeo dicendum quod nihil prohibet aliquid esse unum, secundum quod est in uno genere; et esse multiplex, secundum quod refertur ad aliud genus. Sicut superficies continua est una, secundum quod consideratur in genere quantitatis, tamen est multiplex, secundum quod refertur ad genus coloris, si partim sit alba, et partim nigra. Et secundum hoc, nihil prohibet aliquem actum esse unum secundum quod refertur ad genus naturae, qui tamen non est unus secundum quod refertur ad genus moris, sicut et e converso, ut dictum est. Ambulatio enim continua est unus actus secundum genus naturae, potest tamen contingere quod sint plures secundum genus moris, si mutetur ambulantis voluntas, quae est principium actuum moralium. Si ergo accipiatur unus actus prout est in genere moris, impossibile est quod sit bonus et malus bonitate et malitia morali. Si tamen sit unus unitate naturae, et non unitate moris, potest esse bonus et malus.

###### ad 1
Ad primum ergo dicendum quod ille motus continuus qui procedit ex diversa intentione, licet sit unus unitate naturae, non est tamen unus unitate moris.

###### ad 2
Ad secundum dicendum quod actio et passio pertinent ad genus moris, inquantum habent rationem voluntarii. Et ideo secundum quod diversa voluntate dicuntur voluntaria, secundum hoc sunt duo moraliter, et potest ex una parte inesse bonum, et ex alia malum.

###### ad 3
Ad tertium dicendum quod actus servi, inquantum procedit ex voluntate servi, non est actus domini, sed solum inquantum procedit ex mandato domini. Unde sic non facit ipsum malum mala voluntas servi.

