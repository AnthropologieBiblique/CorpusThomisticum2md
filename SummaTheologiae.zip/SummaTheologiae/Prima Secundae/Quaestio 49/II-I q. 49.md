## Quaestio 49

### Prooemium

Post actus et passiones, considerandum est de principiis humanorum actuum. Et primo, de principiis intrinsecis; secundo, de principiis extrinsecis. Principium autem intrinsecum est potentia et habitus; sed quia de potentiis in prima parte dictum est, nunc restat de habitibus considerandum. Et primo quidem, in generali; secundo vero, de virtutibus et vitiis, et aliis huiusmodi habitibus, qui sunt humanorum actuum principia. Circa ipsos autem habitus in generali, quatuor consideranda sunt, primo quidem, de ipsa substantia habituum, secundo, de subiecto eorum; tertio, de causa generationis, augmenti et corruptionis ipsorum; quarto, de distinctione ipsorum. Circa primum quaeruntur quatuor. Primo, utrum habitus sit qualitas. Secundo, utrum sit determinata species qualitatis. Tertio, utrum habitus importet ordinem ad actum. Quarto, de necessitate habitus.

![[II-I q. 49 a. 1#Articulus 1]]

![[II-I q. 49 a. 2#Articulus 2]]

![[II-I q. 49 a. 3#Articulus 3]]

![[II-I q. 49 a. 4#Articulus 4]]

