## Quaestio 105

### Prooemium

Deinde considerandum est de ratione iudicialium praeceptorum. Et circa hoc quaeruntur quatuor. Primo, de ratione praeceptorum iudicialium quae pertinent ad principes. Secundo, de his quae pertinent ad convictum hominum ad invicem. Tertio, de his quae pertinent ad extraneos. Quarto, de his quae pertinent ad domesticam conversationem.

![[II-I q. 105 a. 1#Articulus 1]]

![[II-I q. 105 a. 2#Articulus 2]]

![[II-I q. 105 a. 3#Articulus 3]]

