### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod non omnis qui peccat ex habitu, peccet ex certa malitia. Peccatum enim quod est ex certa malitia, videtur esse gravissimum. Sed quandoque homo aliquod leve peccatum committit ex habitu, sicut cum dicit verbum otiosum. Non ergo omne peccatum quod est ex habitu, est ex certa malitia.

###### arg. 2
*Praeterea, actus ex habitu procedentes sunt similes actibus ex quibus habitus generantur*, ut dicitur in II Ethic. Sed actus praecedentes habitum vitiosum non sunt ex certa malitia. Ergo etiam peccata quae sunt ex habitu, non sunt ex certa malitia.

###### arg. 3
Praeterea, in his quae aliquis ex certa malitia committit, gaudet postquam commisit, secundum illud [[Pr 2]], *qui laetantur cum male fecerint et exultant in rebus pessimis*. Et hoc ideo, quia unicuique est delectabile cum consequitur id quod intendit, et qui operatur quod est ei quodammodo connaturale secundum habitum. Sed illi qui peccant ex habitu, post peccatum commissum dolent, poenitudine enim replentur pravi, idest habentes habitum vitiosum, ut dicitur in IX Ethic. Ergo peccata quae sunt ex habitu, non sunt ex certa malitia.

###### s. c.
Sed contra, peccatum ex certa malitia dicitur esse quod est ex electione mali. Sed unicuique est eligibile id ad quod inclinatur per proprium habitum; ut dicitur in VI Ethic. de habitu virtuoso. Ergo peccatum quod est ex habitu, est ex certa malitia.

###### co.
Respondeo dicendum quod non est idem peccare habentem habitum, et peccare ex habitu. Uti enim habitu non est necessarium, sed subiacet voluntati habentis, unde et habitus definitur esse quo quis utitur cum voluerit. Et ideo sicut potest contingere quod aliquis habens habitum vitiosum, prorumpat in actum virtutis, eo quod ratio non totaliter corrumpitur per malum habitum, sed aliquid eius integrum manet, ex quo provenit quod peccator aliqua operatur de genere bonorum; ita etiam potest contingere quod aliquis habens habitum, interdum non ex habitu operetur, sed ex passione insurgente, vel etiam ex ignorantia. Sed quandocumque utitur habitu vitioso, necesse est quod ex certa malitia peccet. Quia unicuique habenti habitum, est per se diligibile id quod est ei conveniens secundum proprium habitum, quia fit ei quodammodo connaturale, secundum quod consuetudo et habitus vertitur in naturam. Hoc autem quod est alicui conveniens secundum habitum vitiosum, est id quod excludit bonum spirituale. Ex quo sequitur quod homo eligat malum spirituale, ut adipiscatur bonum quod est ei secundum habitum conveniens. Et hoc est ex certa malitia peccare. Unde manifestum est quod quicumque peccat ex habitu, peccet ex certa malitia.

###### ad 1
Ad primum ergo dicendum quod peccata venialia non excludunt bonum spirituale, quod est gratia Dei vel caritas. Unde non dicuntur mala simpliciter, sed secundum quid. Et propter hoc nec habitus ipsorum possunt dici simpliciter mali, sed solum secundum quid.

###### ad 2
Ad secundum dicendum quod actus qui procedunt ex habitibus, sunt similes secundum speciem actibus ex quibus habitus generantur, differunt tamen ab eis sicut perfectum ab imperfecto. Et talis est differentia peccati quod committitur ex certa malitia, ad peccatum quod committitur ex aliqua passione.

###### ad 3
Ad tertium dicendum quod ille qui peccat ex habitu, semper gaudet de hoc quod ex habitu operatur, quandiu habitu utitur. Sed quia potest habitu non uti, sed per rationem, quae non est totaliter corrupta, aliquid aliud meditari; potest contingere quod, non utens habitu, doleat de hoc quod per habitum commisit. Plerumque tamen tales poenitent de peccato, non quia eis peccatum secundum se displiceat; sed propter aliquod incommodum quod ex peccato incurrunt.

