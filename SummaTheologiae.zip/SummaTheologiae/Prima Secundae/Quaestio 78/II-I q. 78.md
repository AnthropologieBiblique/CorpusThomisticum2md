## Quaestio 78

### Prooemium

Deinde considerandum est de causa peccati quae est ex parte voluntatis, quae dicitur malitia. Et circa hoc quaeruntur quatuor. Primo, utrum aliquis possit ex certa malitia, seu industria, peccare. Secundo, utrum quicumque peccat ex habitu, peccet ex certa malitia. Tertio, utrum quicumque peccat ex certa malitia, peccet ex habitu. Quarto, utrum ille qui peccat ex certa malitia, gravius peccet quam ille qui peccat ex passione.

![[II-I q. 78 a. 1#Articulus 1]]

![[II-I q. 78 a. 2#Articulus 2]]

![[II-I q. 78 a. 3#Articulus 3]]

![[II-I q. 78 a. 4#Articulus 4]]

