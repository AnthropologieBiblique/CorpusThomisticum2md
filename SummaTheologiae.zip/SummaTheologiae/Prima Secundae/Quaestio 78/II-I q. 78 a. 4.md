### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod ille qui peccat ex certa malitia, non peccet gravius quam ille qui peccat ex passione. Ignorantia enim excusat peccatum vel in toto vel in parte. Sed maior est ignorantia in eo qui peccat ex certa malitia, quam in eo qui peccat ex passione, nam ille qui peccat ex certa malitia, patitur ignorantiam principii, quae est maxima, ut philosophus dicit, in VII Ethic.; habet enim malam existimationem de fine, qui est principium in operativis. Ergo magis excusatur a peccato qui peccat ex certa malitia, quam ille qui peccat ex passione.

###### arg. 2
Praeterea, quanto aliquis habet maius impellens ad peccandum, tanto minus peccat, sicut patet de eo qui maiori impetu passionis deiicitur in peccatum. Sed ille qui peccat ex certa malitia, impellitur ab habitu, cuius est fortior impulsio quam passionis. Ergo ille qui peccat ex habitu, minus peccat quam ille qui peccat ex passione.

###### arg. 3
Praeterea, peccare ex certa malitia est peccare ex electione mali. Sed ille qui peccat ex passione, etiam eligit malum. Ergo non minus peccat quam ille qui peccat ex certa malitia.

###### s. c.
Sed contra est quod peccatum quod ex industria committitur, ex hoc ipso graviorem poenam meretur, secundum illud [[Jb 34]], *quasi impios percussit eos in loco videntium, qui quasi de industria recesserunt ab eo*. Sed poena non augetur nisi propter gravitatem culpae. Ergo peccatum ex hoc aggravatur, quod est ex industria, seu certa malitia.

###### co.
Respondeo dicendum quod peccatum quod est ex certa malitia, est gravius peccato quod est ex passione, triplici ratione. Primo quidem quia, cum peccatum principaliter in voluntate consistat, quanto motus peccati est magis proprius voluntati, tanto peccatum est gravius, ceteris paribus. Cum autem ex certa malitia peccatur, motus peccati est magis proprius voluntati, quae ex seipsa in malum movetur, quam quando ex passione peccatur, quasi ex quodam extrinseco impulsu ad peccandum. Unde peccatum ex hoc ipso quod est ex malitia, aggravatur, et tanto magis, quanto fuerit vehementior malitia. Ex eo vero quod est ex passione, diminuitur, et tanto magis, quanto passio fuerit magis vehemens. Secundo, quia passio quae inclinat voluntatem ad peccandum, cito transit, et sic homo cito redit ad bonum propositum, poenitens de peccato. Sed habitus, quo homo ex malitia peccat, est qualitas permanens, et ideo qui ex malitia peccat, diuturnius peccat. Unde philosophus, in VII Ethic., comparat intemperatum, qui peccat ex malitia, infirmo qui continue laborat; incontinentem autem, qui peccat ex passione, ei qui laborat interpolate. Tertio, quia ille qui peccat ex certa malitia, est male dispositus quantum ad ipsum finem, qui est principium in operabilibus. Et sic eius defectus est periculosior quam eius qui ex passione peccat, cuius propositum tendit in bonum finem, licet hoc propositum interrumpatur ad horam propter passionem. Semper autem defectus principii est pessimus. Unde manifestum est quod gravius est peccatum quod est ex malitia, quam quod est ex passione.

###### ad 1
Ad primum ergo dicendum quod ignorantia electionis, de qua obiectio procedit, neque excusat neque diminuit peccatum, ut supra dictum est. Unde neque maior ignorantia talis facit esse minus peccatum.

###### ad 2
Ad secundum dicendum quod impulsio quae est ex passione, est quasi ex exteriori respectu voluntatis, sed per habitum inclinatur voluntas quasi ab interiori. Unde non est similis ratio.

###### ad 3
Ad tertium dicendum quod aliud est peccare eligentem, et aliud peccare ex electione. Ille enim qui peccat ex passione, peccat quidem eligens, non tamen ex electione, quia electio non est in eo primum peccati principium, sed inducitur ex passione ad eligendum id quod extra passionem existens non eligeret. Sed ille qui peccat ex certa malitia, secundum se eligit malum, eo modo quo dictum est. Et ideo electio in ipso est principium peccati; et propter hoc dicitur ex electione peccare.

