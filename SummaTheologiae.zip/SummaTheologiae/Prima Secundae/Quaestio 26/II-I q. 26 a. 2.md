### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod amor non sit passio. Nulla enim virtus passio est. Sed omnis amor est virtus quaedam, ut dicit Dionysius, IV cap. de Div. Nom. Ergo amor non est passio.

###### arg. 2
Praeterea, amor est unio quaedam vel nexus, secundum Augustinum, in libro de Trin. Sed unio vel nexus non est passio, sed magis relatio. Ergo amor non est passio.

###### arg. 3
Praeterea, Damascenus dicit, in II libro, quod passio est motus quidam. Amor autem non importat motum appetitus, qui est desiderium; sed principium huiusmodi motus. Ergo amor non est passio.

###### s. c.
Sed contra est quod philosophus dicit, in VIII Ethic., quod amor est passio.

###### co.
Respondeo dicendum quod passio est effectus agentis in patiente. Agens autem naturale duplicem effectum inducit in patiens, nam primo quidem dat formam, secundo autem dat motum consequentem formam; sicut generans dat corpori gravitatem, et motum consequentem ipsam. Et ipsa gravitas, quae est principium motus ad locum connaturalem propter gravitatem, potest quodammodo dici amor naturalis. Sic etiam ipsum appetibile dat appetitui, primo quidem, quandam coaptationem ad ipsum, quae est complacentia appetibilis; ex qua sequitur motus ad appetibile. Nam appetitivus motus circulo agitur, ut dicitur in III de anima, appetibile enim movet appetitum, faciens se quodammodo in eius intentione; et appetitus tendit in appetibile realiter consequendum, ut sit ibi finis motus, ubi fuit principium. Prima ergo immutatio appetitus ab appetibili vocatur amor, qui nihil est aliud quam complacentia appetibilis; et ex hac complacentia sequitur motus in appetibile, qui est desiderium; et ultimo quies, quae est gaudium. Sic ergo, cum amor consistat in quadam immutatione appetitus ab appetibili, manifestum est quod amor est passio, proprie quidem, secundum quod est in concupiscibili; communiter autem, et extenso nomine, secundum quod est in voluntate.

###### ad 1
Ad primum ergo dicendum quod, quia virtus significat principium motus vel actionis, ideo amor, inquantum est principium appetitivi motus, a Dionysio vocatur virtus.

###### ad 2
Ad secundum dicendum quod unio pertinet ad amorem, inquantum per complacentiam appetitus amans se habet ad id quod amat, sicut ad seipsum, vel ad aliquid sui. Et sic patet quod amor non est ipsa relatio unionis, sed unio est consequens amorem. Unde et Dionysius dicit quod amor est virtus unitiva, et philosophus dicit, in II Polit., quod unio est opus amoris.

###### ad 3
Ad tertium dicendum quod amor, etsi non nominet motum appetitus tendentem in appetibile, nominat tamen motum appetitus quo immutatur ab appetibili, ut ei appetibile complaceat.

