## Quaestio 26

### Prooemium

Consequenter considerandum est de passionibus animae in speciali. Et primo, de passionibus concupiscibilis; secundo, de passionibus irascibilis. Prima consideratio erit tripartita, nam primo considerabimus de amore et odio; secundo, de concupiscentia et fuga tertio, de delectatione et tristitia. Circa amorem consideranda sunt tria, primo, de ipso amore; secundo, de causa amoris; tertio, de effectibus eius. Circa primum quaeruntur quatuor. Primo, utrum amor sit in concupiscibili. Secundo, utrum amor sit passio. Tertio, utrum amor sit idem quod dilectio. Quarto, utrum amor convenienter dividatur in amorem amicitiae et amorem concupiscentiae.

![[II-I q. 26 a. 1#Articulus 1]]

![[II-I q. 26 a. 2#Articulus 2]]

![[II-I q. 26 a. 3#Articulus 3]]

![[II-I q. 26 a. 4#Articulus 4]]

