### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod amor inconvenienter dividatur in amorem amicitiae et concupiscentiae. Amor enim est passio, amicitia vero est habitus, ut dicit philosophus, in VIII Ethic. Sed habitus non potest esse pars divisiva passionis. Ergo amor non convenienter dividitur per amorem concupiscentiae et amorem amicitiae.

###### arg. 2
Praeterea, nihil dividitur per id quod ei connumeratur, non enim homo connumeratur animali. Sed concupiscentia connumeratur amori, sicut alia passio ab amore. Ergo amor non potest dividi per concupiscentiam.

###### arg. 3
Praeterea, secundum philosophum, in VIII Ethic., triplex est amicitia, utilis, delectabilis et honesta. Sed amicitia utilis et delectabilis habet concupiscentiam. Ergo concupiscentia non debet dividi contra amicitiam.

###### s. c.
Sed contra, quaedam dicimur amare quia ea concupiscimus, sicut *dicitur aliquis amare vinum propter dulce quod in eo concupiscit*, ut dicitur in II Topic. Sed ad vinum, et ad huiusmodi, non habemus amicitiam, ut dicitur in VIII Ethic. Ergo alius est amor concupiscentiae, et alius est amor amicitiae.

###### co.
Respondeo dicendum quod, sicut philosophus dicit in II Rhetoric., amare est velle alicui bonum. Sic ergo motus amoris in duo tendit, scilicet in bonum quod quis vult alicui, vel sibi vel alii; et in illud cui vult bonum. Ad illud ergo bonum quod quis vult alteri, habetur amor concupiscentiae, ad illud autem cui aliquis vult bonum, habetur amor amicitiae. Haec autem divisio est secundum prius et posterius. Nam id quod amatur amore amicitiae, simpliciter et per se amatur, quod autem amatur amore concupiscentiae, non simpliciter et secundum se amatur, sed amatur alteri. Sicut enim ens simpliciter est quod habet esse, ens autem secundum quid quod est in alio; ita bonum, quod convertitur cum ente, simpliciter quidem est quod ipsum habet bonitatem; quod autem est bonum alterius, est bonum secundum quid. Et per consequens amor quo amatur aliquid ut ei sit bonum, est amor simpliciter, amor autem quo amatur aliquid ut sit bonum alterius, est amor secundum quid.

###### ad 1
Ad primum ergo dicendum quod amor non dividitur per amicitiam et concupiscentiam, sed per amorem amicitiae et concupiscentiae. Nam ille proprie dicitur amicus, cui aliquod bonum volumus, illud autem dicimur concupiscere, quod volumus nobis.

###### ad 2
Et per hoc patet solutio ad secundum.

###### ad 3
Ad tertium dicendum quod in amicitia utilis et delectabilis, vult quidem aliquis aliquod bonum amico, et quantum ad hoc salvatur ibi ratio amicitiae. Sed quia illud bonum refert ulterius ad suam delectationem vel utilitatem, inde est quod amicitia utilis et delectabilis, inquantum trahitur ad amorem concupiscentiae, deficit a ratione verae amicitiae.

