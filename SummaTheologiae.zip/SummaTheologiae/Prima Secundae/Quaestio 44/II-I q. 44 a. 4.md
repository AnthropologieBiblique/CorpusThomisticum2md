### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod timor impediat operationem. Operatio enim maxime impeditur ex perturbatione rationis, quae dirigit in opere. Sed timor perturbat rationem, ut dictum est. Ergo timor impedit operationem.

###### arg. 2
Praeterea, illi qui faciunt aliquid cum timore, facilius in operando deficiunt, sicut si aliquis incedat super trabem in alto positam, propter timorem de facili cadit; non autem caderet, si incederet super eandem trabem in imo positam, propter defectum timoris. Ergo timor impedit operationem.

###### arg. 3
Praeterea, pigritia, sive segnities, est quaedam species timoris. Sed pigritia impedit operationem. Ergo et timor.

###### s. c.
Sed contra est quod apostolus dicit, ad [[Ph 2]], *cum metu et tremore vestram salutem operamini*, quod non diceret, si timor bonam operationem impediret. Timor ergo non impedit bonam operationem.

###### co.
Respondeo dicendum quod operatio hominis exterior causatur quidem ab anima sicut a primo movente, sed a membris corporeis sicut ab instrumentis. Contingit autem operationem impediri et propter defectum instrumenti, et propter defectum principalis moventis. Ex parte igitur instrumentorum corporalium, timor, quantum est de se, semper natus est impedire exteriorem operationem, propter defectum caloris qui ex timore accidit in exterioribus membris. Sed ex parte animae, si sit timor moderatus, non multum rationem perturbans; confert ad bene operandum, inquantum causat quandam sollicitudinem, et facit hominem attentius consiliari et operari. Si vero timor tantum increscat quod rationem perturbet, impedit operationem etiam ex parte animae. Sed de tali timore apostolus non loquitur.

###### ad 1
Et per haec patet responsio ad primum.

###### ad 2
Ad secundum dicendum quod illi qui cadunt de trabe in alto posita, patiuntur perturbationem imaginationis, propter timorem casus imaginati.

###### ad 3
Ad tertium dicendum quod omnis timens refugit id quod timet, et ideo, cum pigritia sit timor de ipsa operatione, inquantum est laboriosa, impedit operationem, quia retrahit voluntatem ab ipsa. Sed timor qui est de aliis rebus, intantum adiuvat operationem, inquantum inclinat voluntatem ad operandum ea per quae homo effugit id quod timet.

