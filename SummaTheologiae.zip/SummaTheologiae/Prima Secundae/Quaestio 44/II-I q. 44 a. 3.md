### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod tremor non sit effectus timoris. Tremor enim ex frigore accidit, videmus enim infrigidatos tremere. Timor autem non videtur causare frigus, sed magis calorem desiccantem, cuius signum est quod timentes sitiunt, et praecipue in maximis timoribus, sicut patet in illis qui ad mortem ducuntur. Ergo timor non causat tremorem.

###### arg. 2
Praeterea, emissio superfluitatum ex calore accidit, unde, ut plurimum, medicinae laxativae sunt calidae. Sed huiusmodi emissiones superfluitatum ex timore frequenter contingunt. Ergo timor videtur causare calorem. Et sic non causat tremorem.

###### arg. 3
Praeterea, in timore calor ab exterioribus ad interiora revocatur. Si igitur propter huiusmodi revocationem caloris, in exterioribus homo tremit; videtur quod similiter in omnibus exterioribus membris deberet causari tremor ex timore. Hoc autem non videtur. Non ergo tremor corporis est effectus timoris.

###### s. c.
Sed contra est quod Tullius dicit, in IV de Tusculanis quaest., quod *terrorem sequitur tremor, et pallor, et dentium crepitus*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, in timore fit quaedam contractio ab exterioribus ad interiora, et ideo exteriora frigida remanent. Et propter hoc in eis accidit tremor, qui causatur ex debilitate virtutis continentis membra, ad huiusmodi autem debilitatem maxime facit defectus caloris, qui est instrumentum quo anima movet, ut dicitur in II de anima.

###### ad 1
Ad primum ergo dicendum quod, calore ab exterioribus ad interiora revocato, multiplicatur calor interius, et maxime versus inferiora, idest circa nutritivam. Et ideo, consumpto humido, consequitur sitis, et etiam interdum solutio ventris, et urinae emissio, et quandoque etiam seminis. Vel huiusmodi emissio superfluitatum accidit propter contractionem ventris et testiculorum, ut philosophus dicit, in libro de problematibus.

###### ad 2
Unde patet solutio ad secundum.

###### ad 3
Ad tertium dicendum quod, quia in timore calor deserit cor, a superioribus ad inferiora tendens, ideo timentibus maxime tremit cor, et membra quae habent aliquam connexionem ad pectus, ubi est cor. Unde timentes maxime tremunt in voce, propter vicinitatem vocalis arteriae ad cor. Tremit etiam labium inferius, et tota inferior mandibula, propter continuationem ad cor, unde et crepitus dentium sequitur. Et eadem ratione brachia et manus tremunt. Vel etiam quia huiusmodi membra sunt magis mobilia. Propter quod et genua tremunt timentibus; secundum illud [[Is 35]], *confortate manus dissolutas, et genua trementia roborate*.

