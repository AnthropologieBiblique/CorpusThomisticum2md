## Quaestio 44

### Prooemium

Deinde considerandum est de effectibus timoris. Et circa hoc quaeruntur quatuor. Primo, utrum timor faciat contractionem. Secundo, utrum faciat consiliativos. Tertio, utrum faciat tremorem. Quarto, utrum impediat operationem.

![[II-I q. 44 a. 1#Articulus 1]]

![[II-I q. 44 a. 2#Articulus 2]]

![[II-I q. 44 a. 3#Articulus 3]]

![[II-I q. 44 a. 4#Articulus 4]]

