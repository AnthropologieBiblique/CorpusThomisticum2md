### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod timor non faciat consiliativos. Non enim est eiusdem consiliativos facere, et consilium impedire. Sed timor consilium impedit, omnis enim passio perturbat quietem, quae requiritur ad bonum usum rationis. Ergo timor non facit consiliativos.

###### arg. 2
Praeterea, consilium est actus rationis de futuris cogitantis et deliberantis. Sed aliquis timor est *excutiens cogitata, et mentem a suo loco removet*, ut Tullius dicit, in IV de Tusculanis quaest. Ergo timor non facit consiliativos, sed magis impedit consilium.

###### arg. 3
Praeterea, sicut consilium adhibetur ad vitanda mala, ita etiam adhibetur ad consequenda bona. Sed sicut timor est de malis vitandis, ita spes est de bonis consequendis. Ergo timor non facit magis consiliativos quam spes.

###### s. c.
Sed contra est quod philosophus dicit, in II Rhetoric., quod timor consiliativos facit.

###### co.
Respondeo dicendum quod aliquis potest dici consiliativus dupliciter. Uno modo, a voluntate seu sollicitudine consiliandi. Et sic timor consiliativos facit. Quia, ut philosophus in III Ethic. dicit, *consiliamur de magnis, in quibus quasi nobis ipsis discredimus*. Ea autem quae timorem incutiunt, non sunt simpliciter mala, sed habent quandam magnitudinem, tum ex eo quod apprehenduntur ut quae difficiliter repelli possunt; tum etiam quia apprehenduntur ut de prope existentia, sicut iam dictum est. Unde homines maxime in timoribus quaerunt consiliari. Alio modo dicitur aliquis consiliativus, a facultate bene consiliandi. Et sic nec timor, nec aliqua passio consiliativos facit. Quia homini affecto secundum aliquam passionem, videtur aliquid vel maius vel minus quam sit secundum rei veritatem, sicut amanti videntur ea quae amat, meliora; et timenti, ea quae timet, terribiliora. Et sic ex defectu rectitudinis iudicii, quaelibet passio, quantum est de se, impedit facultatem bene consiliandi.

###### ad 1
Et per hoc patet responsio ad primum.

###### ad 2
Ad secundum dicendum quod quanto aliqua passio est fortior, tanto magis homo secundum ipsam affectus, impeditur. Et ideo quando timor fuerit fortis, vult quidem homo consiliari, sed adeo perturbatur in suis cogitationibus, quod consilium adinvenire non potest. Si autem sit parvus timor, qui sollicitudinem consiliandi inducat, nec multum rationem conturbet; potest etiam conferre ad facultatem bene consiliandi, ratione sollicitudinis consequentis.

###### ad 3
Ad tertium dicendum quod etiam spes facit consiliativos, quia, ut in II Rhetoric. philosophus dicit, *nullus consiliatur de his de quibus desperat*; sicut nec de impossibilibus, ut dicitur in III Ethic. Timor tamen facit magis consiliativos quam spes. Quia spes est de bono, prout possumus ipsum consequi, timor autem de malo, prout vix repelli potest, et ita magis respicit rationem difficilis timor quam spes. In difficilibus autem, maxime in quibus nobis non confidimus, consiliamur, sicut dictum est.

