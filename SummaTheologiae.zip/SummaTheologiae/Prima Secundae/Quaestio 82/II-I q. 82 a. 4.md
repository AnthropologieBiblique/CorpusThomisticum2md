### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod peccatum originale non sit aequaliter in omnibus. Est enim peccatum originale concupiscentia inordinata, ut dictum est. Sed non omnes aequaliter sunt proni ad concupiscendum. Ergo peccatum originale non est aequaliter in omnibus.

###### arg. 2
Praeterea, peccatum originale est quaedam inordinata dispositio animae, sicut aegritudo est quaedam inordinata dispositio corporis. Sed aegritudo recipit magis et minus. Ergo peccatum originale recipit magis et minus.

###### arg. 3
Praeterea, Augustinus dicit, in libro de Nupt. et Concupisc., quod *libido transmittit originale peccatum in prolem*. Sed contingit esse maiorem libidinem unius in actu generationis, quam alterius. Ergo peccatum originale potest esse maius in uno quam in alio.

###### s. c.
Sed contra est quia peccatum originale est peccatum naturae, ut dictum est. Sed natura aequaliter est in omnibus. Ergo et peccatum originale.

###### co.
Respondeo dicendum quod in originali peccato sunt duo, quorum unum est defectus originalis iustitiae; aliud autem est relatio huius defectus ad peccatum primi parentis, a quo per vitiatam originem deducitur. Quantum autem ad primum, peccatum originale non recipit magis et minus, quia totum donum originalis iustitiae est sublatum; privationes autem totaliter aliquid privantes, ut mors et tenebrae, non recipiunt magis et minus, sicut supra dictum est. Similiter etiam nec quantum ad secundum, aequaliter enim omnes relationem habent ad primum principium vitiatae originis, ex quo peccatum originale recipit rationem culpae; relationes enim non recipiunt magis et minus. Unde manifestum est quod peccatum originale non potest esse magis in uno quam in alio.

###### ad 1
Ad primum ergo dicendum quod, soluto vinculo originalis iustitiae, sub quo quodam ordine omnes vires animae continebantur, unaquaeque vis animae tendit in suum proprium motum; et tanto vehementius, quanto fuerit fortior. Contingit autem vires aliquas animae esse fortiores in uno quam in alio, propter diversas corporis complexiones. Quod ergo unus homo sit pronior ad concupiscendum quam alter, non est ratione peccati originalis, cum in omnibus aequaliter solvatur vinculum originalis iustitiae, et aequaliter in omnibus partes inferiores animae sibi relinquantur, sed accidit hoc ex diversa dispositione potentiarum, sicut dictum est.

###### ad 2
Ad secundum dicendum quod aegritudo corporalis non habet in omnibus aequalem causam, etiam si sit eiusdem speciei, puta, si sit febris ex cholera putrefacta, potest esse maior vel minor putrefactio, et propinquior vel remotior a principio vitae. Sed causa originalis peccati in omnibus est aequalis. Unde non est simile.

###### ad 3
Ad tertium dicendum quod libido quae transmittit peccatum originale in prolem, non est libido actualis, quia dato quod virtute divina concederetur alicui quod nullam inordinatam libidinem in actu generationis sentiret, adhuc transmitteret in prolem originale peccatum. Sed libido illa est intelligenda habitualiter, secundum quod appetitus sensitivus non continetur sub ratione vinculo originalis iustitiae. Et talis libido in omnibus est aequalis.

