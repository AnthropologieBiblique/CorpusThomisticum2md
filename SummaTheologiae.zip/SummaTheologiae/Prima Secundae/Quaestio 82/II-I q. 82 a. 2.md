### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod in uno homine sint multa originalia peccata. Dicitur enim in Psalmo l, *ecce enim in iniquitatibus conceptus sum, et in peccatis concepit me mater mea*. Sed peccatum in quo homo concipitur, est originale. Ergo plura peccata originalia sunt in uno homine.

###### arg. 2
Praeterea, unus et idem habitus non inclinat ad contraria, habitus enim inclinat per modum naturae, quae tendit in unum. Sed peccatum originale, etiam in uno homine, inclinat ad diversa peccata et contraria. Ergo peccatum originale non est unus habitus, sed plures.

###### arg. 3
Praeterea, peccatum originale inficit omnes animae partes. Sed diversae partes animae sunt diversa subiecta peccati, ut ex praemissis patet. Cum igitur unum peccatum non possit esse in diversis subiectis, videtur quod peccatum originale non sit unum, sed multa.

###### s. c.
Sed contra est quod dicitur [[Jn 1]], *ecce agnus Dei, ecce qui tollit peccatum mundi*. Quod singulariter dicitur, quia peccatum mundi, quod est peccatum originale, est unum; ut Glossa ibidem exponit.

###### co.
Respondeo dicendum quod in uno homine est unum peccatum originale. Cuius ratio dupliciter accipi potest. Uno modo, ex parte causae peccati originalis. Dictum est enim supra quod solum primum peccatum primi parentis in posteros traducitur. Unde peccatum originale in uno homine est unum numero; et in omnibus hominibus est unum proportione, in respectu scilicet ad primum principium. Alio modo potest accipi ratio eius ex ipsa essentia originalis peccati. In omni enim inordinata dispositione unitas speciei consideratur ex parte causae; unitas autem secundum numerum, ex parte subiecti. Sicut patet in aegritudine corporali, sunt enim diversae aegritudines specie quae ex diversis causis procedunt, puta ex superabundantia calidi vel frigidi, vel ex laesione pulmonis vel hepatis; una autem aegritudo secundum speciem, in uno homine non est nisi una numero. Causa autem huius corruptae dispositionis quae dicitur originale peccatum, est una tantum, scilicet privatio originalis iustitiae, per quam sublata est subiectio humanae mentis ad Deum. Et ideo peccatum originale est unum specie. Et in uno homine non potest esse nisi unum numero, in diversis autem hominibus est unum specie et proportione, diversum autem numero.

###### ad 1
Ad primum ergo dicendum quod pluraliter dicitur in peccatis, secundum illum morem divinae Scripturae quo frequenter ponitur pluralis numerus pro singulari, sicut [[Mt 2]], *defuncti sunt qui quaerebant animam pueri*. Vel quia in peccato originali virtualiter praeexistunt omnia peccata actualia, sicut in quodam principio, unde est multiplex virtute. Vel quia in peccato primi parentis quod per originem traducitur, fuerunt plures deformitates, scilicet superbiae, inobedientiae, gulae, et alia huiusmodi. Vel quia multae partes animae inficiuntur per peccatum originale.

###### ad 2
Ad secundum dicendum quod unus habitus non potest inclinare per se et directe, idest per propriam formam, ad contraria. Sed indirecte et per accidens, scilicet per remotionem prohibentis, nihil prohibet, sicut, soluta harmonia corporis mixti, elementa tendunt in loca contraria. Et similiter, soluta harmonia originalis iustitiae, diversae animae potentiae in diversa feruntur.

###### ad 3
Ad tertium dicendum quod peccatum originale inficit diversas partes animae, secundum quod sunt partes unius totius, sicut et iustitia originalis continebat omnes animae partes in unum. Et ideo est unum tantum peccatum originale. Sicut etiam est una febris in uno homine, quamvis diversae partes corporis graventur.

