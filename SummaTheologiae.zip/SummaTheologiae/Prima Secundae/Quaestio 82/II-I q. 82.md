## Quaestio 82

### Prooemium

Deinde considerandum est de peccato originali quantum ad suam essentiam. Et circa hoc quaeruntur quatuor. Primo, utrum originale peccatum sit habitus. Secundo, utrum sit unum tantum in uno homine. Tertio, utrum sit concupiscentia. Quarto, utrum sit aequaliter in omnibus.

![[II-I q. 82 a. 1#Articulus 1]]

![[II-I q. 82 a. 2#Articulus 2]]

![[II-I q. 82 a. 3#Articulus 3]]

![[II-I q. 82 a. 4#Articulus 4]]

