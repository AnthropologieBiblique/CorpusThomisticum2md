### Articulus 1

###### arg. 1
Ad primum sic proceditur. Videtur quod amor non sit causa timoris. Illud enim quod introducit aliquid, est causa eius. Sed timor introducit amorem caritatis, ut Augustinus dicit, super canonicam Ioan. Ergo timor est causa amoris, et non e converso.

###### arg. 2
Praeterea, philosophus dicit, in II Rhetoric., quod *illi maxime timentur, a quibus expectamus imminere nobis aliqua mala*. Sed per hoc quod ab aliquo expectamus malum, magis provocamur ad odium eius quam ad amorem. Ergo timor magis causatur ab odio quam ab amore.

###### arg. 3
Praeterea, supra dictum est quod ea quae sunt a nobis ipsis, non habent rationem terribilium. Sed ea quae sunt ex amore, maxime proveniunt ex intimo cordis. Ergo timor ex amore non causatur.

###### s. c.
Sed contra est quod Augustinus dicit, in libro octoginta trium quaest., *nulli dubium est non aliam esse metuendi causam, nisi ne id quod amamus, aut adeptum amittamus, aut non adipiscamur speratum*. Omnis ergo timor causatur ex hoc quod aliquid amamus. Amor igitur est causa timoris.

###### co.
Respondeo dicendum quod obiecta passionum animae se habent ad eas tanquam formae ad res naturales vel artificiales, quia passiones animae speciem recipiunt ab obiectis, sicut res praedictae a suis formis. Sicut igitur quidquid est causa formae, est causa rei constitutae per ipsam; ita etiam quidquid, et quocumque modo, est causa obiecti, est causa passionis. Contingit autem aliquid esse causam obiecti vel per modum causae efficientis, vel per modum dispositionis materialis. Sicut obiectum delectationis est bonum apparens conveniens coniunctum, cuius causa efficiens est illud quod facit coniunctionem, vel quod facit convenientiam vel bonitatem, vel apparentiam huiusmodi boni; causa autem per modum dispositionis materialis, est habitus, vel quaecumque dispositio secundum quam fit alicui conveniens aut apparens illud bonum quod est ei coniunctum. Sic igitur, in proposito, obiectum timoris est aestimatum malum futurum propinquum cui resisti de facili non potest. Et ideo illud quod potest inferre tale malum, est causa effectiva obiecti timoris, et per consequens ipsius timoris. Illud autem per quod aliquis ita disponitur ut aliquid sit ei tale, est causa timoris, et obiecti eius, per modum dispositionis materialis. Et hoc modo amor est causa timoris, ex hoc enim quod aliquis amat aliquod bonum, sequitur quod privativum talis boni sit ei malum, et per consequens quod timeat ipsum tanquam malum.

###### ad 1
Ad primum ergo dicendum quod, sicut supra dictum est, timor per se et primo respicit ad malum, quod refugit, quod opponitur alicui bono amato. Et sic per se timor nascitur ex amore. Secundario vero respicit ad id per quod provenit tale malum. Et sic per accidens quandoque timor inducit amorem, inquantum scilicet homo qui timet puniri a Deo, servat mandata eius, et sic incipit sperare, et spes introducit amorem, ut supra dictum est.

###### ad 2
Ad secundum dicendum quod ille a quo expectantur mala, primo quidem odio habetur, sed postquam ab ipso iam incipiunt sperari bona, tunc incipit amari. Bonum autem cui contrariatur malum quod timetur, a principio amabatur.

###### ad 3
Ad tertium dicendum quod ratio illa procedit de eo quod est causa mali terribilis per modum efficientis. Amor autem est causa eius per modum materialis dispositionis, ut dictum est.

