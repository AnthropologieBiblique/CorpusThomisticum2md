## Quaestio 43

### Prooemium

Deinde considerandum est de causa timoris. Et circa hoc quaeruntur duo. Primo, utrum causa timoris sit amor. Secundo, utrum causa timoris sit defectus.

![[II-I q. 43 a. 1#Articulus 1]]

![[II-I q. 43 a. 2#Articulus 2]]

