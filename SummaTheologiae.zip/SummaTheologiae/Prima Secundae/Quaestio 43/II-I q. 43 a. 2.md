### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod defectus non sit causa timoris. Illi enim qui potentiam habent, maxime timentur. Sed defectus contrariatur potentiae. Ergo defectus non est causa timoris.

###### arg. 2
Praeterea, illi qui iam decapitantur, maxime sunt in defectu. Sed tales non timent. Ut dicitur in II Rhetoric. Ergo defectus non est causa timoris.

###### arg. 3
Praeterea, decertare ex fortitudine provenit, non ex defectu. *Sed decertantes timent eos qui pro eisdem decertant*, ut dicitur in II Rhetoric. Ergo defectus non est causa timoris.

###### s. c.
Sed contra, contrariorum contrariae sunt causae. Sed *divitiae, et robur, et multitudo amicorum, et potestas, excludunt timorem*, ut dicitur in II Rhetoric. Ergo ex defectu horum timor causatur.

###### co.
Respondeo dicendum quod, sicut supra dictum est, duplex causa timoris accipi potest, una quidem per modum materialis dispositionis, ex parte eius qui timet; alia per modum causae efficientis, ex parte eius qui timetur. Quantum igitur ad primum, defectus, per se loquendo, est causa timoris, ex aliquo enim defectu virtutis contingit quod non possit aliquis de facili repellere imminens malum. Sed tamen ad causandum timorem requiritur defectus cum aliqua mensura. Minor enim est defectus qui causat timorem futuri mali, quam defectus consequens malum praesens, de quo est tristitia. Et adhuc esset maior defectus, si totaliter sensus mali auferretur, vel amor boni cuius contrarium timetur. Quantum vero ad secundum, virtus et robur, per se loquendo, est causa timoris, ex hoc enim quod aliquid quod apprehenditur ut nocivum, est virtuosum, contingit quod eius effectus repelli non potest. Contingit tamen per accidens quod aliquis defectus ex ista parte causat timorem, inquantum ex aliquo defectu contingit quod aliquis velit nocumentum inferre, puta propter iniustitiam, vel quia ante laesus fuit, vel quia timet laedi.

###### ad 1
Ad primum ergo dicendum quod ratio illa procedit de causa timoris ex parte causae efficientis.

###### ad 2
Ad secundum dicendum quod illi qui iam decapitantur, sunt in passione praesentis mali. Et ideo iste defectus excedit mensuram timoris.

###### ad 3
Ad tertium dicendum quod decertantes timent non propter potentiam, qua decertare possunt, sed propter defectum potentiae, ex quo contingit quod se superaturos non confidunt.

