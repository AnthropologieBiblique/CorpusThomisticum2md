### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod peccatum originale non sit per prius in essentia animae quam in potentiis. Anima enim nata est esse subiectum peccati, quantum ad id quod potest a voluntate moveri. Sed anima non movetur a voluntate secundum suam essentiam, sed solum secundum potentias. Ergo peccatum originale non est in anima secundum suam essentiam, sed solum secundum potentias.

###### arg. 2
Praeterea, peccatum originale opponitur originali iustitiae. Sed originalis iustitia erat in aliqua potentia animae, quae est subiectum virtutis. Ergo et peccatum originale est magis in potentia animae quam in eius essentia.

###### arg. 3
Praeterea, sicut a carne peccatum originale derivatur ad animam, ita ab essentia animae derivatur ad potentias. Sed peccatum originale magis est in anima quam in carne. Ergo etiam magis est in potentiis animae quam in essentia.

###### arg. 4
Praeterea, peccatum originale dicitur esse concupiscentia, ut dictum est. Sed concupiscentia est in potentiis animae. Ergo et peccatum originale.

###### s. c.
Sed contra est quod peccatum originale dicitur esse peccatum naturale, ut supra dictum est. Anima autem est forma et natura corporis secundum essentiam suam, et non secundum potentias, ut in primo habitum est. Ergo anima est subiectum originalis peccati principaliter secundum suam essentiam.

###### co.
Respondeo dicendum quod illud animae est principaliter subiectum alicuius peccati, ad quod primo pertinet causa motiva illius peccati, sicut si causa motiva ad peccandum sit delectatio sensus, quae pertinet ad vim concupiscibilem sicut obiectum proprium eius, sequitur quod vis concupiscibilis sit proprium subiectum illius peccati. Manifestum est autem quod peccatum originale causatur per originem. Unde illud animae quod primo attingitur ab origine hominis, est primum subiectum originalis peccati. Attingit autem origo animam ut terminum generationis, secundum quod est forma corporis; quod quidem convenit ei secundum essentiam propriam, ut in primo habitum est. Unde anima secundum essentiam est primum subiectum originalis peccati.

###### ad 1
Ad primum ergo dicendum quod, sicut motio voluntatis alicuius propriae pervenit ad potentias animae, non autem ad animae essentiam; ita motio voluntatis primi generantis, per viam generationis, pervenit primo ad animae essentiam, ut dictum est.

###### ad 2
Ad secundum dicendum quod etiam originalis iustitia pertinebat primordialiter ad essentiam animae, erat enim donum divinitus datum humanae naturae, quam per prius respicit essentia animae quam potentiae. Potentiae enim magis videntur pertinere ad personam, inquantum sunt principia personalium actuum. Unde sunt propria subiecta peccatorum actualium, quae sunt peccata personalia.

###### ad 3
Ad tertium dicendum quod corpus comparatur ad animam sicut materia ad formam, quae etsi sit posterior ordine generationis, est tamen prior ordine perfectionis et naturae. Essentia autem animae comparatur ad potentias sicut subiecta ad accidentia propria, quae sunt posteriora subiecto et ordine generationis et etiam perfectionis. Unde non est similis ratio.

###### ad 4
Ad quartum dicendum quod concupiscentia se habet materialiter et ex consequenti in peccato originali, ut supra dictum est.

