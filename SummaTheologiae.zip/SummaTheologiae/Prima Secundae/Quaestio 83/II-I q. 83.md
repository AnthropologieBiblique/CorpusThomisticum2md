## Quaestio 83

### Prooemium

Deinde considerandum est de subiecto originalis peccati. Et circa hoc quaeruntur quatuor. Primo, utrum subiectum originalis peccati per prius sit caro vel anima. Secundo, si anima, utrum per essentiam aut per potentias suas. Tertio, utrum voluntas per prius sit subiectum peccati originalis quam aliae potentiae. Quarto, utrum aliquae potentiae animae sint specialiter infectae, scilicet generativa, vis concupiscibilis et sensus tactus.

![[II-I q. 83 a. 1#Articulus 1]]

![[II-I q. 83 a. 2#Articulus 2]]

![[II-I q. 83 a. 3#Articulus 3]]

![[II-I q. 83 a. 4#Articulus 4]]

