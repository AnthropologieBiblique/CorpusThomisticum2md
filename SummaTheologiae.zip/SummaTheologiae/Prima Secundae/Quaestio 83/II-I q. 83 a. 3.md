### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod peccatum originale non per prius inficiat voluntatem quam alias potentias. Omne enim peccatum principaliter pertinet ad potentiam per cuius actum causatur. Sed peccatum originale causatur per actum generativae potentiae. Ergo inter ceteras potentias animae, videtur magis pertinere ad generativam potentiam.

###### arg. 2
Praeterea, peccatum originale per semen carnale traducitur. Sed aliae vires animae propinquiores sunt carni quam voluntas, sicut patet de omnibus sensitivis, quae utuntur organo corporali. Ergo in eis magis est peccatum originale quam in voluntate.

###### arg. 3
Praeterea, intellectus est prior voluntate, non enim est voluntas nisi de bono intellecto. Si ergo peccatum originale inficit omnes potentias animae, videtur quod per prius inficiat intellectum, tanquam priorem.

###### s. c.
Sed contra est quod iustitia originalis per prius respicit voluntatem, est enim rectitudo voluntatis, ut Anselmus dicit, in libro de conceptu virginali. Ergo et peccatum originale, quod ei opponitur, per prius respicit voluntatem.

###### co.
Respondeo dicendum quod in infectione peccati originalis duo est considerare. Primo quidem, inhaerentiam eius ad subiectum, et secundum hoc primo respicit essentiam animae, ut dictum est. Deinde oportet considerare inclinationem eius ad actum, et hoc modo respicit potentias animae. Oportet ergo quod illam per prius respiciat, quae primam inclinationem habet ad peccandum. Haec autem est voluntas, ut ex supradictis patet. Unde peccatum originale per prius respicit voluntatem.

###### ad 1
Ad primum ergo dicendum quod peccatum originale non causatur in homine per potentiam generativam prolis, sed per actum potentiae generativae parentis. Unde non oportet quod sua potentia generativa sit primum subiectum originalis peccati.

###### ad 2
Ad secundum dicendum quod peccatum originale habet duplicem processum, unum quidem a carne ad animam; alium vero ab essentia animae ad potentias. Primus quidem processus est secundum ordinem generationis, secundus autem secundum ordinem perfectionis. Et ideo quamvis aliae potentiae, scilicet sensitivae, propinquiores sint carni; quia tamen voluntas est propinquior essentiae animae, tanquam superior potentia, primo pervenit ad ipsam infectio originalis peccati.

###### ad 3
Ad tertium dicendum quod intellectus quodam modo praecedit voluntatem, inquantum proponit ei suum obiectum. Alio vero modo voluntas praecedit intellectum, secundum ordinem motionis ad actum, quae quidem motio pertinet ad peccatum.

