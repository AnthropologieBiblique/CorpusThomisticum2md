### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod consilium non solum sit de his quae sunt ad finem, sed etiam de fine. Quaecumque enim dubitationem habent, de his potest inquiri. Sed circa operabilia humana contingit esse dubitationem de fine, et non solum de his quae sunt ad finem. Cum igitur inquisitio circa operabilia sit consilium, videtur quod consilium possit esse de fine.

###### arg. 2
Praeterea, materia consilii sunt operationes humanae. Sed quaedam operationes humanae sunt fines, ut dicitur in I Ethic. ergo consilium potest esse de fine.

###### s. c.
Sed contra est quod Gregorius Nyssenus dicit, quod *non de fine, sed de his quae sunt ad finem, est consilium*.

###### co.
Respondeo dicendum quod finis in operabilibus habet rationem principii, eo quod rationes eorum quae sunt ad finem, ex fine sumuntur. Principium autem non cadit sub quaestione, sed principia oportet supponere in omni inquisitione. Unde cum consilium sit quaestio, de fine non est consilium, sed solum de his quae sunt ad finem. Tamen contingit id quod est finis respectu quorundam, ordinari ad alium finem, sicut etiam id quod est principium unius demonstrationis, est conclusio alterius. Et ideo id quod accipitur ut finis in una inquisitione, potest accipi ut ad finem in alia inquisitione. Et sic de eo erit consilium.

###### ad 1
Ad primum ergo dicendum quod id quod accipitur ut finis, est iam determinatum. Unde quandiu habetur ut dubium, non habetur ut finis. Et ideo si de eo consilium habetur, non erit consilium de fine, sed de eo quod est ad finem.

###### ad 2
Ad secundum dicendum quod de operationibus est consilium, inquantum ordinantur ad aliquem finem. Unde si aliqua operatio humana sit finis, de ea, inquantum huiusmodi, non est consilium.

