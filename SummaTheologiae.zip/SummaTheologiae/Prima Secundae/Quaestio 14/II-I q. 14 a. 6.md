### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod inquisitio consilii procedat in infinitum. Consilium enim est inquisitio de particularibus, in quibus est operatio. Sed singularia sunt infinita. Ergo inquisitio consilii est infinita.

###### arg. 2
Praeterea, sub inquisitione consilii cadit considerare non solum quid agendum sit, sed etiam quomodo impedimenta tollantur. Sed quaelibet humana actio potest impediri, et impedimentum tolli potest per aliquam rationem humanam. Ergo in infinitum remanet quaerere de impedimentis tollendis.

###### arg. 3
Praeterea, inquisitio scientiae demonstrativae non procedit in infinitum, quia est devenire in aliqua principia per se nota, quae omnimodam certitudinem habent. Sed talis certitudo non potest inveniri in singularibus contingentibus, quae sunt variabilia et incerta. Ergo inquisitio consilii procedit in infinitum.

###### s. c.
*Sed contra, nullus movetur ad id ad quod impossibile est quod perveniat*, ut dicitur in I de caelo. Sed infinitum impossibile est transire. Si igitur inquisitio consilii sit infinita, nullus consiliari inciperet. Quod patet esse falsum.

###### co.
Respondeo dicendum quod inquisitio consilii est finita in actu ex duplici parte, scilicet ex parte principii, et ex parte termini. Accipitur enim in inquisitione consilii duplex principium. Unum proprium, ex ipso genere operabilium, et hoc est finis, de quo non est consilium, sed supponitur in consilio ut principium, ut dictum est. Aliud quasi ex alio genere assumptum sicut et in scientiis demonstrativis una scientia supponit aliqua ab alia, de quibus non inquirit. Huiusmodi autem principia quae in inquisitione consilii supponuntur, sunt quaecumque sunt per sensum accepta, utpote quod hoc sit panis vel ferrum; et quaecumque sunt per aliquam scientiam speculativam vel practicam in universali cognita, sicut quod moechari est a Deo prohibitum, et quod homo non potest vivere nisi nutriatur nutrimento convenienti. Et de istis non inquirit consiliator. Terminus autem inquisitionis est id quod statim est in potestate nostra ut faciamus. Sicut enim finis habet rationem principii, ita id quod agitur propter finem, habet rationem conclusionis. Unde id quod primo agendum occurrit, habet rationem ultimae conclusionis, ad quam inquisitio terminatur. Nihil autem prohibet consilium potentia infinitum esse, secundum quod in infinitum possunt aliqua occurrere consilio inquirenda.

###### ad 1
Ad primum ergo dicendum quod singularia non sunt infinita actu, sed in potentia tantum.

###### ad 2
Ad secundum dicendum quod, licet humana actio possit impediri, non tamen semper habet impedimentum paratum. Et ideo non semper oportet consiliari de impedimento tollendo.

###### ad 3
Ad tertium dicendum quod in singularibus contingentibus potest aliquid accipi certum, etsi non simpliciter, tamen ut nunc, prout assumitur in operatione. Socratem enim sedere non est necessarium, sed eum sedere, dum sedet, est necessarium. Et hoc per certitudinem accipi potest.

