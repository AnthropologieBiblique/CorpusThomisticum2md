## Quaestio 14

### Prooemium

Deinde considerandum est de consilio. Et circa hoc quaeruntur sex. Primo, utrum consilium sit inquisitio. Secundo, utrum consilium sit de fine, vel solum de his quae sunt ad finem. Tertio, utrum consilium sit solum de his quae a nobis aguntur. Quarto, utrum consilium sit de omnibus quae a nobis aguntur. Quinto, utrum consilium procedat ordine resolutorio. Sexto, utrum consilium procedat in infinitum.

![[II-I q. 14 a. 1#Articulus 1]]

![[II-I q. 14 a. 2#Articulus 2]]

![[II-I q. 14 a. 3#Articulus 3]]

![[II-I q. 14 a. 4#Articulus 4]]

![[II-I q. 14 a. 5#Articulus 5]]

![[II-I q. 14 a. 6#Articulus 6]]

