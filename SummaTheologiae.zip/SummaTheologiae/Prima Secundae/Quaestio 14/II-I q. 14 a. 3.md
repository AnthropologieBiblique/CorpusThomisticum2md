### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod consilium non sit solum de his quae aguntur a nobis. Consilium enim collationem quandam importat. Sed collatio inter multos potest fieri etiam de rebus immobilibus, quae non fiunt a nobis, puta de naturis rerum. Ergo consilium non solum est de his quae aguntur a nobis.

###### arg. 2
Praeterea, homines interdum consilium quaerunt de his quae sunt lege statuta, unde et iurisconsulti dicuntur. Et tamen eorum qui quaerunt huiusmodi consilium, non est leges facere. Ergo consilium non solum est de his quae a nobis aguntur.

###### arg. 3
Praeterea, dicuntur etiam quidam consultationes facere de futuris eventibus; qui tamen non sunt in potestate nostra. Ergo consilium non solum est de his quae a nobis fiunt.

###### arg. 4
Praeterea, si consilium esset solum de his quae a nobis fiunt, nullus consiliaretur de his quae sunt per alium agenda. Sed hoc patet esse falsum. Ergo consilium non solum est de his quae a nobis fiunt.

###### s. c.
Sed contra est quod Gregorius Nyssenus dicit, *consiliamur de his quae sunt in nobis, et per nos fieri possunt*.

###### co.
Respondeo dicendum quod consilium proprie importat collationem inter plures habitam. Quod et ipsum nomen designat, dicitur enim consilium quasi Considium, eo quod multi consident ad simul conferendum. Est autem considerandum quod in particularibus contingentibus, ad hoc quod aliquid certum cognoscatur, plures conditiones seu circumstantias considerare oportet, quas ab uno non facile est considerari, sed a pluribus certius percipiuntur, dum quod unus considerat, alii non occurrit, in necessariis autem et universalibus est absolutior et simplicior consideratio, ita quod magis ad huiusmodi considerationem unus per se sufficere potest. Et ideo inquisitio consilii proprie pertinet ad contingentia singularia. Cognitio autem veritatis in talibus non habet aliquid magnum, ut per se sit appetibilis, sicut cognitio universalium et necessariorum, sed appetitur secundum quod est utilis ad operationem, quia actiones sunt circa contingentia singularia. Et ideo dicendum est quod proprie consilium est circa ea quae aguntur a nobis.

###### ad 1
Ad primum ergo dicendum quod consilium importat collationem non quamcumque, sed collationem de rebus agendis, ratione iam dicta.

###### ad 2
Ad secundum dicendum quod id quod est lege positum, quamvis non sit ex operatione quaerentis consilium, tamen est directivum eius ad operandum, quia ista est una ratio aliquid operandi, mandatum legis.

###### ad 3
Ad tertium dicendum quod consilium non solum est de his quae aguntur, sed de his quae ordinantur ad operationes. Et propter hoc consultatio dicitur fieri de futuris eventibus, inquantum homo per futuros eventus cognitos dirigitur ad aliquid faciendum vel vitandum.

###### ad 4
Ad quartum dicendum quod de aliorum factis consilium quaerimus, inquantum sunt quodammodo unum nobiscum, vel per unionem affectus, sicut amicus sollicitus est de his quae ad amicum spectant, sicut de suis; vel per modum instrumenti, nam agens principale et instrumentale sunt quasi una causa, cum unum agat per alterum; et sic dominus consiliatur de his quae sunt agenda per servum.

