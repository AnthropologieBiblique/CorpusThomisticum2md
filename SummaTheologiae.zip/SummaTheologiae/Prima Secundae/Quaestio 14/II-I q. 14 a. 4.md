### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod consilium sit de omnibus quae sunt per nos agenda. Electio enim est appetitus praeconsiliati, ut dictum est. Sed electio est de omnibus quae per nos aguntur. Ergo et consilium.

###### arg. 2
Praeterea, consilium importat inquisitionem rationis. Sed in omnibus quae non per impetum passionis agimus, procedimus ex inquisitione rationis. Ergo de omnibus quae aguntur a nobis, est consilium.

###### arg. 3
Praeterea, philosophus dicit, in III Ethic., quod *si per plura aliquid fieri potest, consilio inquiritur per quod facillime et optime fiat; si autem per unum, qualiter per illud fiat*. Sed omne quod fit, fit per unum vel per multa. Ergo de omnibus quae fiunt a nobis, est consilium.

###### s. c.
Sed contra est quod Gregorius Nyssenus dicit, quod *de his quae secundum disciplinam vel artem sunt operibus, non est consilium*.

###### co.
Respondeo dicendum quod consilium est inquisitio quaedam, ut dictum est. De illis autem inquirere solemus, quae in dubium veniunt, unde et ratio inquisitiva, quae dicitur argumentum, est rei dubiae faciens fidem. Quod autem aliquid in operabilibus humanis non sit dubitabile, ex duobus contingit. Uno modo, quia per determinatas vias proceditur ad determinatos fines, sicut contingit in artibus quae habent certas vias operandi; sicut scriptor non consiliatur quomodo debeat trahere litteras, hoc enim determinatum est per artem. Alio modo, quia non multum refert utrum sic vel sic fiat, et ista sunt minima, quae parum adiuvant vel impediunt respectu finis consequendi; quod autem parum est, quasi nihil accipit ratio. Et ideo de duobus non consiliamur, quamvis ordinentur ad finem, ut philosophus dicit, scilicet de rebus parvis; et de his quae sunt determinata qualiter fieri debent, sicut est in operibus artium, praeter quasdam coniecturales, ut Gregorius Nyssenus dicit, ut puta medicinalis, negotiativa, et huiusmodi.

###### ad 1
Ad primum ergo dicendum quod electio praesupponit consilium ratione iudicii vel sententiae. Unde quando iudicium vel sententia manifesta est absque inquisitione, non requiritur consilii inquisitio.

###### ad 2
Ad secundum dicendum quod ratio in rebus manifestis non inquirit, sed statim iudicat. Et ideo non oportet in omnibus quae ratione aguntur, esse inquisitionem consilii.

###### ad 3
Ad tertium dicendum quod quando aliquid per unum potest fieri, sed diversis modis, potest dubitationem habere, sicut et quando fit per plura, et ideo opus est consilio. Sed quando determinatur non solum res, sed modus, tunc non est opus consilio.

