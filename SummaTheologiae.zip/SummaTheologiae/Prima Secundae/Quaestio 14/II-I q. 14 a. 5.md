### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod consilium non procedat modo resolutorio. Consilium enim est de his quae a nobis aguntur. Sed operationes nostrae non procedunt modo resolutorio, sed magis modo compositivo, scilicet de simplicibus ad composita. Ergo consilium non semper procedit modo resolutorio.

###### arg. 2
Praeterea, consilium est inquisitio rationis. Sed ratio a prioribus incipit, et ad posteriora devenit, secundum convenientiorem ordinem cum igitur praeterita sint priora praesentibus, et praesentia priora futuris, in consiliando videtur esse procedendum a praesentibus et praeteritis in futura. Quod non pertinet ad ordinem resolutorium. Ergo in consiliis non servatur ordo resolutorius.

###### arg. 3
Praeterea, consilium non est nisi de his quae sunt nobis possibilia, ut dicitur in III Ethic. Sed an sit nobis aliquid possibile, perpenditur ex eo quod possumus facere, vel non possumus facere, ut perveniamus in illud. Ergo in inquisitione consilii a praesentibus incipere oportet.

###### s. c.
Sed contra est quod philosophus dicit, in III Ethic., quod *ille qui consiliatur, videtur quaerere et resolvere*.

###### co.
Respondeo dicendum quod in omni inquisitione oportet incipere ab aliquo principio. Quod quidem si, sicut est prius in cognitione, ita etiam sit prius in esse, non est processus resolutorius, sed magis compositivus, procedere enim a causis in effectus, est processus compositivus, nam causae sunt simpliciores effectibus. Si autem id quod est prius in cognitione, sit posterius in esse, est processus resolutorius, utpote cum de effectibus manifestis iudicamus, resolvendo in causas simplices. Principium autem in inquisitione consilii est finis, qui quidem est prior in intentione, posterior tamen in esse. Et secundum hoc, oportet quod inquisitio consilii sit resolutiva, incipiendo scilicet ab eo quod in futuro intenditur, quousque perveniatur ad id quod statim agendum est.

###### ad 1
Ad primum ergo dicendum quod consilium est quidem de operationibus. Sed ratio operationum accipitur ex fine, et ideo ordo ratiocinandi de operationibus, est contrarius ordini operandi.

###### ad 2
Ad secundum dicendum quod ratio incipit ab eo quod est prius secundum rationem, non autem semper ab eo quod est prius tempore.

###### ad 3
Ad tertium dicendum quod de eo quod est agendum propter finem, non quaereremus scire an sit possibile, si non esset congruum fini. Et ideo prius oportet inquirere an conveniat ad ducendum in finem, quam consideretur an sit possibile.

