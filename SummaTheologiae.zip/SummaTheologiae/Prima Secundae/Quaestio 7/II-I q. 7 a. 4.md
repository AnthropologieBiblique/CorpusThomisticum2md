### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod non sint principales circumstantiae propter quid, et ea in quibus est operatio, ut dicitur in III Ethic. Ea enim in quibus est operatio, videntur esse locus et tempus, quae non videntur esse principalia inter circumstantias, cum sint maxime extrinseca ab actu. Ea ergo in quibus est operatio non sunt principalissimae circumstantiarum.

###### arg. 2
Praeterea, finis est extrinsecus rei. Non ergo videtur esse principalissima circumstantiarum.

###### arg. 3
Praeterea, principalissimum in unoquoque est causa eius et forma ipsius. Sed causa ipsius actus est persona agens; forma autem actus est modus ipsius. Ergo istae duae circumstantiae videntur esse principalissimae.

###### s. c.
Sed contra est quod Gregorius Nyssenus dicit, quod *principalissimae circumstantiae sunt cuius gratia agitur, et quid est quod agitur*.

###### co.
Respondeo dicendum quod actus proprie dicuntur humani, sicut supra dictum est, prout sunt voluntarii. Voluntatis autem motivum et obiectum est finis. Et ideo principalissima est omnium circumstantiarum illa quae attingit actum ex parte finis, scilicet cuius gratia, secundaria vero, quae attingit ipsam substantiam actus, idest quid fecit. Aliae vero circumstantiae sunt magis vel minus principales, secundum quod magis vel minus ad has appropinquant.

###### ad 1
Ad primum ergo dicendum quod per ea in quibus est operatio, philosophus non intelligit tempus et locum, sed ea quae adiunguntur ipsi actui. Unde Gregorius Nyssenus, quasi exponens dictum philosophi, loco eius quod philosophus dixit, in quibus est operatio, dicit quid agitur.

###### ad 2
Ad secundum dicendum quod finis, etsi non sit de substantia actus, est tamen causa actus principalissima, inquantum movet ad agendum. Unde et maxime actus moralis speciem habet ex fine.

###### ad 3
Ad tertium dicendum quod persona agens causa est actus secundum quod movetur a fine; et secundum hoc principaliter ordinatur ad actum. Aliae vero conditiones personae non ita principaliter ordinantur ad actum. Modus etiam non est substantialis forma actus, hoc enim attenditur in actu secundum obiectum et terminum vel finem, sed est quasi quaedam qualitas accidentalis.

