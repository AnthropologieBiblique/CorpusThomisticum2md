## Quaestio 7

### Prooemium

Deinde considerandum est de circumstantiis humanorum actuum. Et circa hoc quaeruntur quatuor. Primo, quid sit circumstantia. Secundo, utrum circumstantiae sint circa humanos actus attendendae a theologo. Tertio, quot sunt circumstantiae. Quarto, quae sunt in eis principaliores.

![[II-I q. 7 a. 1#Articulus 1]]

![[II-I q. 7 a. 2#Articulus 2]]

![[II-I q. 7 a. 3#Articulus 3]]

![[II-I q. 7 a. 4#Articulus 4]]

