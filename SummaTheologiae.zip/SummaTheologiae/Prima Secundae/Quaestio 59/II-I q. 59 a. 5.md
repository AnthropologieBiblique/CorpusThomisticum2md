### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod virtus moralis possit esse absque passione. Quanto enim virtus moralis est perfectior, tanto magis superat passiones. Ergo in suo perfectissimo esse, est omnino absque passionibus.

###### arg. 2
Praeterea, tunc unumquodque est perfectum, quando est remotum a suo contrario, et ab his quae ad contrarium inclinant. Sed passiones inclinant ad peccatum, quod virtuti contrariatur, unde [[Rm 7]], nominantur passiones peccatorum. Ergo perfecta virtus est omnino absque passione.

###### arg. 3
Praeterea, secundum virtutem Deo conformamur; ut patet per Augustinum, in libro de moribus Eccles. Sed Deus omnia operatur sine passione. Ergo virtus perfectissima est absque omni passione.

###### s. c.
Sed contra est quod nullus iustus est qui non gaudet iusta operatione, ut dicitur in I Ethic. Sed gaudium est passio. Ergo iustitia non potest esse sine passione. Et multo minus aliae virtutes.

###### co.
Respondeo dicendum quod, si passiones dicamus inordinatas affectiones, sicut Stoici posuerunt; sic manifestum est quod virtus perfecta est sine passionibus. Si vero passiones dicamus omnes motus appetitus sensitivi, sic planum est quod virtutes morales quae sunt circa passiones sicut circa propriam materiam, sine passionibus esse non possunt. Cuius ratio est, quia secundum hoc, sequeretur quod virtus moralis faceret appetitum sensitivum omnino otiosum. Non autem ad virtutem pertinet quod ea quae sunt subiecta rationi, a propriis actibus vacent, sed quod exequantur imperium rationis, proprios actus agendo. Unde sicut virtus membra corporis ordinat ad actus exteriores debitos, ita appetitum sensitivum ad motus proprios ordinatos. Virtutes vero morales quae non sunt circa passiones, sed circa operationes, possunt esse sine passionibus (et huiusmodi virtus est iustitia), quia per eas applicatur voluntas ad proprium actum, qui non est passio. Sed tamen ad actum iustitiae sequitur gaudium, ad minus in voluntate, quod non est passio. Et si hoc gaudium multiplicetur per iustitiae perfectionem, fiet gaudii redundantia usque ad appetitum sensitivum; secundum quod vires inferiores sequuntur motum superiorum, ut supra dictum est. Et sic per redundantiam huiusmodi, quanto virtus fuerit perfectior, tanto magis passionem causat.

###### ad 1
Ad primum ergo dicendum quod virtus passiones inordinatas superat, moderatas autem producit.

###### ad 2
Ad secundum dicendum quod passiones inordinatae inducunt ad peccandum, non autem si sunt moderatae.

###### ad 3
Ad tertium dicendum quod bonum in unoquoque consideratur secundum conditionem suae naturae. In Deo autem et Angelis non est appetitus sensitivus, sicut est in homine. Et ideo bona operatio Dei et Angeli est omnino sine passione, sicut et sine corpore, bona autem operatio hominis est cum passione, sicut et cum corporis ministerio.

