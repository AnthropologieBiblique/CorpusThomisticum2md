## Quaestio 59

### Prooemium

Deinde considerandum est de distinctione moralium virtutum ad invicem. Et quia virtutes morales quae sunt circa passiones, distinguuntur secundum diversitatem passionum, oportet primo considerare comparationem virtutis ad passionem; secundo, distinctionem moralium virtutum secundum passiones. Circa primum quaeruntur quinque. Primo, utrum virtus moralis sit passio. Secundo, utrum virtus moralis possit esse cum passione. Tertio, utrum possit esse cum tristitia. Quarto, utrum omnis virtus moralis sit circa passionem. Quinto, utrum aliqua virtus moralis possit esse sine passione.

![[II-I q. 59 a. 1#Articulus 1]]

![[II-I q. 59 a. 2#Articulus 2]]

![[II-I q. 59 a. 3#Articulus 3]]

![[II-I q. 59 a. 4#Articulus 4]]

![[II-I q. 59 a. 5#Articulus 5]]

