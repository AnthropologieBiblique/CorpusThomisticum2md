### Articulus 4

###### arg. 1
Ad quartum sic proceditur. Videtur quod omnis virtus moralis sit circa passiones. Dicit enim philosophus, in II Ethic., quod *circa voluptates et tristitias est moralis virtus*. Sed delectatio et tristitia sunt passiones, ut supra dictum est. Ergo omnis virtus moralis est circa passiones.

###### arg. 2
Praeterea, rationale per participationem est subiectum moralium virtutum, ut dicitur in I Ethic. Sed huiusmodi pars animae est in qua sunt passiones, ut supra dictum est. Ergo omnis virtus moralis est circa passiones.

###### arg. 3
Praeterea, in omni virtute morali est invenire aliquam passionem. Aut ergo omnes sunt circa passiones, aut nulla. Sed aliquae sunt circa passiones, ut fortitudo et temperantia, ut dicitur in III Ethic. Ergo omnes virtutes morales sunt circa passiones.

###### s. c.
Sed contra est quod iustitia, quae est virtus moralis, non est circa passiones, ut dicitur in V Ethic.

###### co.
Respondeo dicendum quod virtus moralis perficit appetitivam partem animae ordinando ipsam in bonum rationis. Est autem rationis bonum id quod est secundum rationem moderatum seu ordinatum. Unde circa omne id quod contingit ratione ordinari et moderari, contingit esse virtutem moralem. Ratio autem ordinat non solum passiones appetitus sensitivi; sed etiam ordinat operationes appetitus intellectivi, qui est voluntas, quae non est subiectum passionis, ut supra dictum est. Et ideo non omnis virtus moralis est circa passiones; sed quaedam circa passiones, quaedam circa operationes.

###### ad 1
Ad primum ergo dicendum quod non omnis virtus moralis est circa delectationes et tristitias sicut circa propriam materiam, sed sicut circa aliquid consequens proprium actum. Omnis enim virtuosus delectatur in actu virtutis, et tristatur in contrario. Unde philosophus post praemissa verba subdit quod, *si virtutes sunt circa actus et passiones; omni autem passioni et omni actui sequitur delectatio et tristitia; propter hoc virtus erit circa delectationes et tristitias*, scilicet sicut circa aliquid consequens.

###### ad 2
Ad secundum dicendum quod rationale per participationem non solum est appetitus sensitivus, qui est subiectum passionum; sed etiam voluntas, in qua non sunt passiones, ut dictum est.

###### ad 3
Ad tertium dicendum quod in quibusdam virtutibus sunt passiones sicut propria materia, in quibusdam autem non. Unde non est eadem ratio de omnibus, ut infra ostendetur.

