### Articulus 6

###### arg. 1
Ad sextum sic proceditur. Videtur quod caritas non sit maxima inter virtutes theologicas. Cum enim fides sit in intellectu, spes autem et caritas in vi appetitiva, ut supra dictum est; videtur quod fides comparetur ad spem et caritatem, sicut virtus intellectualis ad moralem. Sed virtus intellectualis est maior morali, ut ex dictis patet. Ergo fides est maior spe et caritate.

###### arg. 2
Praeterea, quod se habet ex additione ad aliud, videtur esse maius eo. Sed spes, ut videtur, se habet ex additione ad caritatem, praesupponit enim spes amorem, ut Augustinus dicit in Enchirid.; addit autem quendam motum protensionis in rem amatam. Ergo spes est maior caritate.

###### arg. 3
Praeterea, causa est potior effectu. Sed fides et spes sunt causa caritatis, dicitur enim [[Mt 1]], in Glossa, quod *fides generat spem, et spes caritatem*. Ergo fides et spes sunt maiores caritate.

###### s. c.
Sed contra est quod apostolus dicit, I ad Cor. XIII, *nunc autem manent fides, spes, caritas, tria haec; maior autem horum est caritas*.

###### co.
Respondeo dicendum quod, sicut supra dictum est, magnitudo virtutis secundum suam speciem, consideratur ex obiecto. Cum autem tres virtutes theologicae respiciant Deum sicut proprium obiectum, non potest una earum dici maior altera ex hoc quod sit circa maius obiectum; sed ex eo quod una se habet propinquius ad obiectum quam alia. Et hoc modo caritas est maior aliis. Nam aliae important in sui ratione quandam distantiam ab obiecto, est enim fides de non visis, spes autem de non habitis. Sed amor caritatis est de eo quod iam habetur, est enim amatum quodammodo in amante, et etiam amans per affectum trahitur ad unionem amati; propter quod dicitur [[1 Jn 4]], *qui manet in caritate, in Deo manet, et Deus in eo*.

###### ad 1
Ad primum ergo dicendum quod non hoc modo se habent fides et spes ad caritatem, sicut prudentia ad virtutem moralem. Et hoc propter duo. Primo quidem, quia virtutes theologicae habent obiectum quod est supra animam humanam, sed prudentia et virtutes morales sunt circa ea quae sunt infra hominem. In his autem quae sunt supra hominem, nobilior est dilectio quam cognitio. Perficitur enim cognitio, secundum quod cognita sunt in cognoscente, dilectio vero, secundum quod diligens trahitur ad rem dilectam. Id autem quod est supra hominem, nobilius est in seipso quam sit in homine, quia unumquodque est in altero per modum eius in quo est. E converso autem est in his quae sunt infra hominem. Secundo, quia prudentia moderatur motus appetitivos ad morales virtutes pertinentes, sed fides non moderatur motum appetitivum tendentem in Deum, qui pertinet ad virtutes theologicas; sed solum ostendit obiectum. Motus autem appetitivus in obiectum, excedit cognitionem humanam; secundum illud ad [[Ep 3]], *supereminentem scientiae caritatem Christi*.

###### ad 2
Ad secundum dicendum quod spes praesupponit amorem eius quod quis adipisci se sperat, qui est amor concupiscentiae, quo quidem amore magis se amat qui concupiscit bonum, quam aliquid aliud. Caritas autem importat amorem amicitiae, ad quam pervenitur spe, ut supra dictum est.

###### ad 3
Ad tertium dicendum quod causa perficiens est potior effectu, non autem causa disponens. Sic enim calor ignis esset potior quam anima, ad quam disponit materiam, quod patet esse falsum. Sic autem fides generat spem, et spes caritatem, secundum scilicet quod una disponit ad alteram.

