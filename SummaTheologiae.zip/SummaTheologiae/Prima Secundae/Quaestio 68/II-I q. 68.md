## Quaestio 68

### Prooemium

Consequenter considerandum est de donis. Et circa hoc quaeruntur octo. Primo, utrum dona differant a virtutibus. Secundo, de necessitate donorum. Tertio, utrum dona sint habitus. Quarto, quae, et quot sint. Quinto, utrum dona sint connexa. Sexto, utrum maneant in patria. Septimo, de comparatione eorum ad invicem. Octavo, de comparatione eorum ad virtutes.

![[II-I q. 68 a. 1#Articulus 1]]

![[II-I q. 68 a. 2#Articulus 2]]

![[II-I q. 68 a. 3#Articulus 3]]

![[II-I q. 68 a. 4#Articulus 4]]

![[II-I q. 68 a. 5#Articulus 5]]

![[II-I q. 68 a. 6#Articulus 6]]

![[II-I q. 68 a. 7#Articulus 7]]

![[II-I q. 68 a. 8#Articulus 8]]

