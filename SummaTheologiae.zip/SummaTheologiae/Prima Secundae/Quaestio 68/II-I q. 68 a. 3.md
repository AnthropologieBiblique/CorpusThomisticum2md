### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod dona spiritus sancti non sint habitus. Habitus enim est qualitas in homine manens, est enim qualitas difficile mobilis, ut dicitur in praedicamentis. Sed proprium Christi est quod dona spiritus sancti in eo requiescant, ut dicitur [[Is 11]]. Et [[Jn 1]], dicitur, *super quem videris spiritum descendentem, et manentem super eum, hic est qui baptizat*, quod exponens Gregorius, in II Moral., dicit, *in cunctis fidelibus spiritus sanctus venit; sed in solo mediatore semper singulariter permanet*. Ergo dona spiritus sancti non sunt habitus.

###### arg. 2
Praeterea, dona spiritus sancti perficiunt hominem secundum quod agitur a spiritu Dei, sicut dictum est. Sed inquantum homo agitur a spiritu Dei, se habet quodammodo ut instrumentum respectu eius. Non autem convenit ut instrumentum perficiatur per habitum, sed principale agens. Ergo dona spiritus sancti non sunt habitus.

###### arg. 3
Praeterea, sicut dona spiritus sancti sunt ex inspiratione divina, ita et donum prophetiae. Sed prophetia non est habitus, non enim semper spiritus prophetiae adest prophetis, ut Gregorius dicit, in I homilia Ezechielis. Ergo neque etiam dona spiritus sancti sunt habitus.

###### s. c.
Sed contra est quod dominus dicit discipulis, de spiritu sancto loquens, [[Jn 14]], *apud vos manebit, et in vobis erit*. Spiritus autem sanctus non est in hominibus absque donis eius. Ergo dona eius manent in hominibus. Ergo non solum sunt actus vel passiones, sed etiam habitus permanentes.

###### co.
Respondeo dicendum quod, sicut dictum est, dona sunt quaedam perfectiones hominis, quibus disponitur ad hoc quod homo bene sequatur instinctum spiritus sancti. Manifestum est autem ex supradictis quod virtutes morales perficiunt vim appetitivam secundum quod participat aliqualiter rationem, inquantum scilicet nata est moveri per imperium rationis. Hoc igitur modo dona spiritus sancti se habent ad hominem in comparatione ad spiritum sanctum, sicut virtutes morales se habent ad vim appetitivam in comparatione ad rationem. Virtutes autem morales habitus quidam sunt, quibus vires appetitivae disponuntur ad prompte obediendum rationi. Unde et dona spiritus sancti sunt quidam habitus, quibus homo perficitur ad prompte obediendum spiritui sancto.

###### ad 1
Ad primum ergo dicendum quod Gregorius ibidem solvit, dicens quod *in illis donis sine quibus ad vitam perveniri non potest, spiritus sanctus in electis omnibus semper manet, sed in aliis non semper manet*. Septem autem dona sunt necessaria ad salutem, ut dictum est. Unde quantum ad ea, spiritus sanctus semper manet in sanctis.

###### ad 2
Ad secundum dicendum quod ratio illa procedit de instrumento cuius non est agere, sed solum agi. Tale autem instrumentum non est homo; sed sic agitur a spiritu sancto, quod etiam agit, inquantum est liberi arbitrii. Unde indiget habitu.

###### ad 3
Ad tertium dicendum quod prophetia est de donis quae sunt ad manifestationem spiritus, non autem ad necessitatem salutis. Unde non est simile.

