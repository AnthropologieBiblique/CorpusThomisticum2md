### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod gratia inconvenienter dividatur in praevenientem et subsequentem. Gratia enim est divinae dilectionis effectus. Sed Dei dilectio nunquam est subsequens, sed semper praeveniens; secundum illud [[1 Jn 4]], *non quasi nos dilexerimus Deum, sed quia ipse prior dilexit nos*. Ergo gratia non debet poni praeveniens et subsequens.

###### arg. 2
Praeterea, gratia gratum faciens est una tantum in homine, cum sit sufficiens, secundum illud II ad Cor. XII, *sufficit tibi gratia mea*. Sed idem non potest esse prius et posterius. Ergo gratia inconvenienter dividitur in praevenientem et subsequentem.

###### arg. 3
Praeterea, gratia cognoscitur per effectus. Sed infiniti sunt effectus gratiae, quorum unus praecedit alium. Ergo si penes hoc gratia deberet dividi in praevenientem et subsequentem, videtur quod infinitae essent species gratiae. Infinita autem relinquuntur a qualibet arte. Non ergo gratia convenienter dividitur in praevenientem et subsequentem.

###### s. c.
Sed contra est quod gratia Dei ex eius misericordia provenit. Sed utrumque in Psalmo legitur, *misericordia eius praeveniet me*; et iterum, *misericordia eius subsequetur me*. Ergo gratia convenienter dividitur in praevenientem et subsequentem.

###### co.
Respondeo dicendum quod, sicut gratia dividitur in operantem et cooperantem secundum diversos effectus, ita etiam in praevenientem et subsequentem, qualitercumque gratia accipiatur. Sunt autem quinque effectus gratiae in nobis, quorum primus est ut anima sanetur; secundus est ut bonum velit; tertius est ut bonum quod vult, efficaciter operetur; quartus est ut in bono perseveret; quintus est ut ad gloriam perveniat. Et ideo gratia secundum quod causat in nobis primum effectum, vocatur praeveniens respectu secundi effectus; et prout causat in nobis secundum, vocatur subsequens respectu primi effectus. Et sicut unus effectus est posterior uno effectu et prior alio, ita gratia potest dici et praeveniens et subsequens secundum eundem effectum, respectu diversorum. Et hoc est quod Augustinus dicit, in libro de Nat. et Grat., *praevenit ut sanemur, subsequitur ut sanati vegetemur, praevenit ut vocemur, subsequitur ut glorificemur*.

###### ad 1
Ad primum ergo dicendum quod dilectio Dei nominat aliquid aeternum, et ideo nunquam potest dici nisi praeveniens. Sed gratia significat effectum temporalem, qui potest praecedere aliquid et ad aliquid subsequi. Et ideo gratia potest dici praeveniens et subsequens.

###### ad 2
Ad secundum dicendum quod gratia non diversificatur per hoc quod est praeveniens et subsequens, secundum essentiam, sed solum secundum effectum, sicut et de operante et cooperante dictum est. Quia etiam secundum quod gratia subsequens ad gloriam pertinet, non est alia numero a gratia praeveniente per quam nunc iustificamur. Sicut enim caritas viae non evacuatur, sed perficitur in patria, ita etiam et de lumine gratiae est dicendum, quia neutrum in sui ratione imperfectionem importat.

###### ad 3
Ad tertium dicendum quod, quamvis effectus gratiae possint esse infiniti numero, sicut sunt infiniti actus humani; tamen omnes reducuntur ad aliqua determinata in specie. Et praeterea omnes conveniunt in hoc quod unus alium praecedit.

