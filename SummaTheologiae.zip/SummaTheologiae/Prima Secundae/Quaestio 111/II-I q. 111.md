## Quaestio 111

### Prooemium

Deinde considerandum est de divisione gratiae. Et circa hoc quaeruntur quinque. Primo, utrum convenienter dividatur gratia per gratiam gratis datam et gratiam gratum facientem. Secundo, de divisione gratiae gratum facientis per operantem et cooperantem. Tertio, de divisione eiusdem per gratiam praevenientem et subsequentem. Quarto, de divisione gratiae gratis datae. Quinto, de comparatione gratiae gratum facientis et gratis datae.

![[II-I q. 111 a. 1#Articulus 1]]

![[II-I q. 111 a. 2#Articulus 2]]

![[II-I q. 111 a. 3#Articulus 3]]

![[II-I q. 111 a. 4#Articulus 4]]

![[II-I q. 111 a. 5#Articulus 5]]

