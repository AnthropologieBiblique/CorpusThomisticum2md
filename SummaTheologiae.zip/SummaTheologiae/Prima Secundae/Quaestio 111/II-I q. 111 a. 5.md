### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod gratia gratis data sit dignior quam gratia gratum faciens. *Bonum enim gentis est melius quam bonum unius*; ut philosophus dicit, in I Ethic. Sed gratia gratum faciens ordinatur solum ad bonum unius hominis, gratia autem gratis data ordinatur ad bonum commune totius Ecclesiae, ut supra dictum est. Ergo gratia gratis data est dignior quam gratia gratum faciens.

###### arg. 2
Praeterea, maioris virtutis est quod aliquid possit agere in aliud, quam quod solum in seipso perficiatur, sicut maior est claritas corporis quod potest etiam alia corpora illuminare, quam eius quod ita in se lucet quod alia illuminare non potest. Propter quod etiam philosophus dicit, in V Ethic., quod iustitia est praeclarissima virtutum, per quam homo recte se habet etiam ad alios. Sed per gratiam gratum facientem homo perficitur in seipso, per gratiam autem gratis datam homo operatur ad perfectionem aliorum. Ergo gratia gratis data est dignior quam gratia gratum faciens.

###### arg. 3
Praeterea, id quod est proprium meliorum, dignius est quam id quod est commune omnium, sicut ratiocinari, quod est proprium hominis, dignius est quam sentire, quod est commune omnibus animalibus. Sed gratia gratum faciens est communis omnibus membris Ecclesiae, gratia autem gratis data est proprium donum digniorum membrorum Ecclesiae. Ergo gratia gratis data est dignior quam gratia gratum faciens.

###### s. c.
Sed contra est quod apostolus, I ad Cor. XII, enumeratis gratiis gratis datis, subdit, *adhuc excellentiorem viam vobis demonstro*, et sicut per subsequentia patet, loquitur de caritate, quae pertinet ad gratiam gratum facientem. Ergo gratia gratum faciens excellentior est quam gratia gratis data.

###### co.
Respondeo dicendum quod unaquaeque virtus tanto excellentior est, quanto ad altius bonum ordinatur. Semper autem finis potior est his quae sunt ad finem. Gratia autem gratum faciens ordinat hominem immediate ad coniunctionem ultimi finis. Gratiae autem gratis datae ordinant hominem ad quaedam praeparatoria finis ultimi, sicut per prophetiam et miracula et alia huiusmodi homines inducuntur ad hoc quod ultimo fini coniungantur. Et ideo gratia gratum faciens est multo excellentior quam gratia gratis data.

###### ad 1
Ad primum ergo dicendum quod, sicut philosophus dicit, in XII Metaphys., bonum multitudinis, sicut exercitus, est duplex. Unum quidem quod est in ipsa multitudine, puta ordo exercitus. Aliud autem quod est separatum a multitudine, sicut bonum ducis, et hoc melius est, quia ad hoc etiam illud aliud ordinatur. Gratia autem gratis data ordinatur ad bonum commune Ecclesiae quod est ordo ecclesiasticus, sed gratia gratum faciens ordinatur ad bonum commune separatum, quod est ipse Deus. Et ideo gratia gratum faciens est nobilior.

###### ad 2
Ad secundum dicendum quod, si gratia gratis data posset hoc agere in altero quod homo per gratiam gratum facientem consequitur, sequeretur quod gratia gratis data esset nobilior, sicut excellentior est claritas solis illuminantis quam corporis illuminati. Sed per gratiam gratis datam homo non potest causare in alio coniunctionem ad Deum, quam ipse habet per gratiam gratum facientem; sed causat quasdam dispositiones ad hoc. Et ideo non oportet quod gratia gratis data sit excellentior, sicut nec in igne calor manifestativus speciei eius, per quam agit ad inducendum calorem in alia, est nobilior quam forma substantialis ipsius.

###### ad 3
Ad tertium dicendum quod sentire ordinatur ad ratiocinari sicut ad finem, et ideo ratiocinari est nobilius. Hic autem est e converso, quia id quod est proprium, ordinatur ad id quod est commune sicut ad finem. Unde non est simile.

