### Articulus 8

###### arg. 1
Ad octavum sic proceditur. Videtur quod Damascenus inconvenienter assignet tres species irae, scilicet fel, maniam et furorem. Nullius enim generis species diversificantur secundum aliquod accidens. Sed ista tria diversificantur secundum aliquod accidens, *principium enim motus irae fel vocatur; ira autem permanens dicitur mania; furor autem est ira observans tempus in vindictam*. Ergo non sunt diversae species irae.

###### arg. 2
Praeterea, Tullius, in IV de Tusculanis quaest., dicit quod *excandescentia Graece dicitur thymosis; et est ira modo nascens et modo desistens*. Thymosis autem secundum Damascenum, est idem quod furor. Non ergo furor tempus quaerit ad vindictam, sed tempore deficit.

###### arg. 3
Praeterea, Gregorius, XXI Moral., ponit tres gradus irae, scilicet *iram sine voce, et iram cum voce, et iram cum verbo expresso*, secundum illa tria quae dominus ponit [[Mt 5]], qui irascitur fratri suo, ubi tangitur ira sine voce; et postea subdit, qui dixerit fratri suo, raca, ubi tangitur ira cum voce, sed necdum pleno verbo formata; et postea dicit, qui autem dixerit fratri suo, fatue, ubi expletur vox perfectione sermonis. Ergo insufficienter divisit Damascenus iram, nihil ponens ex parte vocis.

###### s. c.
Sed contra est auctoritas Damasceni et Gregorii Nysseni.

###### co.
Respondeo dicendum quod tres species irae quas Damascenus ponit, et etiam Gregorius Nyssenus, sumuntur secundum ea quae dant irae aliquod augmentum. Quod quidem contingit tripliciter. Uno modo, ex facilitate ipsius motus, et talem iram vocat fel, quia cito accenditur. Alio modo, ex parte tristitiae causantis iram, quae diu in memoria manet, et haec pertinet ad maniam, quae a manendo dicitur. Tertio, ex parte eius quod iratus appetit, scilicet vindictae, et haec pertinet ad furorem, qui nunquam quiescit donec puniat. Unde philosophus, in IV Ethic., quosdam irascentium vocat acutos, quia cito irascuntur; quosdam amaros, quia diu retinent iram; quosdam difficiles, quia nunquam quiescunt nisi puniant.

###### ad 1
Ad primum ergo dicendum quod omnia illa per quae ira recipit aliquam perfectionem, non omnino per accidens se habent ad iram. Et ideo nihil prohibet secundum ea species irae assignari.

###### ad 2
Ad secundum dicendum quod excandescentia, quam Tullius ponit, magis videtur pertinere ad primam speciem irae, quae perficitur secundum velocitatem irae, quam ad furorem. Nihil autem prohibet ut thymosis Graece, quod Latine furor dicitur, utrumque importet, et velocitatem ad irascendum et firmitatem propositi ad puniendum.

###### ad 3
Ad tertium dicendum quod gradus illi irae distinguuntur secundum effectum irae, non autem secundum diversam perfectionem ipsius motus irae.

