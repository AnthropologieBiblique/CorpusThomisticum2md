## Quaestio 46

### Prooemium

Deinde considerandum est de ira. Et primo, de ira secundum se; secundo, de causa factiva irae, et remedio eius; tertio, de effectu eius. Circa primum quaeruntur octo. Primo, utrum ira sit passio specialis. Secundo, utrum obiectum irae sit bonum, an malum. Tertio, utrum ira sit in concupiscibili. Quarto, utrum ira sit cum ratione. Quinto, utrum ira sit naturalior quam concupiscentia. Sexto, utrum ira sit gravior quam odium. Septimo, utrum ira solum sit ad illos ad quos est iustitia. Octavo, de speciebus irae.

![[II-I q. 46 a. 1#Articulus 1]]

![[II-I q. 46 a. 2#Articulus 2]]

![[II-I q. 46 a. 3#Articulus 3]]

![[II-I q. 46 a. 4#Articulus 4]]

![[II-I q. 46 a. 5#Articulus 5]]

![[II-I q. 46 a. 6#Articulus 6]]

![[II-I q. 46 a. 7#Articulus 7]]

![[II-I q. 46 a. 8#Articulus 8]]

