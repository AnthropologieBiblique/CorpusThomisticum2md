### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod ira sit in concupiscibili. Dicit enim Tullius, in IV de Tusculanis quaest., quod ira est libido quaedam. Sed libido est in concupiscibili. Ergo et ira.

###### arg. 2
Praeterea, Augustinus dicit, in regula, quod ira crescit in odium. Et Tullius dicit, in eodem libro, quod odium est ira inveterata. Sed odium est in concupiscibili, sicut amor. Ergo ira est in concupiscibili.

###### arg. 3
Praeterea, Damascenus et Gregorius Nyssenus dicunt quod ira componitur ex tristitia et desiderio. Sed utrumque horum est in concupiscibili. Ergo ira est in concupiscibili.

###### s. c.
Sed contra, vis concupiscibilis est alia ab irascibili. Si igitur ira esset in concupiscibili, non denominaretur ab ea vis irascibilis.

###### co.
Respondeo dicendum quod, sicut supra dictum est, passiones irascibilis in hoc differunt a passionibus concupiscibilis, quod obiecta passionum concupiscibilis sunt bonum et malum absolute; obiecta autem passionum irascibilis sunt bonum et malum cum quadam elevatione vel arduitate. Dictum est autem quod ira respicit duo obiecta, scilicet vindictam, quam appetit; et eum de quo vindictam quaerit. Et circa utrumque quandam arduitatem ira requirit, non enim insurgit motus irae, nisi aliqua magnitudine circa utrumque existente; *quaecumque enim nihil sunt, aut modica valde nullo digna aestimamus*, ut dicit philosophus, in II Rhetoric. Unde manifestum est quod ira non est in concupiscibili, sed in irascibili.

###### ad 1
Ad primum ergo dicendum quod Tullius libidinem nominat appetitum cuiuscumque boni futuri non habita discretione ardui vel non ardui. Et secundum hoc, ponit iram sub libidine, inquantum est appetitus vindictae. Sic autem libido communis est ad irascibilem et concupiscibilem.

###### ad 2
Ad secundum dicendum quod ira dicitur crescere in odium, non quod eadem numero passio quae prius fuit ira, postmodum fiat odium per quandam inveterationem, sed per quandam causalitatem. Ira enim, per diuturnitatem, causat odium.

###### ad 3
Ad tertium dicendum quod ira dicitur componi ex tristitia et desiderio, non sicut ex partibus, sed sicut ex causis. Dictum est autem supra quod passiones concupiscibilis sunt causae passionum irascibilis.

