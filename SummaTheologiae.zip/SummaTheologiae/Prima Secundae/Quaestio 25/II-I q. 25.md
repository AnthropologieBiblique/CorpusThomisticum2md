## Quaestio 25

### Prooemium

Deinde considerandum est de ordine passionum ad invicem. Et circa hoc quaeruntur quatuor. Primo, de ordine passionum irascibilis ad passiones concupiscibilis. Secundo, de ordine passionum concupiscibilis ad invicem. Tertio, de ordine passionum irascibilis ad invicem. Quarto, de quatuor principalibus passionibus.

![[II-I q. 25 a. 1#Articulus 1]]

![[II-I q. 25 a. 2#Articulus 2]]

![[II-I q. 25 a. 3#Articulus 3]]

