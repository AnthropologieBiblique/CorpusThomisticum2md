### Articulus 3

###### arg. 1
Ad tertium sic proceditur. Videtur quod spes non sit prima inter passiones irascibilis. Vis enim irascibilis ab ira denominatur. Cum ergo denominatio fiat a potiori, videtur quod ira sit potior et prior quam spes.

###### arg. 2
Praeterea, arduum est obiectum irascibilis. Sed magis videtur esse arduum quod aliquis conetur superare malum contrarium quod imminet ut futurum, quod pertinet ad audaciam; vel quod iniacet iam ut praesens, quod pertinet ad iram; quam quod conetur acquirere simpliciter aliquod bonum. Et similiter magis videtur esse arduum quod conetur vincere malum praesens, quam malum futurum. Ergo ira videtur esse potior passio quam audacia, et audacia quam spes. Et sic spes non videtur esse prior.

###### arg. 3
Praeterea, prius occurrit, in motu ad finem, recessus a termino, quam accessus ad terminum. Sed timor et desperatio important recessum ab aliquo, audacia autem et spes important accessum ad aliquid. Ergo timor et desperatio praecedunt spem et audaciam.

###### s. c.
Sed contra, quanto aliquid est propinquius primo, tanto est prius. Sed spes est propinquior amori, qui est prima passionum. Ergo spes est prior inter omnes passiones irascibilis.

###### co.
Respondeo dicendum quod, sicut iam dictum est, omnes passiones irascibilis important motum in aliquid. Motus autem ad aliquid in irascibili potest causari ex duobus, uno modo, ex sola aptitudine seu proportione ad finem, quae pertinet ad amorem vel odium; alio modo, ex praesentia ipsius boni vel mali, quae pertinet ad tristitiam vel gaudium. Et quidem ex praesentia boni non causatur aliqua passio in irascibili, ut dictum est, sed ex praesentia mali causatur passio irae. Quia igitur in via generationis seu consecutionis, proportio vel aptitudo ad finem praecedit consecutionem finis; inde est quod ira, inter omnes passiones irascibilis, est ultima, ordine generationis. Inter alias autem passiones irascibilis, quae important motum consequentem amorem vel odium boni vel mali, oportet quod passiones quarum obiectum est bonum, scilicet spes et desperatio, sint naturaliter priores passionibus quarum obiectum est malum, scilicet audacia et timore. Ita tamen quod spes est prior desperatione, quia spes est motus in bonum secundum rationem boni quod de sua ratione est attractivum, et ideo est motus in bonum per se; desperatio autem est recessus a bono, qui non competit bono secundum quod est bonum, sed secundum aliquid aliud, unde est quasi per accidens. Et eadem ratione, timor, cum sit recessus a malo, est prior quam audacia. Quod autem spes et desperatio sint naturaliter priores quam timor et audacia, ex hoc manifestum est, quod, sicut appetitus boni est ratio quare vitetur malum, ita etiam spes et desperatio sunt ratio timoris et audaciae, nam audacia consequitur spem victoriae, et timor consequitur desperationem vincendi. Ira autem consequitur audaciam, nullus enim irascitur vindictam appetens, nisi audeat vindicare, secundum quod Avicenna dicit, in sexto de naturalibus. Sic ergo patet quod spes est prima inter omnes passiones irascibilis. Et si ordinem omnium passionum secundum viam generationis, scire velimus, primo occurrunt amor et odium; secundo, desiderium et fuga; tertio, spes et desperatio; quarto, timor et audacia; quinto, ira; sexto et ultimo, gaudium et tristitia, quae consequuntur ad omnes passiones, ut dicitur in II Ethic. Ita tamen quod amor est prior odio, et desiderium fuga, et spes desperatione, et timor audacia, et gaudium quam tristitia, ut ex praedictis colligi potest.

###### ad 1
Ad primum ergo dicendum quod, quia ira causatur ex aliis passionibus sicut effectus a causis praecedentibus, ideo ab ea, tanquam a manifestiori, denominatur potentia.

###### ad 2
Ad secundum dicendum quod arduum non est ratio accedendi vel appetendi, sed potius bonum. Et ideo spes, quae directius respicit bonum, est prior, quamvis audacia aliquando sit in magis arduum, vel etiam ira.

###### ad 3
Ad tertium dicendum quod appetitus primo et per se movetur in bonum, sicut in proprium obiectum; et ex hoc causatur quod recedat a malo. Proportionatur enim motus appetitivae partis, non quidem motui naturali, sed intentioni naturae; quae per prius intendit finem quam remotionem contrarii, quae non quaeritur nisi propter adeptionem finis.

