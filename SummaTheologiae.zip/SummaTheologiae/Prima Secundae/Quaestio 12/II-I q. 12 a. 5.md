### Articulus 5

###### arg. 1
Ad quintum sic proceditur. Videtur quod bruta animalia intendant finem. Natura enim in his quae cognitione carent, magis distat a rationali natura, quam natura sensitiva, quae est in animalibus brutis. Sed natura intendit finem etiam in his quae cognitione carent, ut probatur in II Physic. Ergo multo magis bruta animalia intendunt finem.

###### arg. 2
Praeterea, sicut intentio est finis, ita et fruitio. Sed fruitio convenit brutis animalibus, ut dictum est. Ergo et intentio.

###### arg. 3
Praeterea, eius est intendere finem, cuius est agere propter finem, cum intendere nihil sit nisi in aliud tendere. Sed bruta animalia agunt propter finem, movetur enim animal vel ad cibum quaerendum, vel ad aliquid huiusmodi. Ergo bruta animalia intendunt finem.

###### s. c.
Sed contra, intentio finis importat ordinationem alicuius in finem quod est rationis. Cum igitur bruta animalia non habeant rationem, videtur quod non intendant finem.

###### co.
Respondeo dicendum quod, sicut supra dictum est, intendere est in aliud tendere; quod quidem est et moventis, et moti. Secundum quidem igitur quod dicitur intendere finem id quod movetur ad finem ab alio, sic natura dicitur intendere finem, quasi mota ad suum finem a Deo, sicut sagitta a sagittante. Et hoc modo etiam bruta animalia intendunt finem, inquantum moventur instinctu naturali ad aliquid. Alio modo intendere finem est moventis, prout scilicet ordinat motum alicuius, vel sui vel alterius, in finem. Quod est rationis tantum. Unde per hunc modum bruta non intendunt finem, quod est proprie et principaliter intendere, ut dictum est.

###### ad 1
Ad primum ergo dicendum quod ratio illa procedit secundum quod intendere est eius quod movetur ad finem.

###### ad 2
Ad secundum dicendum quod fruitio non importat ordinationem alicuius in aliquid, sicut intentio; sed absolutam quietem in fine.

###### ad 3
Ad tertium dicendum quod bruta animalia moventur ad finem, non quasi considerantia quod per motum suum possunt consequi finem, quod est proprie intendentis, sed concupiscentia finem naturali instinctu, moventur ad finem quasi ab alio mota, sicut et cetera quae moventur naturaliter.

