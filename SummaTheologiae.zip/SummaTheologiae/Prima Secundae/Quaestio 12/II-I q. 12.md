## Quaestio 12

### Prooemium

Deinde considerandum est de intentione. Et circa hoc quaeruntur quinque. Primo, utrum intentio sit actus intellectus, vel voluntatis secundo, utrum sit tantum finis ultimi. Tertio, utrum aliquis possit simul duo intendere. Quarto, utrum intentio finis sit idem actus cum voluntate eius quod est ad finem. Quinto, utrum intentio conveniat brutis animalibus.

![[II-I q. 12 a. 1#Articulus 1]]

![[II-I q. 12 a. 2#Articulus 2]]

![[II-I q. 12 a. 3#Articulus 3]]

![[II-I q. 12 a. 4#Articulus 4]]

![[II-I q. 12 a. 5#Articulus 5]]

