### Articulus 2

###### arg. 1
Ad secundum sic proceditur. Videtur quod intentio sit tantum ultimi finis. Dicitur enim in libro sententiarum prosperi, *clamor ad Deum est intentio cordis*. Sed Deus est ultimus finis humani cordis. Ergo intentio semper respicit ultimum finem.

###### arg. 2
Praeterea, intentio respicit finem secundum quod est terminus, ut dictum est. Sed terminus habet rationem ultimi. Ergo intentio semper respicit ultimum finem.

###### arg. 3
Praeterea, sicut intentio respicit finem, ita et fruitio. Sed fruitio semper est ultimi finis. Ergo et intentio.

###### s. c.
Sed contra, ultimus finis humanarum voluntatum est unus, scilicet beatitudo, ut supra dictum est. Si igitur intentio esset tantum ultimi finis, non essent diversae hominum intentiones. Quod patet esse falsum.

###### co.
Respondeo dicendum quod, sicut dictum est, intentio respicit finem secundum quod est terminus motus voluntatis. In motu autem potest accipi terminus dupliciter, uno modo, ipse terminus ultimus, in quo quiescitur, qui est terminus totius motus; alio modo, aliquod medium, quod est principium unius partis motus, et finis vel terminus alterius. Sicut in motu quo itur de a in c per b, c est terminus ultimus, b autem est terminus, sed non ultimus. Et utriusque potest esse intentio. Unde etsi semper sit finis, non tamen oportet quod semper sit ultimi finis.

###### ad 1
Ad primum ergo dicendum quod intentio cordis dicitur clamor ad Deum, non quod Deus sit obiectum intentionis semper, sed quia est intentionis cognitor. Vel quia, cum oramus, intentionem nostram ad Deum dirigimus, quae quidem intentio vim clamoris habet.

###### ad 2
Ad secundum dicendum quod terminus habet rationem ultimi; sed non semper ultimi respectu totius, sed quandoque respectu alicuius partis.

###### ad 3
Ad tertium dicendum quod fruitio importat quietem in fine, quod pertinet solum ad ultimum finem. Sed intentio importat motum in finem, non autem quietem. Unde non est similis ratio.

