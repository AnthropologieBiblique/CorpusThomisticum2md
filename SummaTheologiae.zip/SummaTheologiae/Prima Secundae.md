# Prima Secundae

[[II-I q. 1]]

[[II-I q. 2]]

[[II-I q. 3]]

[[II-I q. 4]]

[[II-I q. 5]]

[[II-I q. 6]]

[[II-I q. 7]]

[[II-I q. 8]]

[[II-I q. 9]]

[[II-I q. 10]]

[[II-I q. 11]]

[[II-I q. 12]]

[[II-I q. 13]]

[[II-I q. 14]]

[[II-I q. 15]]

[[II-I q. 16]]

[[II-I q. 17]]

[[II-I q. 18]]

[[II-I q. 19]]

[[II-I q. 20]]

[[II-I q. 21]]

[[II-I q. 22]]

[[II-I q. 23]]

[[II-I q. 24]]

[[II-I q. 25]]

[[II-I q. 26]]

[[II-I q. 27]]

[[II-I q. 28]]

[[II-I q. 29]]

[[II-I q. 30]]

[[II-I q. 31]]

[[II-I q. 32]]

[[II-I q. 33]]

[[II-I q. 34]]

[[II-I q. 35]]

[[II-I q. 36]]

[[II-I q. 37]]

[[II-I q. 38]]

[[II-I q. 39]]

[[II-I q. 40]]

[[II-I q. 41]]

[[II-I q. 42]]

[[II-I q. 43]]

[[II-I q. 44]]

[[II-I q. 45]]

[[II-I q. 46]]

[[II-I q. 47]]

[[II-I q. 48]]

[[II-I q. 49]]

[[II-I q. 50]]

[[II-I q. 51]]

[[II-I q. 52]]

[[II-I q. 53]]

[[II-I q. 54]]

[[II-I q. 55]]

[[II-I q. 56]]

[[II-I q. 57]]

[[II-I q. 58]]

[[II-I q. 59]]

[[II-I q. 60]]

[[II-I q. 61]]

[[II-I q. 62]]

[[II-I q. 63]]

[[II-I q. 64]]

[[II-I q. 65]]

[[II-I q. 66]]

[[II-I q. 67]]

[[II-I q. 68]]

[[II-I q. 69]]

[[II-I q. 70]]

[[II-I q. 71]]

[[II-I q. 72]]

[[II-I q. 73]]

[[II-I q. 74]]

[[II-I q. 75]]

[[II-I q. 76]]

[[II-I q. 77]]

[[II-I q. 78]]

[[II-I q. 79]]

[[II-I q. 80]]

[[II-I q. 81]]

[[II-I q. 82]]

[[II-I q. 83]]

[[II-I q. 84]]

[[II-I q. 85]]

[[II-I q. 86]]

[[II-I q. 87]]

[[II-I q. 88]]

[[II-I q. 89]]

[[II-I q. 90]]

[[II-I q. 91]]

[[II-I q. 92]]

[[II-I q. 93]]

[[II-I q. 94]]

[[II-I q. 95]]

[[II-I q. 96]]

[[II-I q. 97]]

[[II-I q. 98]]

[[II-I q. 99]]

[[II-I q. 100]]

[[II-I q. 101]]

[[II-I q. 102]]

[[II-I q. 103]]

[[II-I q. 104]]

[[II-I q. 105]]

[[II-I q. 106]]

[[II-I q. 107]]

[[II-I q. 108]]

[[II-I q. 109]]

[[II-I q. 110]]

[[II-I q. 111]]

[[II-I q. 112]]

[[II-I q. 113]]

[[II-I q. 114]]

